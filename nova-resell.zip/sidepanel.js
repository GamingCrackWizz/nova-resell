// ===== Nova Resell – photos → annonce complète → validation =====

const $ = (s) => document.querySelector(s);

let settings = { apiKey: '', model: 'claude-haiku-5-5', nextSku: 1, extraRules: '', autoAnalyze: true, autoDraft: true };
let articles = [];
let filter = 'all';

const ETATS = ['Neuf avec étiquette', 'Neuf sans étiquette', 'Très bon état', 'Bon état', 'Satisfaisant'];
const GENRES = ['Femme', 'Homme', 'Enfant', 'Unisexe'];

// ---------- Utilitaires ----------
const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  kids.flat().forEach((k) => k != null && k !== false && n.append(k));
  return n;
};
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}
const copy = (txt, label = 'Copié') => navigator.clipboard.writeText(txt).then(() => toast(label + ' ✓'));
const stateOf = (a) => {
  if (a.status !== 'done') return a.status;
  if (a.draftStatus === 'sending') return 'sending';
  if (a.draftId) return 'ready';
  if (a.draftStatus === 'error') return 'drafterr';
  return 'done';
};
const VINTED_COLORS = ['Noir', 'Gris', 'Blanc', 'Crème', 'Beige', 'Abricot', 'Orange', 'Corail', 'Rouge', 'Bordeaux', 'Fuchsia', 'Rose', 'Violet', 'Lila', 'Bleu clair', 'Bleu', 'Marine', 'Turquoise', 'Menthe', 'Vert', 'Vert foncé', 'Kaki', 'Marron', 'Moutarde', 'Jaune', 'Argenté', 'Doré', 'Multicolore'];

// ---------- Stockage ----------
async function load() {
  const s = await chrome.storage.local.get(['settings', 'articles']);
  settings = { ...settings, ...(s.settings || {}) };
  articles = (s.articles || []).map((a) => (a.status === 'loading' ? { ...a, status: 'pending' } : a));
  // migration 1.3.5 : recalcule la catégorie Vinted des anciens articles (nouvelles règles + liste de choix)
  articles.forEach((a) => { if (a.vintedCat && !a.vintedCandidates && !a.catManual) { a.vintedCat = null; a.vintedCatKey = null; } });
  fillSettings();
  render();
  if (!settings.apiKey && !/worker|print/.test(location.hash)) openSettings('api');
}
const saveArticles = () => chrome.storage.local.set({ articles });
const saveSettings = () => chrome.storage.local.set({ settings });

// ---------- Réglages ----------
function fillSettings() {
  $('#apiKey').value = settings.apiKey;
  $('#model').value = settings.model;
  $('#aiPhotoPx').value = String(settings.aiPhotoPx || 800);
  $('#nextSku').value = settings.nextSku;
  $('#skuAuto').checked = settings.skuAuto !== false;
  $('#nextSku').disabled = settings.skuAuto !== false;
  $('#extraRules').value = settings.extraRules;
  $('#autoAnalyze').checked = settings.autoAnalyze !== false;
  $('#priceMargin').value = settings.priceMargin ?? 40;
  $('#autoDraft').checked = settings.autoDraft !== false;
  $('#skuInfo').textContent = 'Prochain SKU : P' + settings.nextSku;
}
function openSettings(section) {
  $('#settings').hidden = false;
  if (section) document.querySelectorAll('#settings .seg-btn[data-set]').forEach((b) => b.classList.toggle('active', b.dataset.set === section));
  const cur = section || document.querySelector('#settings .seg-btn[data-set].active')?.dataset.set || 'compte';
  document.querySelectorAll('#settings .set-pane').forEach((p) => { p.hidden = p.dataset.set !== cur; });
  $('#settings').scrollIntoView({ block: 'start' });
}
document.querySelectorAll('#settings .seg-btn[data-set]').forEach((b) => b.addEventListener('click', () => openSettings(b.dataset.set)));
$('#toggleSettings').addEventListener('click', () => { if ($('#settings').hidden) openSettings(); else $('#settings').hidden = true; });
$('#closeSettings').addEventListener('click', () => { $('#settings').hidden = true; });
document.querySelectorAll('.save-settings').forEach((btn) => btn.addEventListener('click', async () => {
  settings.apiKey = $('#apiKey').value.trim();
  settings.model = $('#model').value;
  settings.aiPhotoPx = Number($('#aiPhotoPx').value) || 800;
  settings.nextSku = Math.max(1, parseInt($('#nextSku').value, 10) || 1);
  settings.extraRules = $('#extraRules').value.trim();
  settings.skuAuto = $('#skuAuto').checked;
  settings.autoAnalyze = $('#autoAnalyze').checked;
  settings.priceMargin = Math.min(200, Math.max(0, Number($('#priceMargin').value) || 0));
  settings.autoDraft = $('#autoDraft').checked;
  await saveSettings();
  fillSettings();
  toast('Réglages enregistrés ✓');
}));

// ---------- Photos ----------
function resizeImage(file, max = 1024) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const r = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * r);
      c.height = Math.round(img.height * r);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error(file.name + ' illisible (HEIC ? convertis en JPG)')); };
    img.src = url;
  });
}

async function readFiles(fileList) {
  const files = [...fileList].filter((f) => f.type.startsWith('image/') || /\.(heic|heif)$/i.test(f.name));
  const out = [];
  for (const f of files) {
    try { out.push(await resizeImage(f)); } catch (e) { toast(e.message); }
  }
  return out;
}

async function addArticle(fileList) {
  const photos = await readFiles(fileList);
  if (!photos.length) return;
  const a = { id: crypto.randomUUID(), photos, status: 'pending', sku: null, data: null, open: false };
  a.photos = await enhanceList(photos, a);
  articles.unshift(a);
  await saveArticles();
  render();
  toast(`Article ajouté · ${photos.length} photo${photos.length > 1 ? 's' : ''}`);
  if (settings.autoAnalyze !== false && settings.apiKey) enqueue(() => analyze(a));
}

function pickFiles(callback) {
  const input = el('input', { type: 'file', accept: 'image/*', multiple: true });
  input.addEventListener('change', () => callback(input.files));
  input.click();
}

const drop = $('#drop');
drop.addEventListener('click', () => $('#fileInput').click());
drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('#fileInput').click(); } });
$('#fileInput').addEventListener('change', async (e) => { await addArticle(e.target.files); e.target.value = ''; });
drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
drop.addEventListener('dragleave', () => drop.classList.remove('over'));
drop.addEventListener('drop', async (e) => { e.preventDefault(); drop.classList.remove('over'); await addArticle(e.dataTransfer.files); });
document.addEventListener('dragover', (e) => e.preventDefault());
document.addEventListener('drop', (e) => e.preventDefault());

// ---------- SKU automatique : continue après le plus grand SKU trouvé (Vinted + articles locaux) ----------
let skuCheckedAt = 0;
async function syncSku(force = false) {
  if (settings.skuAuto === false) return;
  const localMax = Math.max(0, ...articles.map((a) => Number(String(a.sku || '').replace(/\D/g, '')) || 0));
  let vintedMax = settings.vintedMaxSku || 0;
  if (force || Date.now() - skuCheckedAt > 120000) {
    try {
      const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
      if (tab) { vintedMax = await vinted('maxSku'); settings.vintedMaxSku = vintedMax; skuCheckedAt = Date.now(); }
    } catch { /* Vinted indisponible : on garde la valeur connue */ }
  }
  const next = Math.max(settings.nextSku || 1, localMax + 1, vintedMax + 1);
  if (next !== settings.nextSku) { settings.nextSku = next; await saveSettings(); fillSettings(); }
}

// File d'attente : un article traité à la fois
let queue = Promise.resolve();
const enqueue = (job) => (queue = queue.then(job).catch(() => {}));

// ---------- Claude ----------
function buildSystem(sku) {
  return `Tu es un expert de la revente de vêtements d'occasion sur Vinted France. À partir des photos d'UN SEUL article, tu crées son annonce complète.

Règles :
- Titre : type d'article + marque + coupe ou détail marquant + couleur (+ genre si utile, + "vintage" si pertinent). Environ 60 caractères maximum, puis il se termine EXACTEMENT par " (#${sku})".
- Description : courte et directe, une information par ligne, SANS tirets, puces ni phrases inutiles. Lignes typiques : article et marque, taille, état, matière si connue, mesures si visibles, "Envoi rapide et soigné". Ensuite une ligne vide puis 18 à 25 hashtags pertinents sur une seule ligne : d'abord en français (marque, type, style, couleur, matière, époque, genre, tendance), puis les mots-clés les plus importants (type d'article, style, couleur) traduits en anglais, italien, espagnol et allemand, car Vinted est consulté dans toute l'Europe (ex. #veste #jacket #giacca #chaqueta #jacke). Pas de hashtag inventé ou trompeur, pas de doublon, uniquement des lettres et chiffres sans espace ni accent dans un hashtag.
- État : "Très bon état" par défaut. "Bon état" ou "Satisfaisant" seulement si un défaut est visible. "Neuf avec étiquette" seulement si l'étiquette de magasin est visible. Valeurs possibles : ${ETATS.join(', ')}.
- Marque, taille, composition : lis les étiquettes si elles sont visibles. N'invente pas : si tu n'es pas sûr, mets ta meilleure estimation et signale-le dans "incertitudes".
- Type d'article ("type_article") : le type précis en 2 à 4 mots, ex. "veste de survêtement", "pull col V", "doudoune", "sweat zippé à capuche".
- Catégorie : chemin de catégorie Vinted, ex. "Femmes > Vêtements > Pulls et sweats > Pulls". Une veste de survêtement n'est PAS une veste de ski.
- Prix : entier en euros, un peu AU-DESSUS du prix de revente habituel sur Vinted pour garder une marge de négociation.
- Taille : écris-la comme sur Vinted (ex. "M", "38", "W32", "42"), sans texte autour.
- Couleurs : 1 ou 2 couleurs choisies UNIQUEMENT dans : ${VINTED_COLORS.join(', ')}.
- Matières : noms simples en français (ex. "Coton", "Laine", "Polyester", "Cachemire").
- Ordre des photos ("ordre_photos") : liste des numéros de photos dans l'ordre idéal pour Vinted : 1) vêtement entier vu de FACE (photo principale), 2) vêtement vu de DOS, 3) étiquette de marque, 4) étiquette taille / composition, 5) détails, 6) défauts éventuels. Tous les numéros doivent apparaître une seule fois.
- Colis : "petit" (vêtement léger), "moyen" (chaussures, veste épaisse) ou "grand".
${settings.extraRules ? '\nRègles du vendeur :\n' + settings.extraRules + '\n' : ''}
Réponds UNIQUEMENT avec un objet JSON valide, sans texte autour :
{"titre":"","description":"","type_article":"","categorie":"","marque":"","taille":"","etat":"","genre":"Femme|Homme|Enfant|Unisexe","couleurs":[""],"matieres":[""],"prix":0,"colis":"petit|moyen|grand","ordre_photos":[1,2,3],"justification_prix":"","incertitudes":[""]}`;
}

// Économie d'API : l'IA reçoit au plus 5 photos, réduites à 800 px (Vinted garde toutes les photos en pleine qualité)
const aiMaxPhotos = () => (Number(settings.aiPhotoPx) === 1024 ? 6 : 5), aiMaxPx = () => Number(settings.aiPhotoPx) || 800;
function shrinkForAi(dataUrl) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const r = Math.min(1, aiMaxPx() / Math.max(img.width, img.height));
      if (r === 1) return resolve(dataUrl);
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.82));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}
async function callClaude(allPhotos, sku) {
  if (!(await NovaAccess.ok())) { if (typeof showAccessGate === 'function') showAccessGate(); throw new Error('Accès Nova inactif'); }
  const photos = await Promise.all(allPhotos.slice(0, aiMaxPhotos()).map(shrinkForAi));
  const content = photos.flatMap((p, i) => [
    { type: 'text', text: `Photo ${i + 1} :` },
    { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: p.split(',')[1] } },
  ]);
  content.push({ type: 'text', text: `Crée l'annonce Vinted de cet article. SKU : ${sku}.` });

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': settings.apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: settings.model,
      max_tokens: 2000,
      system: buildSystem(sku),
      messages: [{ role: 'user', content }],
    }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error?.message || 'Erreur API ' + res.status);
  recordUsage('annonce', settings.model, json.usage);

  const text = (json.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error('Réponse de Claude illisible, réessaie.');
  const d = JSON.parse(match[0]);

  const tag = `(#${sku})`;
  d.titre = String(d.titre || '').trim();
  if (!d.titre.endsWith(tag)) d.titre = d.titre.replace(/\(#P\d+\)\s*$/, '').trim() + ' ' + tag;
  if (!ETATS.includes(d.etat)) d.etat = 'Très bon état';
  d.couleurs = [].concat(d.couleurs || []).filter(Boolean);
  d.matieres = [].concat(d.matieres || []).filter(Boolean);
  d.incertitudes = [].concat(d.incertitudes || []).filter(Boolean);
  d.prix = Math.round(Number(d.prix) || 0);
  // ordre des photos : permutation valide de 1..n, sinon ordre d'origine
  const n = photos.length;
  const ord = [].concat(d.ordre_photos || []).map(Number).filter((x) => x >= 1 && x <= n);
  const sent = new Set(ord).size === n && ord.length === n ? ord : [...Array(n)].map((_, i) => i + 1);
  // les photos non analysées (au-delà de 5) gardent leur place, à la suite
  d.ordre_photos = [...sent, ...[...Array(Math.max(0, allPhotos.length - n))].map((_, i) => n + i + 1)];
  return d;
}

async function analyze(a) {
  if (!settings.apiKey) { openSettings('api'); toast("Ajoute d'abord ta clé API"); return false; }
  if (!a.sku) {
    await syncSku();
    a.sku = 'P' + settings.nextSku;
    settings.nextSku += 1;
    await saveSettings();
    fillSettings();
  }
  a.status = 'loading'; a.error = null;
  render();
  try {
    a.data = await callClaude(a.photos, a.sku);
    a.photos = a.data.ordre_photos.map((k) => a.photos[k - 1]);
    a.status = 'done';
    a.open = true;
    a.draftId = null; a.draftStatus = null; a.draftError = null;
  } catch (e) {
    a.status = 'error'; a.error = e.message;
  }
  await saveArticles();
  render();
  if (a.status === 'error') reportMobile(a, { status: 'error', error: a.error });
  else reportMobile(a, { status: 'pc', title: a.data.titre, sku: a.sku, price: a.data.prix });
  if (a.status === 'done' && settings.autoDraft !== false) await sendToVinted(a);
  return a.status === 'done';
}

// Analyse en lot avec barre de progression
let running = false;
$('#analyzeAll').addEventListener('click', async () => {
  if (running) return;
  const todo = articles.filter((a) => a.status === 'pending' || a.status === 'error').reverse();
  if (!todo.length) return;
  if (!settings.apiKey) { openSettings('api'); toast("Ajoute d'abord ta clé API"); return; }
  running = true;
  const bar = $('#progressBar'), txt = $('#progressText');
  $('#progress').hidden = false;
  let ok = 0;
  for (let i = 0; i < todo.length; i++) {
    bar.style.width = (i / todo.length) * 100 + '%';
    txt.textContent = `Analyse ${i + 1} / ${todo.length}`;
    if (await new Promise((res) => enqueue(async () => res(await analyze(todo[i]))))) ok++;
  }
  bar.style.width = '100%';
  txt.textContent = `${ok} / ${todo.length} annonces créées`;
  setTimeout(() => { $('#progress').hidden = true; bar.style.width = '0'; }, 1800);
  running = false;
  render();
});

$('#clearAll').addEventListener('click', async () => {
  if (!articles.length || !confirm('Supprimer tous les articles de la liste ?')) return;
  articles = []; await saveArticles(); render();
});

document.querySelectorAll('.chip[data-filter]').forEach((c) => c.addEventListener('click', () => {
  filter = c.dataset.filter;
  document.querySelectorAll('.chip[data-filter]').forEach((x) => x.classList.toggle('active', x === c));
  render();
}));

// ---------- Champs ----------
function field(a, key, label, opts = {}) {
  let v = a.data[key];
  if (Array.isArray(v)) v = v.join(', ');
  let input;
  if (opts.type === 'textarea') input = el('textarea', { rows: opts.rows || 8, value: v ?? '' });
  else if (opts.options) {
    const list = opts.options.includes(v) || !v ? opts.options : [v, ...opts.options];
    input = el('select', {}, list.map((o) => el('option', { value: o, textContent: o })));
    input.value = v || opts.options[0];
  } else input = el('input', { type: 'text', value: v ?? '' });

  const counter = opts.counter ? el('small', { textContent: String(v ?? '').length + ' car.' }) : null;
  const copyBtn = opts.copy ? el('button', { className: 'copy', textContent: 'Copier' }) : null;
  copyBtn?.addEventListener('click', (e) => { e.preventDefault(); copy(input.value, label + ' copié'); });

  input.addEventListener('input', () => { if (counter) counter.textContent = input.value.length + ' car.'; });
  input.addEventListener('change', () => {
    let nv = input.value;
    if (key === 'couleurs' || key === 'matieres') nv = nv.split(',').map((s) => s.trim()).filter(Boolean);
    a.data[key] = nv;
    saveArticles();
    if (key === 'titre' || key === 'marque' || key === 'taille') updateTop(a);
    scheduleSync(a);
  });

  return el('label', {}, el('span', { className: 'field-head' }, el('span', { textContent: label }), el('span', {}, counter, ' ', copyBtn)), input);
}

function priceField(a) {
  const input = el('input', { type: 'number', min: 0, value: a.data.prix || 0 });
  const set = (n) => { a.data.prix = Math.max(0, Math.round(n || 0)); input.value = a.data.prix; saveArticles(); updateTop(a); updateStats(); scheduleSync(a); };
  const minus = el('button', { type: 'button', textContent: '−' });
  const plus = el('button', { type: 'button', textContent: '+' });
  minus.addEventListener('click', (e) => { e.preventDefault(); set(a.data.prix - 1); });
  plus.addEventListener('click', (e) => { e.preventDefault(); set(a.data.prix + 1); });
  input.addEventListener('change', () => set(Number(input.value)));
  return el('label', {}, 'Prix (€)', el('div', { className: 'stepper' }, minus, input, plus));
}

// ---------- Cartes ----------
const BADGES = { pending: 'À analyser', loading: 'Analyse…', sending: 'Envoi Vinted…', done: 'Pas encore sur Vinted', ready: 'Brouillon Vinted ✓', drafterr: 'Erreur Vinted', error: 'Erreur' };
const chevron = () => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', '18'); s.setAttribute('height', '18');
  s.setAttribute('class', 'chev');
  s.innerHTML = '<path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
  return s;
};

function topContent(a) {
  const st = stateOf(a);
  const title = a.data?.titre || 'Nouvel article';
  const sub = a.data
    ? [a.data.marque, a.data.taille, a.data.etat].filter(Boolean).join(' · ')
    : `${a.photos.length} photo${a.photos.length > 1 ? 's' : ''}${a.sku ? ' · ' + a.sku : ''}`;
  const badge = el('span', { className: 'badge ' + st });
  if (st === 'loading' || st === 'sending') badge.append(el('span', { className: 'spinner' }));
  badge.append(BADGES[st]);
  return [
    el('div', { className: 'cover' }, el('img', { src: a.photos[0], alt: '' }),
      a.photos.length > 1 && el('span', { className: 'count', textContent: a.photos.length })),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: title }), el('div', { className: 'sub', textContent: sub })),
    el('div', { className: 'side' }, a.data ? el('span', { className: 'price', textContent: (a.data.prix || 0) + ' €' }) : null, badge, quickAnalyze(a)),
    chevron(),
  ];
}
function quickAnalyze(a) {
  if (a.status !== 'pending' && a.status !== 'error') return null;
  const b = el('button', { className: 'btn primary quick', textContent: a.status === 'error' ? 'Réessayer' : 'Analyser' });
  b.addEventListener('click', (e) => { e.stopPropagation(); enqueue(() => analyze(a)); });
  return b;
}
function updateTop(a) {
  const top = document.querySelector(`[data-id="${a.id}"] .card-top`);
  if (top) top.replaceChildren(...topContent(a).filter(Boolean));
}

function card(a) {
  const st = stateOf(a);
  const c = el('div', { className: 'card' + (a.open ? ' open' : '') + (st === 'ready' ? ' is-ready' : '') });
  c.dataset.id = a.id;

  const top = el('div', { className: 'card-top' }, ...topContent(a));
  top.addEventListener('click', () => { a.open = !a.open; saveArticles(); render(); });
  c.append(top);

  c.addEventListener('dragover', (e) => { e.preventDefault(); e.stopPropagation(); c.classList.add('over'); });
  c.addEventListener('dragleave', () => c.classList.remove('over'));
  c.addEventListener('drop', async (e) => {
    e.preventDefault(); e.stopPropagation(); c.classList.remove('over');
    if (!e.dataTransfer.files?.length) return;
    const added = await readFiles(e.dataTransfer.files);
    if (added.length) { a.photos.push(...(await enhanceList(added, a))); a.photosDirty = true; await saveArticles(); render(); scheduleSync(a); toast(`${added.length} photo(s) ajoutée(s)`); }
  });

  if (!a.open) return c;

  const body = el('div', { className: 'card-body' });
  const busy = a.status === 'loading' || a.draftStatus === 'sending';

  // Photos
  const thumbs = el('div', { className: 'thumbs' });
  a.photos.forEach((p, i) => {
    const rm = el('button', { title: 'Retirer', textContent: '✕' });
    rm.addEventListener('click', async () => {
      if (a.photos.length === 1) return toast('Il faut au moins une photo');
      a.photos.splice(i, 1); a.photosDirty = true; await saveArticles(); render(); scheduleSync(a);
    });
    const left = el('button', { className: 'mv l', title: 'Déplacer à gauche', textContent: '‹', disabled: i === 0 });
    const right = el('button', { className: 'mv r', title: 'Déplacer à droite', textContent: '›', disabled: i === a.photos.length - 1 });
    const move = async (to) => {
      if (to < 0 || to >= a.photos.length || to === i) return;
      const [x] = a.photos.splice(i, 1); a.photos.splice(to, 0, x);
      a.photosDirty = true; await saveArticles(); render(); scheduleSync(a);
    };
    left.addEventListener('click', () => move(i - 1));
    right.addEventListener('click', () => move(i + 1));
    const im = el('img', { src: p, alt: '', draggable: false });
    if (a.orig?.[p]) { im.style.cursor = 'zoom-in'; im.title = 'Voir avant / après'; im.addEventListener('click', () => openCompare(a, p)); }
    const t = el('div', { className: 'thumb', draggable: true }, im, rm, left, right,
      i === 0 ? el('span', { className: 'main-tag', textContent: 'Principale' }) : null,
      a.orig?.[p] ? el('span', { className: 'enh-tag', textContent: '✨' }) : null);
    t.addEventListener('dragstart', (e) => { e.stopPropagation(); e.dataTransfer.setData('text/va-photo', String(i)); e.dataTransfer.effectAllowed = 'move'; t.classList.add('dragging'); });
    t.addEventListener('dragend', () => t.classList.remove('dragging'));
    t.addEventListener('dragover', (e) => { if ([...e.dataTransfer.types].includes('text/va-photo')) { e.preventDefault(); e.stopPropagation(); t.classList.add('drop-target'); } });
    t.addEventListener('dragleave', () => t.classList.remove('drop-target'));
    t.addEventListener('drop', async (e) => {
      const from = e.dataTransfer.getData('text/va-photo');
      if (from === '') return;
      e.preventDefault(); e.stopPropagation();
      const f = Number(from);
      if (f === i) return render();
      const [x] = a.photos.splice(f, 1); a.photos.splice(i, 0, x);
      a.photosDirty = true; await saveArticles(); render(); scheduleSync(a);
    });
    thumbs.append(t);
  });
  const add = el('button', { className: 'add-thumb', title: 'Ajouter des photos', textContent: '+' });
  add.addEventListener('click', () => pickFiles(async (files) => {
    const added = await readFiles(files);
    if (added.length) { a.photos.push(...(await enhanceList(added, a))); a.photosDirty = true; await saveArticles(); render(); scheduleSync(a); }
  }));
  thumbs.append(add);
  body.append(thumbs);

  if (a.status === 'error') body.append(el('div', { className: 'alert err', textContent: a.error }));

  if (a.data) {
    if (a.data.incertitudes?.length) body.append(el('div', { className: 'alert warn', textContent: '⚠︎ À vérifier : ' + a.data.incertitudes.join(' · ') }));
    body.append(
      field(a, 'titre', 'Titre', { counter: true, copy: true }),
      field(a, 'description', 'Description', { type: 'textarea', rows: 9, copy: true }),
      field(a, 'categorie', 'Catégorie'),
      el('div', { className: 'grid2' },
        field(a, 'marque', 'Marque'),
        field(a, 'taille', 'Taille'),
        field(a, 'etat', 'État', { options: ETATS }),
        field(a, 'genre', 'Genre', { options: GENRES }),
        field(a, 'couleurs', 'Couleurs'),
        field(a, 'matieres', 'Matières'),
      ),
      priceField(a),
    );
    if (a.data.justification_prix) body.append(el('div', { className: 'hint', textContent: '💡 ' + a.data.justification_prix }));
    if (a.market?.n) body.append(marketBar(a.market, Number(a.data.prix)));
    if (a.vintedCat) {
      const opts = [a.vintedCat, ...(a.vintedCandidates || []).filter((c) => c.id !== a.vintedCat.id)];
      const sel = el('select', {}, opts.map((c) => el('option', { value: c.id, textContent: c.path.replace(/^(Hommes|Femmes|Enfants) > Vêtements > /, '$1 › ') })));
      sel.value = a.vintedCat.id;
      sel.addEventListener('change', () => {
        const c = opts.find((x) => String(x.id) === sel.value);
        a.vintedCat = c; a.catManual = true; saveArticles();
        toast('Catégorie changée : mise à jour du brouillon…');
        scheduleSync(a);
      });
      body.append(el('label', { className: 'vcat' }, 'Catégorie Vinted', sel));
    }
    if (a.draftStatus === 'error') body.append(el('div', { className: 'alert err', textContent: 'Brouillon non créé : ' + a.draftError }));
    if (a.draftId && a.draftWarnings?.length) body.append(el('div', { className: 'alert warn', textContent: '⚠︎ À compléter sur Vinted : ' + a.draftWarnings.join(', ') }));
    if (a.draftId) body.append(el('div', { className: 'hint sync-' + (a.syncState || 'ok'), textContent:
      a.syncState === 'pending' ? '⏳ Modification en attente d\'envoi à Vinted…'
      : a.syncState === 'syncing' ? '↻ Mise à jour du brouillon Vinted…'
      : a.syncState === 'error' ? '⚠︎ Mise à jour Vinted échouée : ' + (a.syncError || '') + ' (clique sur « Mettre à jour »)'
      : "✓ Brouillon à jour sur Vinted. Tes modifications ici sont envoyées automatiquement. Valide-le dans l'onglet Brouillons." }));
  }

  // Actions
  const actions = el('div', { className: 'actions' });
  const btnAnalyze = el('button', { className: 'btn' + (a.data ? '' : ' primary'), disabled: busy, textContent: a.data ? '↻ Réanalyser' : 'Analyser' });
  btnAnalyze.addEventListener('click', () => enqueue(() => analyze(a)));
  actions.append(btnAnalyze);

  if (a.data) {
    const all = el('button', { className: 'btn', textContent: 'Copier tout' });
    all.addEventListener('click', () => copy(a.data.titre + '\n\n' + a.data.description, 'Annonce copiée'));
    actions.append(all);
  }
  const del = el('button', { className: 'btn ghost danger', disabled: busy, textContent: 'Supprimer' });
  del.addEventListener('click', async () => {
    if (!confirm('Supprimer cet article ?')) return;
    articles = articles.filter((x) => x !== a); await saveArticles(); render();
  });
  actions.append(del, el('span', { className: 'spacer' }));

  if (a.data) {
    if (a.draftId) {
      const open = el('button', { className: 'btn', textContent: 'Ouvrir sur Vinted' });
      open.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/items/${a.draftId}/edit` }));
      const resend = el('button', { className: 'btn ghost', disabled: busy, textContent: 'Mettre à jour' });
      resend.addEventListener('click', () => syncNow(a));
      actions.append(resend, open);
    } else {
      const send = el('button', { className: 'btn primary', disabled: busy, textContent: a.draftStatus === 'error' ? '↻ Réessayer Vinted' : 'Créer le brouillon Vinted' });
      send.addEventListener('click', () => enqueue(() => sendToVinted(a)));
      actions.append(send);
    }
  }
  body.append(actions);
  c.append(body);
  return c;
}

// ---------- Rendu ----------
function updateStats() {
  const pending = articles.filter((a) => a.status === 'pending' || a.status === 'error').length;
  const ready = articles.filter((a) => a.draftId).length;
  const value = articles.reduce((s, a) => s + (a.data?.prix || 0), 0);
  // les compteurs du haut sont gérés par ship.js (données Vinted)

  const btn = $('#analyzeAll');
  btn.disabled = running || !pending;
  if (!running) btn.textContent = pending ? `✦ Analyser ${pending} article${pending > 1 ? 's' : ''} en attente` : 'Aucun article en attente';
}

function matches(a) {
  const st = stateOf(a);
  if (filter === 'all') return true;
  if (filter === 'pending') return st === 'pending' || st === 'error' || st === 'loading';
  if (filter === 'done') return st === 'done' || st === 'drafterr' || st === 'sending';
  return st === filter;
}

function render() {
  const list = $('#list');
  list.replaceChildren();
  const shown = articles.filter(matches);
  if (!articles.length) {
    list.append(el('div', { className: 'empty' }, el('b', { textContent: 'Aucun article pour le moment' }), 'Dépose les photos de ton premier article ci-dessus.'));
  } else if (!shown.length) {
    list.append(el('div', { className: 'empty', textContent: 'Rien dans ce filtre.' }));
  }
  shown.forEach((a) => list.append(card(a)));
  updateStats();
}

load().then(() => { setTimeout(() => syncSku(true), 1500); setTimeout(consumeMobileInbox, 800); });

// ---------- Appli mobile : articles envoyés depuis l'iPhone ----------
async function reportMobile(a, patch) {
  if (!a.mobileJobId) return;
  const { mobileResults = {} } = await chrome.storage.local.get('mobileResults');
  mobileResults[a.mobileJobId] = { ...(mobileResults[a.mobileJobId] || {}), ...patch, updatedAt: Date.now() };
  const keys = Object.keys(mobileResults); if (keys.length > 200) keys.slice(0, keys.length - 200).forEach((k) => delete mobileResults[k]);
  await chrome.storage.local.set({ mobileResults });
}
let consuming = false;
async function consumeMobileInbox() {
  if (consuming) return; consuming = true;
  try {
    const { mobileInbox = [] } = await chrome.storage.local.get('mobileInbox');
    if (!mobileInbox.length) return;
    await chrome.storage.local.set({ mobileInbox: [] });
    for (const it of mobileInbox) {
      if (articles.some((a) => a.mobileJobId === it.jobId)) continue;
      const a = { id: crypto.randomUUID(), photos: it.photos, status: 'pending', sku: null, data: null, open: false, mobileJobId: it.jobId };
      a.photos = await enhanceList(it.photos, a);
      articles.unshift(a);
      await saveArticles(); render();
      await reportMobile(a, { status: 'pc' });
      if (settings.apiKey) enqueue(() => analyze(a));
      else reportMobile(a, { status: 'error', error: 'Clé API manquante dans Nova Resell (PC)' });
    }
    toast(`${mobileInbox.length} article(s) reçu(s) de l'iPhone`);
  } finally { consuming = false; }
}
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.mobileInbox?.newValue?.length) consumeMobileInbox(); });
setInterval(() => chrome.storage.local.set({ panelAlive: Date.now() }).catch(() => {}), 10000);
chrome.storage.local.set({ panelAlive: Date.now() }).catch(() => {});

// Barre « prix du marché » : fourchette 25–75 % et position de ton prix
function marketBar(m, prix) {
  const lo = Math.min(m.min, prix || m.min), hi = Math.max(m.max, prix || m.max), w = Math.max(1, hi - lo);
  const pos = (x) => Math.min(100, Math.max(0, ((x - lo) / w) * 100));
  const where = !prix ? '' : prix > m.p75 ? 'au-dessus du marché' : prix < m.p25 ? 'en dessous du marché' : prix >= m.med ? 'dans le haut du marché' : 'dans le bas du marché';
  return el('div', { className: 'mkt' },
    el('div', {}, el('b', { textContent: `📊 Prix du marché : ${m.p25} – ${m.p75} €` }), document.createTextNode(` · médiane ${m.med} € · ${m.n} annonces`)),
    el('div', { className: 'mkt-bar' }, el('i', { style: `left:${pos(m.p25)}%;width:${pos(m.p75) - pos(m.p25)}%` }), prix ? el('b', { style: `left:calc(${pos(prix)}% - 1px)`, title: 'Ton prix' }) : ''),
    el('span', { className: 'hint', textContent: `${m.min} € → ${m.max} €${where ? ' · ton prix (' + prix + ' €) est ' + where : ''}` }));
}

$('#photoEnhance').addEventListener('change', () => { settings.photoEnhance = $('#photoEnhance').checked; saveSettings(); toast(settings.photoEnhance ? '✨ Les prochaines photos seront améliorées' : 'Amélioration des photos désactivée'); });
chrome.storage.local.get('settings').then(({ settings: st = {} }) => { $('#photoEnhance').checked = !!st.photoEnhance; });
