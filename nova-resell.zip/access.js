// ===== Nova Resell – droit d'accès : essai 7 jours, code bêta, abonnement (vérifié par le serveur Nova) =====
// Partagé panneau / arrière-plan. Le résultat est gardé 6 h ; sans réseau, on garde le dernier état connu.
const NovaAccess = {
  async cached() { return (await chrome.storage.local.get('novaAccess')).novaAccess || null; },
  async refresh() {
    try {
      const r = await NovaCloud.rest('POST', 'rpc/nova_access', {});
      const a = { ...r, checkedAt: Date.now() };
      await chrome.storage.local.set({ novaAccess: a });
      return a;
    } catch (e) {
      if (/Non connecté|session/i.test(e.message)) { const a = { active: false, reason: 'login', checkedAt: Date.now() }; await chrome.storage.local.set({ novaAccess: a }); return a; }
      const old = await this.cached();
      // pas de réseau / serveur indisponible : on n'empêche pas de travailler (nouvel essai dans 10 min)
      const a = old ? { ...old, checkedAt: Date.now() - 6 * 3600e3 + 600e3 } : { active: true, offline: true, checkedAt: Date.now() - 6 * 3600e3 + 600e3 };
      await chrome.storage.local.set({ novaAccess: a });
      return a;
    }
  },
  async state() { const a = await this.cached(); return !a || Date.now() - (a.checkedAt || 0) > 6 * 3600e3 ? this.refresh() : a; },
  async ok() {
    const a = await this.state();
    if (!a?.active) return false;
    if (a.plan === 'trial' && a.trial_ends && Date.parse(a.trial_ends) < Date.now()) return false;
    return true;
  },
  async redeem(code) {
    const r = await NovaCloud.rest('POST', 'rpc/nova_redeem', { p_code: String(code || '').trim() });
    const a = { ...r, checkedAt: Date.now() };
    await chrome.storage.local.set({ novaAccess: a });
    return a;
  },
  daysLeft(a) { return a?.trial_ends ? Math.max(0, Math.ceil((Date.parse(a.trial_ends) - Date.now()) / 864e5)) : 0; },
};
