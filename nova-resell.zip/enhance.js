// ===== Nova Resell – amélioration automatique des photos (lumière, couleurs, lissage, netteté) =====
// Traitement local et gratuit : ne change ni la forme ni la couleur réelle du vêtement, corrige seulement la prise de vue.
async function enhancePhoto(dataUrl) {
  const img = await new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = ko; i.src = dataUrl; });
  const w = img.naturalWidth, h = img.naturalHeight;
  const cv = new OffscreenCanvas(w, h), cx = cv.getContext('2d');
  cx.drawImage(img, 0, 0);
  const id = cx.getImageData(0, 0, w, h), d = id.data, n = w * h;
  // 1. analyse : histogramme de luminosité + moyenne des couleurs
  const hist = new Uint32Array(256); let sr = 0, sg = 0, sb = 0, cnt = 0;
  for (let i = 0; i < d.length; i += 16) {
    const r = d[i], g = d[i + 1], b = d[i + 2], l = (r * 77 + g * 150 + b * 29) >> 8;
    hist[l]++; if (l > 20 && l < 235) { sr += r; sg += g; sb += b; cnt++; }
  }
  const tot = hist.reduce((a, b) => a + b, 0), pct = (p) => { let s = 0; for (let k = 0; k < 256; k++) { s += hist[k]; if (s >= tot * p) return k; } return 255; };
  const lo = Math.min(pct(0.005), 40), hi = Math.max(pct(0.995), 200);
  let mean = 0; for (let k = 0; k < 256; k++) mean += k * hist[k]; mean /= tot * 255;
  // balance des blancs douce (moitié du « monde gris »), gains limités pour ne pas trahir la couleur du vêtement
  const avg = cnt ? (sr + sg + sb) / (3 * cnt) : 1;
  const gain = (c) => Math.min(1.12, Math.max(0.9, 1 + ((cnt ? avg / (c / cnt) : 1) - 1) * 0.5));
  const gr = gain(sr), gg = gain(sg), gb = gain(sb);
  // exposition : photo sombre → on éclaircit (gamma)
  const stretched = (mean * 255 - lo) / Math.max(1, hi - lo);
  const gamma = stretched < 0.45 ? Math.max(0.65, Math.log(0.5) / Math.log(Math.max(0.05, stretched))) : 1;
  const lut = new Uint8ClampedArray(256);
  for (let k = 0; k < 256; k++) lut[k] = 255 * Math.pow(Math.min(1, Math.max(0, (k - lo) / Math.max(1, hi - lo))), gamma);
  const out = new Uint8ClampedArray(d.length);
  for (let i = 0; i < d.length; i += 4) {
    let r = lut[Math.min(255, d[i] * gr) | 0], g = lut[Math.min(255, d[i + 1] * gg) | 0], b = lut[Math.min(255, d[i + 2] * gb) | 0];
    const l = (r + g + b) / 3; // couleurs un peu plus vives (+8 %)
    out[i] = l + (r - l) * 1.08; out[i + 1] = l + (g - l) * 1.08; out[i + 2] = l + (b - l) * 1.08; out[i + 3] = 255;
  }
  // 2. lissage qui garde les contours (moyenne des voisins proches en couleur) puis netteté douce
  const sm = new Uint8ClampedArray(out);
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const o = (y * w + x) * 4;
    for (let c = 0; c < 3; c++) {
      const v = out[o + c]; let s = 0, k = 0;
      for (let dy = -w * 4; dy <= w * 4; dy += w * 4) for (let dx = -4; dx <= 4; dx += 4) { const u = out[o + dy + dx + c]; if (Math.abs(u - v) < 14) { s += u; k++; } }
      sm[o + c] = s / k;
    }
  }
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const o = (y * w + x) * 4;
    for (let c = 0; c < 3; c++) {
      const blur = (sm[o + c] * 4 + sm[o - 4 + c] + sm[o + 4 + c] + sm[o - w * 4 + c] + sm[o + w * 4 + c]) / 8;
      d[o + c] = sm[o + c] + (sm[o + c] - blur) * 0.6;
    }
  }
  cx.putImageData(id, 0, 0);
  const blob = await cv.convertToBlob({ type: 'image/jpeg', quality: 0.9 });
  return new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(blob); });
}

// Améliore une liste si l'option est cochée ; garde l'original pour la comparaison avant/après
async function enhanceList(photos, a) {
  if (!settings.photoEnhance) return photos;
  a.orig = a.orig || {};
  const res = [];
  for (const p of photos) { try { const e = await enhancePhoto(p); a.orig[e] = p; res.push(e); } catch { res.push(p); } }
  return res;
}

// Fenêtre avant / après avec curseur
function openCompare(a, p) {
  const orig = a.orig?.[p]; if (!orig) return;
  const after = el('img', { src: p, alt: 'Après' }), before = el('img', { src: orig, alt: 'Avant' });
  const clip = el('div', { className: 'cmp-before' }, before);
  const range = el('input', { type: 'range', min: 0, max: 100, value: 50 });
  const line = el('i', { className: 'cmp-line' });
  const set = () => { before.style.width = (after.getBoundingClientRect().width || 500) + 'px'; clip.style.width = range.value + '%'; line.style.left = range.value + '%'; };
  range.addEventListener('input', set); after.addEventListener('load', set); set();
  const keep = el('button', { className: 'btn ghost', textContent: "Garder l'original" });
  const close = el('button', { className: 'btn primary', textContent: "Garder l'amélioration" });
  const box = el('div', { className: 'cmp-modal' }, el('div', { className: 'cmp-card' },
    el('div', { className: 'cmp-head' }, el('b', { textContent: '✨ Avant / après' }), el('span', { className: 'hint', textContent: 'Glisse le curseur : à gauche la photo d’origine, à droite la photo améliorée' })),
    el('div', { className: 'cmp-view' }, after, clip, line, el('span', { className: 'cmp-tag l', textContent: 'Avant' }), el('span', { className: 'cmp-tag r', textContent: 'Après' })),
    range, el('div', { className: 'actions' }, keep, close)));
  const shut = () => box.remove();
  close.addEventListener('click', shut);
  box.addEventListener('click', (e) => { if (e.target === box) shut(); });
  keep.addEventListener('click', async () => {
    const i = a.photos.indexOf(p); if (i >= 0) a.photos[i] = orig;
    delete a.orig[p]; a.photosDirty = true; await saveArticles(); render(); if (typeof scheduleSync === 'function') scheduleSync(a); shut();
  });
  document.body.append(box);
}

// Brouillon Vinted : améliore ses photos, montre avant / après côte à côte, puis remplace les photos du brouillon
async function openDraftEnhance(i) {
  const grid = el('div', { className: 'de-grid' }, el('p', { className: 'hint', textContent: '⏳ Récupération et amélioration des photos…' }));
  const apply = el('button', { className: 'btn primary', textContent: '✅ Appliquer au brouillon', disabled: true });
  const close = el('button', { className: 'btn ghost', textContent: 'Annuler' });
  const box = el('div', { className: 'cmp-modal' }, el('div', { className: 'cmp-card de-card' },
    el('div', { className: 'cmp-head' }, el('b', { textContent: '✨ ' + i.title }), el('span', { className: 'hint', textContent: 'À gauche la photo actuelle, à droite la photo améliorée. Décoche celles que tu ne veux pas changer.' })),
    grid, el('div', { className: 'actions' }, close, apply)));
  close.addEventListener('click', () => box.remove());
  document.body.append(box);
  let pairs = [];
  try {
    const orig = await vinted('draftPhotos', { id: i.id, _t: i.title });
    if (!orig.length) throw new Error('Ce brouillon n’a pas de photo');
    grid.replaceChildren();
    for (const [k, o] of orig.entries()) {
      const e = await enhancePhoto(o);
      const keep = el('input', { type: 'checkbox', checked: true });
      pairs.push({ o, e, keep });
      grid.append(el('div', { className: 'de-pair' },
        el('figure', {}, el('img', { src: o, alt: '' }), el('figcaption', { textContent: `Photo ${k + 1} · avant` })),
        el('figure', {}, el('img', { src: e, alt: '' }), el('figcaption', { textContent: 'après ✨' })),
        el('label', { className: 'check' }, keep, document.createTextNode(' Utiliser la version améliorée'))));
    }
    apply.disabled = false;
  } catch (err) { grid.replaceChildren(el('p', { className: 'alert err', textContent: 'Impossible : ' + err.message })); return; }
  apply.addEventListener('click', async () => {
    const photos = pairs.map((p) => (p.keep.checked ? p.e : p.o));
    if (pairs.every((p) => !p.keep.checked)) return box.remove();
    apply.disabled = true; apply.textContent = '⏳ Envoi sur Vinted…';
    try {
      await vinted('draftSetPhotos', { id: i.id, photos, _t: i.title });
      toast('✨ Photos du brouillon mises à jour'); box.remove();
      if (typeof logActivity === 'function') logActivity({ cat: 'draft', icon: '✨', title: 'Photos améliorées', detail: i.title });
      if (typeof loadDrafts === 'function') loadDrafts();
    } catch (err) { apply.disabled = false; apply.textContent = '✅ Appliquer au brouillon'; toast('Échec : ' + err.message); }
  });
}
