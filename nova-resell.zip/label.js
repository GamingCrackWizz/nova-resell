// ===== Nova Resell – bordereaux : SKU retrouvé + bande SKU sur l'étiquette (partagé panneau / arrière-plan) =====
const normTitle = (t) => String(t || '').toLowerCase().replace(/\(#?p\d+\)/g, '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();

// Index des SKU : annonces créées par Nova (id → SKU), titres avec SKU, et ton fichier Excel
async function skuIndexLoad() {
  const { skuIndex = {}, excelIndex = {} } = await chrome.storage.local.get(['skuIndex', 'excelIndex']);
  return { items: skuIndex.items || {}, titles: { ...(excelIndex.titles || {}), ...(skuIndex.titles || {}) } };
}
async function skuIndexAdd(entries) {
  const { skuIndex = {} } = await chrome.storage.local.get('skuIndex');
  const items = skuIndex.items || {}, titles = skuIndex.titles || {};
  for (const e of entries) { if (!e.sku) continue; if (e.id) items[e.id] = e.sku; if (e.title) titles[normTitle(e.title)] = e.sku; }
  const trim = (o) => Object.fromEntries(Object.entries(o).slice(-3000));
  await chrome.storage.local.set({ skuIndex: { items: trim(items), titles: trim(titles) } });
}
function resolveSkus(o, idx) {
  if (o.skus?.length) return o.skus;
  // SKU écrit dans le titre de l'annonce : « (#P12) », « #P12 », « (P12) »
  const inTitle = [...new Set([...(o.itemTitles || []), o.title].flatMap((t) => [...String(t || '').matchAll(/(?:#\s*|\(\s*#?\s*)P\s*(\d+)\b/gi)].map((m) => 'P' + Number(m[1]))))];
  if (inTitle.length) return inTitle;
  const out = new Set();
  for (const id of o.itemIds || []) if (idx?.items?.[id]) out.add(idx.items[id]);
  for (const t of [...(o.itemTitles || []), o.title]) { const k = idx?.titles?.[normTitle(t)]; if (k) out.add(k); }
  return [...out].map((s) => String(s).replace(/^#/, '').toUpperCase());
}
// Sur le bordereau : uniquement le SKU (pris dans le titre de l'annonce), jamais le nom du produit
function labelText(o, idx) {
  const skus = resolveSkus(o, idx);
  return skus.length ? skus.join(' + ') : 'SANS SKU';
}

async function labelDocCreate() {
  const { PDFDocument, StandardFonts } = PDFLib;
  const pdf = await PDFDocument.create();
  return { pdf, font: await pdf.embedFont(StandardFonts.HelveticaBold) };
}
// Ajoute le bordereau d'une vente (avec sa bande SKU) au document
async function labelAppend(doc, o, getUrl, { skuPos = 'top', idx, crop = true, orient = 'portrait' } = {}) {
  const { PDFDocument, rgb, degrees } = PDFLib;
  const url = await getUrl();
  const res = await fetch(url);
  if (!res.ok) throw new Error('téléchargement impossible (' + res.status + ')');
  const type = res.headers.get('content-type') || '';
  const bytes = await res.arrayBuffer();
  let pages = [];
  if (type.includes('pdf') || new TextDecoder().decode(new Uint8Array(bytes.slice(0, 5))) === '%PDF-') {
    const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
    // recadrage sur l'étiquette seule (sans les consignes ni le blanc de la page A4)
    let boxes = null;
    if (crop !== false && typeof globalThis.novaLabelCrop === 'function') { try { boxes = await globalThis.novaLabelCrop(bytes); } catch { boxes = null; } }
    pages = await doc.pdf.copyPages(src, src.getPageIndices());
    pages.forEach((p, k) => {
      const b = boxes?.[k];
      if (b && b.w > 50 && b.h > 50) { p.setMediaBox(b.x, b.y, b.w, b.h); p.setCropBox(b.x, b.y, b.w, b.h); p.setTrimBox(b.x, b.y, b.w, b.h); p.setBleedBox(b.x, b.y, b.w, b.h); }
      doc.pdf.addPage(p);
    });
  } else {
    const img = type.includes('png') ? await doc.pdf.embedPng(bytes) : await doc.pdf.embedJpg(bytes);
    const p = doc.pdf.addPage([595, 842]);
    const sc = Math.min(555 / img.width, 760 / img.height);
    p.drawImage(img, { x: (595 - img.width * sc) / 2, y: 842 - 60 - img.height * sc, width: img.width * sc, height: img.height * sc });
    pages = [p];
  }
  const text = labelText(o, idx);
  for (const p of pages) {
    // l'imprimante imprime en vertical : une étiquette plus large que haute est tournée pour remplir la feuille
    const { width, height } = p.getMediaBox(); const rot = ((p.getRotation().angle % 360) + 360) % 360;
    const wide = (rot === 90 || rot === 270) ? height > width : width > height;
    if ((orient || 'portrait') === 'portrait' ? wide : !wide) p.setRotation(degrees((rot + 90) % 360));
    // puis le SKU, en haut de la feuille telle qu'elle sort de l'imprimante
    stampSku(p, text, doc.font, rgb, degrees, skuPos);
  }
  return true;
}

// Ajoute une bande avec le SKU AU-DESSUS (ou en dessous) du bordereau, sans rien masquer du bordereau
function stampSku(page, text, font, rgb, degrees, skuPos = 'top') {
  const { x: bx, y: by, width, height } = page.getMediaBox();
  const rot = ((page.getRotation().angle % 360) + 360) % 360;
  const side = rot === 90 || rot === 270;
  const span = side ? height : width;               // largeur visible de la bande
  let size = Math.max(14, Math.min(36, span / 9));
  while (font.widthOfTextAtSize(text, size) > span - 30 && size > 8) size -= 1;
  const w = font.widthOfTextAtSize(text, size);
  const band = size + 22;
  const top = (skuPos || 'top') === 'top';
  const setBox = (x, y, w2, h2) => { page.setMediaBox(x, y, w2, h2); page.setCropBox(x, y, w2, h2); page.setTrimBox(x, y, w2, h2); page.setBleedBox(x, y, w2, h2); };
  if (!side) {
    const y0 = top ? by + height : by - band;
    setBox(bx, top ? by : by - band, width, height + band);
    page.drawRectangle({ x: bx + (width - w) / 2 - 12, y: y0 + 5, width: w + 24, height: band - 10, color: rgb(1, 1, 1), borderColor: rgb(0, 0, 0), borderWidth: 2 });
    page.drawText(text, { x: bx + (width - w) / 2, y: y0 + 5 + (band - 10 - size) / 2 + size * 0.22, size, font, color: rgb(0, 0, 0) });
  } else {
    // page affichée tournée : la bande « haut » visible correspond au bord gauche (90) ou droit (270)
    const right = (rot === 270) === top; // tourné de 90° : le haut de la feuille = le bord gauche de la page
    const x0 = right ? bx + width : bx - band;
    setBox(right ? bx : bx - band, by, width + band, height);
    const ang = rot === 90 ? 90 : 270;
    page.drawRectangle({ x: x0 + 5, y: by + (height - w) / 2 - 12, width: band - 10, height: w + 24, color: rgb(1, 1, 1), borderColor: rgb(0, 0, 0), borderWidth: 2 });
    const tx = ang === 90 ? x0 + 5 + (band - 10) / 2 + size * 0.35 : x0 + 5 + (band - 10) / 2 - size * 0.35;
    const ty = ang === 90 ? by + (height - w) / 2 : by + (height + w) / 2;
    page.drawText(text, { x: tx, y: ty, size, font, color: rgb(0, 0, 0), rotate: degrees(ang) });
  }
}

