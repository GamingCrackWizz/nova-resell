// ===== Nova Resell – avis reçus (onglet Réponses) =====
(() => {
  const sel = (id) => document.getElementById(id);
  let list = [], loaded = false; const busy = new Set();
  const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
  async function load() {
    stateMsg(sel('reviewList'), 'Chargement des avis…');
    try { list = await vinted('feedbacks', { pages: 2 }); loaded = true; render(); }
    catch (e) { stateMsg(sel('reviewList'), 'Impossible de charger les avis', e.message); }
  }
  function render() {
    if (!loaded) return;
    const todo = list.filter((f) => f.canComment && !f.replied);
    sel('reviewCount').textContent = todo.length || '';
    sel('reviewAll').hidden = !todo.some(reviewAutoOk);
    sel('reviewAll').textContent = `Répondre aux ${todo.filter(reviewAutoOk).length} avis 4-5 ★`;
    if (!todo.length) { sel('reviewList').replaceChildren(el('p', { className: 'hint', textContent: '✅ Tu as répondu à tous tes avis.' })); return; }
    sel('reviewList').replaceChildren(...todo.slice(0, 25).map((f) => {
      const go = el('button', { className: 'btn' + (f.rating >= 4 ? ' primary' : ''), textContent: busy.has(f.id) ? '…' : 'Répondre', disabled: busy.has(f.id) });
      go.addEventListener('click', () => reply(f, true));
      return el('div', { className: 'row-item' },
        el('div', { className: 'meta' }, el('div', { className: 'title' }, `@${f.author} `, el('span', { className: 'stars' + (f.rating < 4 ? ' low' : ''), textContent: stars(f.rating) })),
          el('div', { className: 'sub', textContent: `« ${f.text.slice(0, 120)} » · ${timeAgo(f.date)}` })),
        el('div', { className: 'row-actions' }, go));
    }));
  }
  async function reply(f, ask) {
    let comment = reviewReply(settings, f);
    if (ask) { const t = prompt(`Réponse publique sous l'avis de @${f.author} :`, comment); if (t === null) return; comment = t.trim(); if (!comment) return; }
    busy.add(f.id); render();
    try { await vinted('feedbackReply', { id: f.id, comment, _t: `avis ${f.rating}★`, _who: f.author }); f.replied = true; toast(`Réponse publiée sous l'avis de @${f.author} ✓`); return true; }
    catch (e) { toast(`@${f.author} : ${e.message}`); return false; }
    finally { busy.delete(f.id); render(); }
  }
  sel('reviewReload').addEventListener('click', load);
  sel('reviewAll').addEventListener('click', async () => {
    const todo = list.filter(reviewAutoOk);
    if (!confirm(`Publier une réponse sous ${todo.length} avis (4-5 ★) ?`)) return;
    sel('reviewAll').disabled = true;
    for (const f of todo) { await reply(f, false); await sleep(4000 + Math.random() * 3000); }
    sel('reviewAll').disabled = false;
  });
  sel('reviewTemplates').addEventListener('change', () => { settings.reviewTemplates = sel('reviewTemplates').value; saveSettings(); });
  sel('reviewAuto').addEventListener('change', async () => {
    if (sel('reviewAuto').checked && !confirm('Répondre automatiquement (sans validation) aux nouveaux avis 4 et 5 ★ ?')) { sel('reviewAuto').checked = false; return; }
    settings.reviewAuto = sel('reviewAuto').checked;
    if (settings.reviewAuto) settings.reviewAutoSince = Date.now() - 7 * 864e5; // les avis de la dernière semaine aussi
    await saveSettings();
    if (settings.reviewAuto) chrome.runtime.sendMessage({ va: 'reviewNow' }).catch(() => {});
    toast(settings.reviewAuto ? 'Réponses automatiques aux avis activées' : 'Réponses automatiques aux avis désactivées');
  });
  sel('quickBar').addEventListener('change', () => { settings.quickBar = sel('quickBar').checked; saveSettings(); toast(settings.quickBar ? 'Bulles affichées dans Vinted' : 'Bulles retirées de Vinted'); });
  chrome.storage.local.get('settings').then(({ settings: st = {} }) => {
    sel('quickBar').checked = !!st.quickBar;
    sel('reviewAuto').checked = !!st.reviewAuto;
    sel('reviewTemplates').value = st.reviewTemplates || REVIEW_TEMPLATES.join('\n\n');
  });
  document.querySelector('.tab[data-tab=reponses]')?.addEventListener('click', () => { if (!loaded) load(); });
})();
