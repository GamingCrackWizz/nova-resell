// ===== Nova Resell – onglets Republier et Favoris =====
// Utilise $, el, toast, settings, saveSettings définis dans sidepanel.js

const DEFAULT_TEMPLATE = `Bonjour {pseudo} 😊
Merci d'avoir mis en favori mon article {article} !
Je te le propose à {prix_remise} € au lieu de {prix} € ({remise} de remise).
Envoi rapide et soigné, n'hésite pas si tu as une question !`;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const timeAgo = (d) => {
  const s = (Date.now() - new Date(d).getTime()) / 1000;
  if (!isFinite(s)) return '';
  if (s < 3600) return `il y a ${Math.max(1, Math.round(s / 60))} min`;
  if (s < 86400) return `il y a ${Math.round(s / 3600)} h`;
  return `il y a ${Math.round(s / 86400)} j`;
};

// ---------- Onglets ----------
document.querySelectorAll('.tab[data-tab]').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));
function showTab(name) {
  document.querySelectorAll('.tab[data-tab]').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.pane').forEach((p) => (p.hidden = p.id !== 'pane-' + name));
  if (name === 'republier' && !wardrobe.loaded) loadWardrobe();
  if (name === 'favoris' && !favs.loaded) loadFavs();
  if (name === 'brouillons') loadDrafts();
}

// ---------- Connexion à Vinted (via un onglet vinted.fr ouvert) ----------
function waitLoaded(tabId) {
  return new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(f); clearTimeout(t); resolve(); };
    const f = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const t = setTimeout(done, 20000);
    chrome.tabs.onUpdated.addListener(f);
  });
}
async function vintedTab() {
  let [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (!tab) {
    tab = await chrome.tabs.create({ url: 'https://www.vinted.fr/', active: false });
    await waitLoaded(tab.id);
  } else if (tab.status !== 'complete') await waitLoaded(tab.id);
  return tab;
}
async function vinted(action, args = {}) {
  const { _t, _who, ...clean } = args;
  try { const r = await vintedRaw(action, clean); logVintedCall(action, args, null, 'pc'); return r; }
  catch (e) { if (typeof logError === 'function') logError(action, e.message); logVintedCall(action, args, e.message, 'pc'); throw e; }
}
async function vintedRaw(action, args = {}) {
  const tab = await vintedTab();
  const send = () => chrome.tabs.sendMessage(tab.id, { va: action, args });
  let r;
  try { r = await send(); } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['vinted-main.js'], world: 'MAIN' }); await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['vinted.js'] });
    r = await send();
  }
  if (!r) throw new Error('Vinted ne répond pas, recharge la page Vinted');
  if (!r.ok) throw new Error(r.error);
  return r.data;
}

function stateMsg(container, title, text) {
  container.replaceChildren(el('div', { className: 'state-msg' }, el('b', { textContent: title }), text || ''));
}

// =====================================================================
// REPUBLIER
// =====================================================================
const wardrobe = { loaded: false, items: [], selected: new Set(), done: new Map(), running: false, stop: false };

function initRepostOptions() {
  $('#repostMode').value = settings.repostMode || 'publish';
  $('#repostDiscount').value = settings.repostDiscount ?? 0;
  $('#repostDiscountType').value = settings.repostDiscountType || 'pct';
  $('#repostDelay').value = settings.repostDelay ?? 45;
  $('#repostSort').value = settings.repostSort || 'oldest';
  $('#repostShow').value = settings.repostShow || 'due';
  $('#repostAge').value = settings.repostAge ?? 14;
  const save = () => {
    settings.repostShow = $('#repostShow').value;
    settings.repostAge = Math.min(120, Math.max(1, Number($('#repostAge').value) || 14));
    settings.repostMode = $('#repostMode').value;
    settings.repostDiscountType = $('#repostDiscountType').value;
    settings.repostDiscount = Math.min(settings.repostDiscountType === 'eur' ? 500 : 50, Math.max(0, Number($('#repostDiscount').value) || 0));
    settings.repostDelay = Math.min(600, Math.max(10, Number($('#repostDelay').value) || 45));
    settings.repostSort = $('#repostSort').value;
    saveSettings();
    renderWardrobe();
  };
  ['#repostMode', '#repostDiscount', '#repostDiscountType', '#repostDelay', '#repostSort', '#repostShow', '#repostAge'].forEach((s) => $(s).addEventListener('change', save));
}

async function loadWardrobe() {
  const list = $('#repostList');
  stateMsg(list, 'Chargement de tes annonces…');
  try {
    wardrobe.items = await vinted('wardrobe');
    wardrobe.loaded = true;
    skuIndexAdd(wardrobe.items.map((i) => ({ id: i.id, title: i.title, sku: (String(i.title).match(/#\s*(P\d+)/i) || [])[1] })).filter((e) => e.sku)).catch(() => {});
    wardrobe.selected.clear();
    renderWardrobe();
  } catch (e) {
    stateMsg(list, 'Impossible de charger tes annonces', e.message);
  }
}

const newPrice = (p) => repostPrice(settings, p);

const ageDays = (i) => (i.ts ? Math.floor((Date.now() - i.ts) / 86400000) : null);
const isDue = (i) => { const d = ageDays(i); return d !== null && d >= (Number(settings.repostAge) || 14); };
function sortedItems() {
  let it = [...wardrobe.items];
  if ((settings.repostShow || 'due') === 'due') it = it.filter((i) => isDue(i) || wardrobe.done.has(i.id));
  const by = settings.repostSort || 'oldest';
  if (by === 'oldest') it.sort((a, b) => b.rank - a.rank);
  if (by === 'newest') it.sort((a, b) => a.rank - b.rank);
  if (by === 'views') it.sort((a, b) => a.views - b.views);
  if (by === 'favs') it.sort((a, b) => a.favs - b.favs);
  return it;
}

function renderWardrobe() {
  if (!wardrobe.loaded) return;
  const list = $('#repostList');
  if (!wardrobe.items.length) return stateMsg(list, 'Aucune annonce en ligne', 'Les brouillons, articles vendus ou réservés ne sont pas listés.');
  const shown = sortedItems();
  const due = wardrobe.items.filter(isDue).length;
  if (!shown.length) stateMsg(list, 'Rien à republier pour le moment', `Aucune annonce en ligne depuis plus de ${settings.repostAge ?? 14} jours.`);
  else list.replaceChildren(...shown.map(rowItem));
  const tab = document.querySelector('.tab[data-tab=republier]');
  if (tab) tab.replaceChildren(el('i', { className: 'ti', textContent: '🔁' }), el('span', { className: 'tl', textContent: 'Republier' }), due ? el('span', { className: 'count', textContent: due }) : '');
  const n = wardrobe.selected.size;
  $('#repostRun').disabled = wardrobe.running || !n;
  if (!wardrobe.running) $('#repostRun').textContent = n ? `Republier la sélection (${n})` : 'Coche des annonces';
}

function rowItem(i) {
  const status = wardrobe.done.get(i.id);
  const chk = el('input', { type: 'checkbox', checked: wardrobe.selected.has(i.id), disabled: !!status || wardrobe.running });
  chk.addEventListener('change', () => { chk.checked ? wardrobe.selected.add(i.id) : wardrobe.selected.delete(i.id); renderWardrobe(); });

  const np = newPrice(i.price);
  const price = np !== i.price ? el('span', {}, el('s', { textContent: i.price + ' €' }), ' → ', el('b', { textContent: np + ' €' })) : el('b', { textContent: i.price + ' €' });
  const d = ageDays(i);
  const sub = el('div', { className: 'sub' }, price, ` · ❤ ${i.favs} · 👁 ${i.views}`, d !== null ? ` · ${d} j` : '');
  if (!status && isDue(i)) sub.append(el('span', { className: 'tag age', textContent: 'à republier' }));
  if (status) sub.append(el('span', { className: 'tag ' + status.cls, textContent: status.label }));
  else if (i.favs > 0) sub.append(el('span', { className: 'tag warn', textContent: `perd ${i.favs} fav.` }));

  if (status?.retryDelete) {
    const delOld = el('button', { className: 'btn', textContent: "Supprimer l'ancienne" });
    delOld.addEventListener('click', async () => {
      delOld.disabled = true;
      try { await vinted('deleteItem', { id: i.id, _t: i.title }); wardrobe.done.set(i.id, { cls: 'ok', label: 'Republiée ✓' }); toast('Ancienne annonce supprimée'); }
      catch (e) { toast('Erreur : ' + e.message); delOld.disabled = false; return; }
      renderWardrobe();
    });
    return el('div', { className: 'row-item done' }, el('img', { src: i.photo, alt: '' }),
      el('div', { className: 'meta' }, el('div', { className: 'title', textContent: i.title }),
        el('div', { className: 'sub' }, el('span', { className: 'tag warn', textContent: 'Copie publiée, ancienne encore en ligne' }))), delOld);
  }
  const btn = el('button', { className: 'btn', textContent: 'Republier', disabled: !!status || wardrobe.running });
  btn.addEventListener('click', async () => {
    const msg = settings.repostMode === 'draft'
      ? `Créer une copie en brouillon de « ${i.title} » ?`
      : `Republier « ${i.title} » ?\nL'ancienne annonce sera supprimée${i.favs ? ` (et ses ${i.favs} favoris perdus)` : ''}.`;
    if (!confirm(msg)) return;
    btn.disabled = true; btn.textContent = '…';
    await repostOne(i);
    renderWardrobe();
  });

  return el('div', { className: 'row-item' + (status ? ' done' : '') + (wardrobe.selected.has(i.id) ? ' sel' : '') },
    chk, el('img', { src: i.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: i.title }), sub),
    btn);
}

async function repostOne(i) {
  try {
    const r = await vinted('repost', { id: i.id, _t: i.title, price: newPrice(i.price), mode: settings.repostMode || 'publish' });
    if (settings.repostMode === 'draft') wardrobe.done.set(i.id, { cls: 'ok', label: 'Copie en brouillon' });
    else if (r.deleted) wardrobe.done.set(i.id, { cls: 'ok', label: 'Republiée ✓' });
    else wardrobe.done.set(i.id, { cls: 'warn', label: 'Copiée, ancienne gardée', retryDelete: true });
    if (r.warning) toast(r.warning);
    wardrobe.selected.delete(i.id);
    return true;
  } catch (e) {
    wardrobe.done.set(i.id, { cls: 'err', label: 'Erreur' });
    toast('Erreur : ' + e.message);
    return false;
  }
}

$('#repostReload').addEventListener('click', () => { wardrobe.done.clear(); loadWardrobe(); });
$('#repostSelectAll').addEventListener('click', () => {
  const free = sortedItems().filter((i) => !wardrobe.done.has(i.id));
  const all = free.every((i) => wardrobe.selected.has(i.id));
  free.forEach((i) => (all ? wardrobe.selected.delete(i.id) : wardrobe.selected.add(i.id)));
  $('#repostSelectAll').textContent = all ? 'Tout cocher' : 'Tout décocher';
  renderWardrobe();
});
$('#repostStop').addEventListener('click', () => { wardrobe.stop = true; $('#repostStop').textContent = 'Arrêt après celle-ci…'; });

$('#repostRun').addEventListener('click', async () => {
  const todo = sortedItems().filter((i) => wardrobe.selected.has(i.id));
  if (!todo.length) return;
  const favLost = todo.reduce((s, i) => s + i.favs, 0);
  const draft = settings.repostMode === 'draft';
  if (!confirm(`${draft ? 'Copier en brouillon' : 'Republier'} ${todo.length} annonce(s) ?${!draft && favLost ? `\n${favLost} favoris seront perdus.` : ''}\nPause de ~${settings.repostDelay ?? 45} s entre chaque.`)) return;

  wardrobe.running = true; wardrobe.stop = false;
  const prog = $('#repostProgress'), bar = prog.querySelector('.pbar'), txt = prog.querySelector('.ptext');
  prog.hidden = false; $('#repostStop').hidden = false; $('#repostStop').textContent = "■ Arrêter après l'annonce en cours";
  renderWardrobe();
  let ok = 0;
  for (let k = 0; k < todo.length; k++) {
    bar.style.width = (k / todo.length) * 100 + '%';
    txt.textContent = `Annonce ${k + 1} / ${todo.length}`;
    if (await repostOne(todo[k])) ok++;
    renderWardrobe();
    if (wardrobe.stop || k === todo.length - 1) break;
    // pause aléatoire autour de la valeur choisie, pour ne pas agir comme un robot
    const base = Number(settings.repostDelay) || 45;
    let wait = Math.round(base * (0.75 + Math.random() * 0.5));
    while (wait > 0 && !wardrobe.stop) { txt.textContent = `Pause ${wait} s · ${k + 1} / ${todo.length} faites`; await sleep(1000); wait--; }
    if (wardrobe.stop) break;
  }
  bar.style.width = '100%';
  txt.textContent = `${ok} annonce(s) traitée(s)`;
  wardrobe.running = false;
  $('#repostStop').hidden = true;
  setTimeout(() => { prog.hidden = true; bar.style.width = '0'; }, 2500);
  renderWardrobe();
  toast(`${ok} / ${todo.length} annonces ${draft ? 'copiées' : 'republiées'}`);
});

// =====================================================================
// FAVORIS
// =====================================================================
const favs = { loaded: false, list: [], prices: new Map(), contacted: new Set(), selected: new Set(), sending: new Set(), errors: new Map(), running: false, stop: false };

async function initFavOptions() {
  const s = await chrome.storage.local.get('favContacted');
  favs.contacted = new Set(s.favContacted || []);
  $('#favTemplate').value = settings.favTemplate || DEFAULT_TEMPLATE;
  $('#favDiscountType').value = settings.favDiscountType || 'pct';
  $('#favDiscount').value = settings.favDiscount ?? 10;
  $('#favDelay').value = settings.favDelay ?? 30;
  $('#favFilter').value = settings.favFilter || 'todo';
  $('#favOffer').checked = settings.favOffer !== false;
  $('#favUnit').textContent = $('#favDiscountType').value === 'eur' ? '€' : '%';
  $('#favAuto').checked = !!settings.favAuto;
  $('#favDailyCap').value = settings.favDailyCap ?? 40;
  renderAuto();
  const save = () => {
    settings.favTemplate = $('#favTemplate').value;
    settings.favDiscountType = $('#favDiscountType').value;
    settings.favDiscount = Math.max(0, Number($('#favDiscount').value) || 0);
    settings.favDelay = Math.min(600, Math.max(10, Number($('#favDelay').value) || 30));
    settings.favFilter = $('#favFilter').value;
    settings.favOffer = $('#favOffer').checked;
    $('#favUnit').textContent = settings.favDiscountType === 'eur' ? '€' : '%';
    saveSettings();
    renderFavs();
  };
  ['#favTemplate', '#favDiscountType', '#favDiscount', '#favDelay', '#favFilter', '#favOffer'].forEach((s) => $(s).addEventListener('change', save));
}
const favKey = (f) => `${f.itemId}-${f.userId}`;
const saveContacted = () => chrome.storage.local.set({ favContacted: [...favs.contacted] });

async function loadFavs() {
  if (favs.running) return;
  const list = $('#favList');
  stateMsg(list, 'Chargement des favoris…');
  try {
    favs.list = await vinted('favorites');
    wardrobe.items = await vinted('wardrobe'); wardrobe.loaded = true; renderWardrobe();
    favs.prices = new Map(wardrobe.items.map((i) => [i.id, i]));
    favs.loaded = true;
    renderFavs();
  } catch (e) {
    stateMsg(list, 'Impossible de charger les favoris', e.message);
  }
}

function discounted(prix) {
  const v = Number(settings.favDiscount ?? 10) || 0;
  const r = settings.favDiscountType === 'eur' ? prix - v : prix * (1 - v / 100);
  return Math.max(1, Math.round(r));
}
function buildMessage(f) {
  const item = favs.prices.get(f.itemId);
  const prix = item?.price ?? 0;
  const remise = discounted(prix);
  const v = Number(settings.favDiscount ?? 10) || 0;
  const article = (item?.title || f.article).replace(/\s*\(#P\d+\)\s*$/, '');
  return (settings.favTemplate || DEFAULT_TEMPLATE)
    .replaceAll('{pseudo}', f.pseudo)
    .replaceAll('{article}', article)
    .replaceAll('{prix}', prix || '?')
    .replaceAll('{prix_remise}', prix ? remise : '?')
    .replaceAll('{remise}', settings.favDiscountType === 'eur' ? `${v} €` : `${v} %`);
}

function favLists() {
  const seen = new Set();
  const all = favs.list.filter((f) => { const k = favKey(f); if (seen.has(k) || !favs.prices.has(f.itemId)) return false; seen.add(k); return true; });
  const todo = all.filter((f) => !favs.contacted.has(favKey(f)));
  return { all, todo };
}

function renderFavs() {
  if (!favs.loaded) return;
  const list = $('#favList');
  const { all, todo } = favLists();
  favs.selected = new Set([...favs.selected].filter((k) => todo.some((f) => favKey(f) === k)));
  const shown = (settings.favFilter || 'todo') === 'todo' ? todo : all;
  $('#favCount').textContent = `${todo.length} à contacter`;
  const n = favs.selected.size;
  $('#favSendAll').disabled = favs.running || !todo.length;
  if (!favs.running) $('#favSendAll').textContent = n ? `Envoyer à la sélection (${n})` : `Envoyer à tous (${todo.length})`;
  if (!shown.length) { window.renderBundles?.(); return stateMsg(list, 'Personne à contacter', 'Les nouveaux favoris apparaîtront ici.'); }
  list.replaceChildren(...shown.map(favRow));
  window.renderBundles?.();
}

function favRow(f) {
  const k = favKey(f);
  const done = favs.contacted.has(k);
  const sending = favs.sending.has(k);
  const item = favs.prices.get(f.itemId);
  const chk = el('input', { type: 'checkbox', checked: favs.selected.has(k), disabled: done || favs.running });
  chk.addEventListener('change', () => { chk.checked ? favs.selected.add(k) : favs.selected.delete(k); renderFavs(); });

  const go = el('button', { className: 'btn' + (done ? '' : ' primary'), disabled: sending || favs.running, textContent: sending ? '…' : done ? 'Renvoyer' : 'Envoyer' });
  go.addEventListener('click', async () => {
    if (done && !confirm(`Tu as déjà contacté @${f.pseudo}. Renvoyer un message ?`)) return;
    await sendFav(f);
    renderFavs();
  });
  const preview = el('button', { className: 'btn ghost', textContent: 'Aperçu' });
  preview.addEventListener('click', () => alert(buildMessage(f) + (settings.favOffer !== false && item ? `\n\n+ offre Vinted à ${discounted(item.price)} €` : '')));
  const skip = el('button', { className: 'btn ghost', textContent: done ? 'Remettre' : 'Ignorer', disabled: favs.running });
  skip.addEventListener('click', async () => {
    done ? favs.contacted.delete(k) : favs.contacted.add(k);
    await saveContacted();
    renderFavs();
  });

  const sub = el('div', { className: 'sub' }, `${(item?.title || f.article)} · `, item ? el('span', {}, el('s', { textContent: item.price + ' €' }), ' → ', el('b', { textContent: discounted(item.price) + ' €' })) : '', ` · ${timeAgo(f.date)}`);
  if (done) sub.append(el('span', { className: 'tag ok', textContent: 'Contacté ✓' }));
  if (favs.errors.has(k)) sub.append(el('span', { className: 'tag err', textContent: favs.errors.get(k) }));
  return el('div', { className: 'row-item' + (done ? ' done' : '') + (favs.selected.has(k) ? ' sel' : '') },
    chk, el('img', { src: item?.photo || f.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: '@' + f.pseudo }), sub),
    el('div', { className: 'row-actions' }, go, done ? skip : preview, done ? null : skip));
}

async function sendFav(f) {
  const k = favKey(f);
  const item = favs.prices.get(f.itemId);
  favs.sending.add(k); favs.errors.delete(k); renderFavs();
  try {
    const r = await vinted('contactFav', {
      itemId: f.itemId, userId: f.userId, body: buildMessage(f), _t: item?.title || f.article || '', _who: f.pseudo,
      offerPrice: settings.favOffer !== false && item ? discounted(item.price) : null,
    });
    favs.contacted.add(k);
    await saveContacted();
    toast(`Envoyé à @${f.pseudo}${r.offered ? ' (avec offre)' : ''}`);
    return true;
  } catch (e) {
    favs.errors.set(k, 'Erreur');
    toast(`@${f.pseudo} : ${e.message}`);
    return false;
  } finally {
    favs.sending.delete(k);
  }
}

$('#favReload').addEventListener('click', loadFavs);

// ---------- Mode automatique ----------
async function renderAuto() {
  const { favAutoLog = [], favAutoCount = {} } = await chrome.storage.local.get(['favAutoLog', 'favAutoCount']);
  const today = favAutoCount[new Date().toISOString().slice(0, 10)] || 0;
  $('#favAutoStatus').innerHTML = '';
  $('#favAutoStatus').append(settings.favAuto
    ? el('span', { className: 'live' }, el('i'), ` Actif · ${today} envoyé(s) aujourd'hui`)
    : el('span', { textContent: 'Désactivé' }));
  $('#favAutoLog').replaceChildren(...favAutoLog.slice(-4).reverse().map((l) => el('div', { className: l.ok ? 'ok' : 'ko' },
    `${new Date(l.time).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} · `,
    l.pseudo ? `@${l.pseudo} — ${l.ok ? (l.bundle ? `lot proposé à ${l.price} €` : l.offered ? `offre ${l.price} € + message` : 'message envoyé') : 'échec : ' + l.error}` : 'Erreur : ' + l.error)));
}
$('#favAuto').addEventListener('change', async () => {
  if ($('#favAuto').checked && !confirm("Activer l'envoi automatique ?\nChaque nouveau favori recevra ton message" + (settings.favOffer !== false ? ' et une offre' : '') + ' sans validation de ta part.')) { $('#favAuto').checked = false; return; }
  settings.favAuto = $('#favAuto').checked;
  if (settings.favAuto) settings.favAutoSince = Date.now();
  await saveSettings();
  if (settings.favAuto) chrome.runtime.sendMessage({ va: 'autoFavNow' }).catch(() => {});
  renderAuto();
  toast(settings.favAuto ? 'Mode automatique activé' : 'Mode automatique désactivé');
});
$('#favDailyCap').addEventListener('change', () => { settings.favDailyCap = Math.min(200, Math.max(1, Number($('#favDailyCap').value) || 40)); saveSettings(); });
chrome.storage.onChanged.addListener((c) => { if (c.favAutoLog || c.favAutoCount) renderAuto(); if (c.favContacted && favs.loaded) { favs.contacted = new Set(c.favContacted.newValue || []); renderFavs(); } });
$('#favSelectAll').addEventListener('click', () => {
  const { todo } = favLists();
  const all = todo.length && todo.every((f) => favs.selected.has(favKey(f)));
  todo.forEach((f) => (all ? favs.selected.delete(favKey(f)) : favs.selected.add(favKey(f))));
  $('#favSelectAll').textContent = all ? 'Tout cocher' : 'Tout décocher';
  renderFavs();
});
$('#favStop').addEventListener('click', () => { favs.stop = true; $('#favStop').textContent = 'Arrêt après celui-ci…'; });
$('#favSendAll').addEventListener('click', async () => {
  const { todo } = favLists();
  const targets = favs.selected.size ? todo.filter((f) => favs.selected.has(favKey(f))) : todo;
  if (!targets.length) return;
  const delay = Number(settings.favDelay ?? 30);
  if (!confirm(`Envoyer le message${settings.favOffer !== false ? ' + une offre' : ''} à ${targets.length} personne(s) ?\nPause de ~${delay} s entre chaque envoi.`)) return;
  favs.running = true; favs.stop = false;
  const prog = $('#favProgress'), bar = prog.querySelector('.pbar'), txt = prog.querySelector('.ptext');
  prog.hidden = false; $('#favStop').hidden = false; $('#favStop').textContent = "■ Arrêter après l'envoi en cours";
  let ok = 0;
  for (let i = 0; i < targets.length; i++) {
    bar.style.width = (i / targets.length) * 100 + '%';
    txt.textContent = `Envoi ${i + 1} / ${targets.length}`;
    if (await sendFav(targets[i])) ok++;
    favs.selected.delete(favKey(targets[i]));
    renderFavs();
    if (favs.stop || i === targets.length - 1) break;
    let wait = Math.round(delay * (0.75 + Math.random() * 0.5));
    while (wait > 0 && !favs.stop) { txt.textContent = `Pause ${wait} s · ${i + 1} / ${targets.length} envoyés`; await sleep(1000); wait--; }
    if (favs.stop) break;
  }
  bar.style.width = '100%';
  txt.textContent = `${ok} message(s) envoyé(s)`;
  favs.running = false;
  $('#favStop').hidden = true;
  setTimeout(() => { prog.hidden = true; bar.style.width = '0'; }, 2500);
  renderFavs();
});

// =====================================================================
// ENVOI SUR VINTED (brouillon) depuis l'onglet Annonces
// =====================================================================
const norm = (x) => String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const words = (x) => norm(x).split(/[^a-z0-9]+/).filter((w) => w.length >= 2).map((w) => (w.length > 3 ? w.replace(/s$/, '') : w));

async function askClaude(text, maxTokens = 50) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': settings.apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
    body: JSON.stringify({ model: settings.model, max_tokens: maxTokens, messages: [{ role: 'user', content: text }] }),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error?.message || 'Erreur API ' + res.status);
  recordUsage('categorie', settings.model, j.usage);
  return (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
}

let refsCache = null;
async function getRefs() {
  if (!refsCache) refsCache = await vinted('refs');
  return refsCache;
}

// Catégorie : présélection locale puis choix final par Claude
// Synonymes : mots que l'IA ou le vendeur emploie → mots des catégories Vinted
const CAT_SYNONYMS = {
  survetement: ['survetement', 'sport', 'veste', 'sweat'], survet: ['survetement', 'sport', 'veste', 'sweat'], track: ['survetement', 'sport', 'veste'],
  jogging: ['jogging', 'sport', 'pantalon'], zip: ['zip', 'veste', 'sweat'], zippee: ['zip', 'veste', 'sweat'], zippe: ['zip', 'veste', 'sweat'],
  polaire: ['polaire'], doudoune: ['doudoune'], 'coupe-vent': ['coupe', 'vent'], coupevent: ['coupe', 'vent'], windbreaker: ['coupe', 'vent'],
  hoodie: ['capuche', 'sweat'], capuche: ['capuche'], sweat: ['sweat'], pull: ['pull'], gilet: ['cardigan', 'sans', 'manche'], cardigan: ['cardigan'],
  jean: ['jean'], cargo: ['cargo', 'pantalon'], short: ['short'], maillot: ['maillot'], polo: ['polo'], chemise: ['chemise'], 'tee-shirt': ['t-shirt'], tshirt: ['t-shirt'],
};
function catTargetWords(d) {
  const base = words([d.categorie, d.titre, d.type_article].filter(Boolean).join(' '));
  const out = new Set(base);
  base.forEach((w) => (CAT_SYNONYMS[w] || []).forEach((x) => words(x).forEach((y) => out.add(y))));
  return out;
}

async function pickCategory(d, leaves) {
  const root = { Femme: 'Femmes', Homme: 'Hommes', Enfant: 'Enfants' }[d.genre];
  let pool = root ? leaves.filter((l) => l.path.startsWith(root + ' >')) : leaves;
  if (!pool.length) pool = leaves;
  const target = catTargetWords(d);
  const scored = pool.map((l) => {
    const parts = l.path.split(' > ');
    let sc = 0;
    words(l.path).forEach((w) => target.has(w) && (sc += 1));
    words(parts[parts.length - 1]).forEach((w) => target.has(w) && (sc += 2));
    return { ...l, sc };
  }).sort((a, b) => b.sc - a.sc).slice(0, 70);
  const prompt = `Article à vendre sur Vinted :
Titre : ${d.titre}
Type d'article : ${d.type_article || '(voir titre)'}
Catégorie estimée : ${d.categorie}
Genre : ${d.genre}
Matières : ${(d.matieres || []).join(', ') || '?'}

Choisis la catégorie Vinted qui correspond EXACTEMENT au type de vêtement, parmi cette liste (format id : chemin).
Règles :
- Le type de vêtement prime sur tout : une veste de survêtement / veste zippée de sport (type Adidas, Nike, track jacket) va dans « Vêtements de sport et accessoires > Survêtements » ou « Sweats et pulls > Vestes », JAMAIS dans « Vestes de ski et snowboard ».
- Ne choisis une catégorie spécialisée (ski, snowboard, moto, randonnée, militaire, aviateur, danse…) que si l'article est clairement conçu pour cet usage.
- Une polaire → « Vestes polaires » ; une doudoune → « Doudounes » ; un coupe-vent → « Vestes coupe-vent » ; un sweat zippé à capuche → « Pulls à capuche avec zip ».
- Respecte le genre (Hommes / Femmes / Enfants).

${scored.map((l) => `${l.id} : ${l.path}`).join('\n')}

Réponds uniquement par l'id, sans rien d'autre.`;
  let pick = scored[0];
  try {
    const id = Number((await askClaude(prompt, 20)).match(/\d+/)?.[0]);
    const found = scored.find((l) => l.id === id);
    if (found) pick = found;
  } catch { /* on garde la meilleure présélection */ }
  const candidates = [pick, ...scored.filter((l) => l.id !== pick.id)].slice(0, 15).map(({ id, path }) => ({ id, path }));
  return { ...pick, candidates };
}

function matchOption(opts, value) {
  if (!opts?.length || !value) return null;
  const v = norm(value).replace(/\s+/g, '');
  const exact = opts.find((o) => norm(o.t).replace(/\s+/g, '') === v);
  if (exact) return exact;
  const vw = words(value);
  return opts.find((o) => { const ow = words(o.t); return vw.length && vw.every((w) => ow.includes(w)); }) || null;
}

// Résout tous les champs de l'annonce en identifiants Vinted
async function resolveFields(a) {
  const d = a.data;
  const refs = await getRefs();
  const catKey = [d.categorie, d.genre, d.titre].join('|');
  let cat = a.vintedCat;
  if (!cat || (a.vintedCatKey !== catKey && !a.catManual)) {
    const picked = await pickCategory(d, refs.leaves);
    cat = { id: picked.id, path: picked.path };
    a.vintedCat = cat; a.vintedCatKey = catKey; a.vintedCandidates = picked.candidates;
  }
  const attrs = await vinted('attributes', { catalogId: cat.id });
  const warnings = [];
  const size = matchOption(attrs.size, d.taille);
  if (attrs.size?.length && !size) warnings.push('taille « ' + (d.taille || '?') + ' »');
  const cond = matchOption(attrs.condition, d.etat) || matchOption(attrs.condition, 'Très bon état');
  const mats = (d.matieres || []).map((m) => matchOption(attrs.material, m)).filter(Boolean).map((o) => o.id);
  const colors = (d.couleurs || []).map((c) => matchOption(refs.colors, c)).filter(Boolean).map((o) => o.id);
  const code = { petit: 'SMALL', moyen: 'MEDIUM', grand: 'LARGE' }[norm(d.colis)] || 'SMALL';
  const pkg = attrs.packages?.find((p) => p.code === code)?.id ?? { SMALL: 1, MEDIUM: 2, LARGE: 3 }[code];
  const brand = d.marque ? await vinted('brand', { keyword: d.marque }).catch(() => null) : null;
  if (d.marque && !brand) warnings.push('marque « ' + d.marque + ' »');
  return {
    warnings,
    fields: {
      title: d.titre, description: d.description, price: d.prix,
      catalog_id: cat.id, brand_id: brand?.id, brand: brand?.title,
      size_id: size?.id, condition_id: cond?.id, material_ids: mats, color_ids: colors, package_size_id: pkg,
    },
  };
}

// Prix cohérent : prix du marché (annonces similaires) + fourchette conseillée par Vinted + marge de négo
async function coherentPrice(a, f) {
  const [s, m] = await Promise.all([
    vinted('priceSuggestion', { catalog_id: f.catalog_id, brand_id: f.brand_id, condition_id: f.condition_id, size_id: f.size_id }).catch(() => null),
    settings.marketPrice === false ? null : vinted('marketPrice', { catalog_id: f.catalog_id, brand_id: f.brand_id, size_id: f.size_id, condition_id: f.condition_id, text: a.data.titre }).catch(() => null),
  ]);
  const guess = Number(a.data.prix) || 0;
  const r = priceFromMarket(guess, s, m, Number(settings.priceMargin ?? 40) / 100);
  if (!r) return;
  a.market = m || null;
  a.data.prix = r.prix; f.price = r.prix;
  a.data.justification_prix = r.why;
}
// guess = prix proposé par Claude · s = conseil Vinted {min,max} · m = marché {n,p25,med,p75}
function priceFromMarket(guess, s, m, marge = 0.4) {
  const parts = [];
  let lo, hi;
  if (m && m.n >= 6) {
    // vise entre la médiane et le haut de la fourchette : assez visible, avec de la marge pour négocier
    lo = Math.ceil(m.med); hi = Math.max(lo, Math.round(m.p75 * 1.05));
    parts.push(`Marché : ${m.n} annonces similaires (${m.scope}), la moitié entre ${m.p25} et ${m.p75} € (médiane ${m.med} €).`);
    if (s?.max) parts.push(`Vinted conseille ${Math.round(s.min)}–${Math.round(s.max)} €.`);
  } else if (s?.max) {
    lo = Math.ceil(s.max); hi = Math.max(lo, Math.round(s.max * (1 + marge)));
    parts.push(`Vinted conseille ${Math.round(s.min)}–${Math.round(s.max)} € pour cet article.`);
  } else return null;
  const prix = Math.min(hi, Math.max(lo, guess || hi));
  parts.push(`Prix fixé à ${prix} € pour garder une marge de négo.`);
  return { prix, why: parts.join(' ') };
}

async function sendToVinted(a) {
  if (!a.data) return;
  a.draftStatus = 'sending'; a.draftError = null;
  render();
  try {
    const { fields, warnings } = await resolveFields(a);
    await coherentPrice(a, fields);
    const r = await vinted('createDraft', { ...fields, photos: a.photos, _t: fields.title });
    a.draftId = r.id;
    skuIndexAdd([{ id: r.id, sku: a.sku, title: fields.title }]).catch(() => {});
    a.vintedPhotoIds = r.photoIds;
    a.photosDirty = false;
    a.draftCategory = a.vintedCat?.path;
    a.draftWarnings = warnings;
    a.draftStatus = 'done';
    a.syncState = 'ok';
    a.open = false;
    toast(`${a.sku} envoyé en brouillon sur Vinted`);
    if (typeof reportMobile === 'function') reportMobile(a, { status: 'draft', title: a.data.titre, sku: a.sku, price: a.data.prix, draftId: a.draftId, error: null });
  } catch (e) {
    a.draftStatus = 'error';
    a.draftError = e.message;
    if (typeof reportMobile === 'function') reportMobile(a, { status: 'error', error: 'Brouillon Vinted : ' + e.message });
  }
  await saveArticles();
  render();
}

// ---------- Mise à jour automatique du brouillon quand tu modifies l'annonce ----------
const syncTimers = new Map();
function scheduleSync(a) {
  if (!a.draftId) return;
  a.syncState = 'pending';
  clearTimeout(syncTimers.get(a.id));
  syncTimers.set(a.id, setTimeout(() => syncNow(a), 2500));
  const hint = document.querySelector(`[data-id="${a.id}"] .hint[class*="sync-"]`);
  if (hint) { hint.className = 'hint sync-pending'; hint.textContent = "⏳ Modification en attente d'envoi à Vinted…"; }
}
function syncNow(a) {
  clearTimeout(syncTimers.get(a.id));
  enqueue(async () => {
    if (!a.draftId) return;
    a.syncState = 'syncing'; render();
    try {
      const { fields, warnings } = await resolveFields(a);
      const payload = { ...fields, id: a.draftId };
      if (a.photosDirty || !a.vintedPhotoIds?.length) payload.photos = a.photos;
      else payload.photoIds = a.vintedPhotoIds;
      const r = await vinted('updateDraft', payload);
      a.vintedPhotoIds = r.photoIds;
      a.photosDirty = false;
      a.draftWarnings = warnings;
      a.syncState = 'ok'; a.syncError = null;
      toast(`${a.sku} mis à jour sur Vinted`);
    } catch (e) {
      a.syncState = 'error'; a.syncError = e.message;
    }
    await saveArticles();
    render();
  });
}

// =====================================================================
// BROUILLONS : validation et publication
// =====================================================================
const pub = { items: [], selected: new Set(), done: new Map(), running: false, sched: {}, picking: null };

// ---- Planification ----
const fmtWhen = (t) => new Date(t).toLocaleString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const toLocalInput = (t) => { const d = new Date(t - new Date(t).getTimezoneOffset() * 60000); return d.toISOString().slice(0, 16); };
const nextSlot = () => { const d = new Date(Date.now() + 60 * 60000); d.setMinutes(d.getMinutes() < 30 ? 30 : 60, 0, 0); return d.getTime(); };
async function loadSched() { pub.sched = (await chrome.storage.local.get('pubSchedule')).pubSchedule || {}; }
async function setSched(entries) {
  const cur = (await chrome.storage.local.get('pubSchedule')).pubSchedule || {};
  for (const [id, v] of entries) { if (v) cur[id] = v; else delete cur[id]; }
  await chrome.storage.local.set({ pubSchedule: cur });
  pub.sched = cur;
}
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !c.pubSchedule || !document.querySelector('#pane-brouillons:not([hidden])')) { if (c.pubSchedule) pub.sched = c.pubSchedule.newValue || {}; return; }
  const before = pub.sched; pub.sched = c.pubSchedule.newValue || {};
  // un brouillon publié par le planificateur disparaît : on recharge la liste
  if (Object.keys(before).some((id) => !pub.sched[id]) && !pub.running) loadDrafts(); else if (document.querySelector('#pane-brouillons:not([hidden])')) renderDrafts();
});

async function loadDrafts() {
  if (pub.running) return;
  const list = $('#pubList');
  stateMsg(list, 'Chargement de tes brouillons…');
  try {
    await loadSched();
    pub.items = await vinted('drafts');
    pub.selected = new Set([...pub.selected].filter((id) => pub.items.some((i) => i.id === id)));
    const gone = Object.keys(pub.sched).filter((id) => !pub.items.some((i) => String(i.id) === id));
    if (gone.length) await setSched(gone.map((id) => [id, null]));
    renderDrafts();
  } catch (e) {
    stateMsg(list, 'Impossible de charger tes brouillons', e.message);
  }
}

function renderDrafts() {
  const list = $('#pubList');
  const n = pub.selected.size;
  $('#pubRun').disabled = pub.running || !n;
  if (!pub.running) $('#pubRun').textContent = n ? `Publier la sélection (${n})` : 'Coche les brouillons à publier';
  $('#pubPlan').disabled = pub.running || !n;
  const planned = Object.values(pub.sched).filter((x) => !x.failed).sort((a, b) => a.at - b.at);
  $('#pubPlanInfo').textContent = planned.length ? `🕒 ${planned.length} publication(s) planifiée(s) · prochaine ${fmtWhen(planned[0].at)}. Le PC doit être allumé avec Chrome ouvert.` : '';
  const tab = document.querySelector('.tab[data-tab=brouillons]');
  const left = pub.items.filter((i) => !pub.done.has(i.id)).length;
  if (tab) tab.replaceChildren(el('i', { className: 'ti', textContent: '📝' }), el('span', { className: 'tl', textContent: 'Brouillons' }), left ? el('span', { className: 'count', textContent: left }) : '');
  if (!pub.items.length) return stateMsg(list, 'Aucun brouillon', "Ajoute des photos dans l'onglet Annonces : les brouillons arrivent ici.");
  list.replaceChildren(...pub.items.map(draftRow));
}

function draftRow(i) {
  const status = pub.done.get(i.id);
  const chk = el('input', { type: 'checkbox', checked: pub.selected.has(i.id), disabled: !!status || pub.running });
  chk.addEventListener('change', () => { chk.checked ? pub.selected.add(i.id) : pub.selected.delete(i.id); renderDrafts(); });
  const sub = el('div', { className: 'sub' }, el('b', { textContent: i.price + ' €' }), [i.brand, i.size].filter(Boolean).map((x) => ' · ' + x).join(''));
  if (status) sub.append(el('span', { className: 'tag ' + status.cls, textContent: status.label }));
  const sc = pub.sched[i.id];
  if (!status && sc) sub.append(el('span', { className: 'tag ' + (sc.failed ? 'err' : 'plan'), textContent: sc.failed ? 'Planif. échouée : ' + (sc.error || '') : '🕒 ' + fmtWhen(sc.at) }));

  const plan = el('button', { className: 'btn', textContent: sc ? '🕒 Changer l\'heure' : '🕒 Planifier', disabled: !!status || pub.running });
  plan.addEventListener('click', () => { pub.picking = pub.picking === i.id ? null : i.id; renderDrafts(); });
  let picker = null;
  if (pub.picking === i.id && !status) {
    const when = el('input', { type: 'datetime-local', value: toLocalInput(sc && !sc.failed ? sc.at : nextSlot()), min: toLocalInput(Date.now()) });
    const ok = el('button', { className: 'btn primary', textContent: 'Valider' });
    ok.addEventListener('click', async () => {
      const at = new Date(when.value).getTime();
      if (!at || at < Date.now() - 60000) return toast('Choisis une date dans le futur');
      await setSched([[String(i.id), { at, title: i.title }]]); pub.picking = null; renderDrafts();
      logActivity({ cat: 'publish', icon: '🕒', title: 'Publication planifiée le ' + fmtWhen(at), detail: i.title });
      toast('Publication planifiée le ' + fmtWhen(at));
    });
    const cancel = el('button', { className: 'btn ghost', textContent: sc ? 'Annuler la planification' : 'Fermer' });
    cancel.addEventListener('click', async () => { if (sc) { await setSched([[String(i.id), null]]); toast('Planification annulée'); } pub.picking = null; renderDrafts(); });
    picker = el('div', { className: 'plan-picker' }, el('span', { className: 'hint', textContent: 'Publier le' }), when, ok, cancel);
  }

  const edit = el('button', { className: 'btn', textContent: 'Modifier' });
  edit.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/items/${i.id}/edit` }));
  const go = el('button', { className: 'btn primary', textContent: 'Publier', disabled: !!status || pub.running });
  go.addEventListener('click', async () => {
    if (!confirm(`Publier « ${i.title} » à ${i.price} € ?`)) return;
    go.disabled = true; go.textContent = '…';
    await publishOne(i);
    renderDrafts();
  });
  const del = el('button', { className: 'btn ghost danger', textContent: 'Supprimer', disabled: !!status || pub.running });
  del.addEventListener('click', async () => {
    if (!confirm(`Supprimer définitivement le brouillon « ${i.title} » ?`)) return;
    try { await vinted('deleteDraft', { id: i.id, _t: i.title }); pub.items = pub.items.filter((x) => x !== i); pub.selected.delete(i.id); await setSched([[String(i.id), null]]); renderDrafts(); toast('Brouillon supprimé'); }
    catch (e) { toast('Erreur : ' + e.message); }
  });
  return el('div', { className: 'row-item' + (status ? ' done' : '') + (pub.selected.has(i.id) ? ' sel' : '') },
    chk, el('img', { src: i.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: i.title }), sub),
    el('div', { className: 'row-actions' }, status ? null : go, status ? null : plan, edit, status ? null : del),
    picker);
}

async function publishOne(i) {
  try {
    await vinted('publishDraft', { id: i.id, _t: i.title });
    if (pub.sched[i.id]) await setSched([[String(i.id), null]]);
    pub.done.set(i.id, { cls: 'ok', label: 'Publiée ✓' });
    pub.selected.delete(i.id);
    return true;
  } catch (e) {
    pub.done.set(i.id, { cls: 'err', label: 'À compléter' });
    toast(e.message);
    setTimeout(() => { pub.done.delete(i.id); renderDrafts(); }, 8000);
    return false;
  }
}

$('#pubDelay').value = 20;
$('#pubPlan').addEventListener('click', () => {
  const box = $('#pubPlanBox'); box.hidden = !box.hidden;
  if (!box.hidden) { $('#pubPlanGap').value = settings.pubPlanGap || 30; $('#pubPlanStart').value = toLocalInput(nextSlot()); $('#pubPlanStart').min = toLocalInput(Date.now()); }
});
$('#pubPlanCancel').addEventListener('click', () => { $('#pubPlanBox').hidden = true; });
$('#pubPlanGo').addEventListener('click', async () => {
  const start = new Date($('#pubPlanStart').value).getTime();
  const gap = Math.min(24 * 60, Math.max(1, Number($('#pubPlanGap').value) || 30));
  if (!start || start < Date.now() - 60000) return toast('Choisis une date de départ dans le futur');
  const todo = pub.items.filter((i) => pub.selected.has(i.id));
  await setSched(todo.map((i, k) => [String(i.id), { at: start + k * gap * 60000, title: i.title }]));
  settings.pubPlanGap = gap; saveSettings();
  pub.selected.clear(); $('#pubPlanBox').hidden = true; renderDrafts();
  toast(`${todo.length} publication(s) planifiée(s) à partir du ${fmtWhen(start)}`);
  logActivity({ cat: 'publish', icon: '🕒', title: `${todo.length} publication(s) planifiée(s) à partir du ${fmtWhen(start)}`, detail: `une toutes les ${gap} min` });
});
$('#pubReload').addEventListener('click', () => { pub.done.clear(); loadDrafts(); });
$('#pubSelectAll').addEventListener('click', () => {
  const free = pub.items.filter((i) => !pub.done.has(i.id));
  const all = free.length && free.every((i) => pub.selected.has(i.id));
  free.forEach((i) => (all ? pub.selected.delete(i.id) : pub.selected.add(i.id)));
  $('#pubSelectAll').textContent = all ? 'Tout cocher' : 'Tout décocher';
  renderDrafts();
});
$('#pubRun').addEventListener('click', async () => {
  const todo = pub.items.filter((i) => pub.selected.has(i.id));
  if (!todo.length || !confirm(`Publier ${todo.length} annonce(s) sur Vinted ?`)) return;
  settings.pubDelay = Math.min(600, Math.max(5, Number($('#pubDelay').value) || 20));
  saveSettings();
  pub.running = true;
  const prog = $('#pubProgress'), bar = prog.querySelector('.pbar'), txt = prog.querySelector('.ptext');
  prog.hidden = false;
  renderDrafts();
  let ok = 0;
  for (let k = 0; k < todo.length; k++) {
    bar.style.width = (k / todo.length) * 100 + '%';
    txt.textContent = `Publication ${k + 1} / ${todo.length}`;
    if (await publishOne(todo[k])) ok++;
    renderDrafts();
    if (k < todo.length - 1) {
      let wait = Math.round(settings.pubDelay * (0.75 + Math.random() * 0.5));
      while (wait > 0) { txt.textContent = `Pause ${wait} s · ${k + 1} / ${todo.length} faites`; await sleep(1000); wait--; }
    }
  }
  bar.style.width = '100%';
  txt.textContent = `${ok} / ${todo.length} publiée(s)`;
  pub.running = false;
  setTimeout(() => { prog.hidden = true; bar.style.width = '0'; }, 2500);
  renderDrafts();
  toast(`${ok} annonce(s) publiée(s) sur Vinted`);
});

// ---------- Démarrage ----------
(async () => {
  const s = await chrome.storage.local.get('settings');
  Object.assign(settings, s.settings || {});
  initRepostOptions();
  $('#pubDelay').value = settings.pubDelay ?? 20;
  await initFavOptions();
})();
