// ===== Nova Resell – réglages : notifications iPhone + contre-offre intelligente =====
(() => {
  if (/print|worker/.test(location.hash)) return;
  const box = $('#pushKinds');
  async function render() {
    const { settings: st = {}, pushSubs = [] } = await chrome.storage.local.get(['settings', 'pushSubs']);
    $('#phonePush').checked = !!st.phonePush;
    const kinds = st.pushKinds || {};
    box.replaceChildren(...Object.entries(PUSH_KINDS).map(([k, label]) => {
      const i = el('input', { type: 'checkbox', checked: kinds[k] !== false });
      i.addEventListener('change', () => { settings.pushKinds = { ...(settings.pushKinds || {}), [k]: i.checked }; saveSettings(); });
      return el('label', { className: 'check' }, i, document.createTextNode(' ' + label));
    }));
    box.hidden = !st.phonePush;
    $('#pushInfo').textContent = pushSubs.length
      ? `${pushSubs.length} téléphone${pushSubs.length > 1 ? 's' : ''} relié${pushSubs.length > 1 ? 's' : ''} · ${pushSubs.map((s) => s.device).join(', ')}`
      : "Aucun téléphone relié pour l'instant.";
    $('#pushTestBtn').disabled = !pushSubs.length || !st.phonePush;
  }
  $('#phonePush').addEventListener('change', () => { settings.phonePush = $('#phonePush').checked; saveSettings(); render(); });
  $('#pushTestBtn').addEventListener('click', async () => {
    const b = $('#pushTestBtn'); b.disabled = true;
    const r = await chrome.runtime.sendMessage({ va: 'pushTest' }).catch(() => null);
    toast(r?.ok ? '🔔 Notification envoyée sur ton téléphone' : "Échec de l'envoi : réactive les notifications dans l'appli iPhone");
    render();
  });
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && (c.pushSubs || c.settings)) render(); });
  render();

  // Contre-offre intelligente
  $('#aiMinMargin').addEventListener('change', () => { settings.aiMinMargin = Math.min(100, Math.max(0, Number($('#aiMinMargin').value) || 0)); saveSettings(); });
  $('#aiFlex').addEventListener('change', () => { settings.aiFlex = $('#aiFlex').checked; saveSettings(); });
  chrome.storage.local.get('settings').then(({ settings: st = {} }) => { $('#aiMinMargin').value = st.aiMinMargin ?? 5; $('#aiFlex').checked = st.aiFlex !== false; });
})();
