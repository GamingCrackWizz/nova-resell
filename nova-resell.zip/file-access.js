// Petite fenêtre Nova : choix du fichier Excel / autorisation d'accès (le panneau latéral ne peut pas toujours ouvrir l'explorateur)
const q = new URLSearchParams(location.search);
const mode = q.get('mode') === 'grant' ? 'grant' : 'pick';
const want = q.get('perm') === 'read' ? 'read' : 'readwrite';
const $ = (id) => document.getElementById(id);
function idb(m, fn) {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open('va-phone', 1);
    open.onupgradeneeded = () => open.result.createObjectStore('kv');
    open.onsuccess = () => { const tx = open.result.transaction('kv', m); const req = fn(tx.objectStore('kv')); tx.oncomplete = () => resolve(req?.result); tx.onerror = () => reject(tx.error); };
    open.onerror = () => reject(open.error);
  });
}
(async () => {
  if (mode !== 'grant') return;
  const h = await idb('readonly', (s) => s.get('excel')).catch(() => null);
  if (!h) { location.search = '?mode=pick'; return; }
  $('t').textContent = '📗 Autoriser Nova';
  $('d').textContent = `Nova a besoin de ton accord pour ${want === 'read' ? 'lire' : 'mettre à jour'} « ${h.name} ».`;
  $('go').textContent = '✅ Autoriser l’accès';
})();
$('go').addEventListener('click', async () => {
  try {
    if (mode === 'grant') {
      const h = await idb('readonly', (s) => s.get('excel'));
      if ((await h.requestPermission({ mode: want })) !== 'granted') { $('msg').textContent = 'Accès refusé.'; return; }
      await chrome.storage.local.set({ excelGranted: Date.now() });
    } else {
      if (!window.showOpenFilePicker) return $('file').click(); // navigateur sans accès direct aux fichiers : on importe une copie
      const [h] = await window.showOpenFilePicker({ id: 'nova-excel', startIn: 'documents' });
      if (!/\.xls[xm]$/i.test(h.name)) { $('msg').textContent = 'Choisis un fichier Excel (.xlsx).'; return; }
      // on demande tout de suite l'accès en écriture, pour que la synchro n'ait plus rien à demander
      await h.requestPermission({ mode: 'readwrite' }).catch(() => {});
      await idb('readwrite', (s) => s.put(h, 'excel'));
      await chrome.storage.local.set({ excelPicked: Date.now() });
    }
    $('msg').textContent = '✅ C’est bon, tu peux revenir dans Nova.';
    setTimeout(() => window.close(), 700);
  } catch (e) {
    $('msg').textContent = e.name === 'AbortError' ? '' : 'Erreur : ' + e.message;
  }
});

// Import d'une copie (marche dans tous les navigateurs)
$('file').addEventListener('change', async () => {
  const f = $('file').files[0]; if (!f) return;
  if (!/\.xls[xm]$/i.test(f.name)) { $('msg').textContent = /\.xls$/i.test(f.name) ? 'Ancien format .xls : enregistre-le en .xlsx dans Excel.' : 'Choisis un fichier Excel (.xlsx).'; return; }
  const data = await f.arrayBuffer();
  await idb('readwrite', (s) => s.put({ name: f.name, data, at: Date.now() }, 'excelCopy'));
  await chrome.storage.local.set({ excelPicked: { mode: 'copy', at: Date.now() } });
  $('msg').textContent = '✅ C’est bon, tu peux revenir dans Nova.';
  setTimeout(() => window.close(), 700);
});
$('copy').addEventListener('click', (e) => { e.preventDefault(); $('file').click(); });
