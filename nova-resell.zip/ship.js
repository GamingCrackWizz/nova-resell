// ===== Envois : ventes à expédier + impression des bordereaux avec le SKU + compteurs du haut =====

const ship = { loaded: false, list: [], selected: new Set(), printed: new Set() };
const toShip = (o) => o.userStatus === 'waiting' && !o.isReturn && o.shipmentId && (o.shipmentStatus == null || o.shipmentStatus < 300);
const isActiveReturn = (o) => o.userStatus === 'waiting' && o.isReturn;
const fmtDay = (t, opt = { weekday: 'short', day: 'numeric', month: 'short' }) => new Date(t).toLocaleDateString('fr-FR', opt);
function etaText(eta) {
  if (!eta) return '';
  const same = new Date(eta.from).toDateString() === new Date(eta.to).toDateString();
  const days = Math.round((new Date(eta.to).setHours(12) - new Date().setHours(12)) / 86400000);
  const when = same ? fmtDay(eta.from) : `${fmtDay(eta.from)} → ${fmtDay(eta.to)}`;
  const rel = days < 0 ? ' (date dépassée)' : days === 0 ? " (aujourd'hui)" : days === 1 ? ' (demain)' : ` (dans ${days} j)`;
  return when + rel;
}
const RET_TYPE = { snad: 'Article non conforme', damaged: 'Article endommagé', not_received: 'Colis non reçu', counterfeit: 'Contrefaçon signalée' };
const euro = (n) => (Math.round(n * 100) / 100).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' €';

// ---------- Compteurs du haut ----------
async function refreshStats() {
  try {
    const [dash, sales] = await Promise.all([vinted('dashboard'), ship.loaded ? Promise.resolve(ship.list) : vinted('sales', { pages: 2 })]);
    if (!ship.loaded) { ship.list = sales; ship.loaded = true; }
    const now = new Date();
    const month = sales.filter((o) => o.userStatus !== 'failed' && o.date && sameMonth(o.date, now));
    $('#stShip').textContent = sales.filter(toShip).length;
    $('#stDrafts').textContent = dash.drafts;
    $('#stOnline').textContent = dash.online;
    $('#stMonth').textContent = euro(month.reduce((s, o) => s + (o.price || 0), 0)).replace(',00', '');
    updateShipTab();
  } catch { /* Vinted pas ouvert : on garde les tirets */ }
}
function sameMonth(d, now) {
  const t = new Date(d);
  if (!isNaN(t)) return t.getMonth() === now.getMonth() && t.getFullYear() === now.getFullYear();
  // dates de type "14/10/2026" ou "14 octobre 2026"
  const m = String(d).match(/(\d{1,2})[/.](\d{1,2})[/.](\d{4})/);
  return m ? Number(m[2]) - 1 === now.getMonth() && Number(m[3]) === now.getFullYear() : false;
}
document.querySelectorAll('.stat[data-go]').forEach((b) => b.addEventListener('click', () => {
  showTab(b.dataset.go);
  if (b.dataset.go === 'bordereaux') ship.loaded ? renderShip() : loadShip();
}));

function updateShipTab() {
  const nr = ship.list.filter(isActiveReturn).length;
  const sb = $('#segRetours'); if (sb) sb.replaceChildren('↩️ Retours', nr ? el('span', { className: 'count', textContent: nr }) : '');
  const n = ship.list.filter(toShip).length + nr;
  const tab = document.querySelector('.tab[data-tab=bordereaux]');
  if (tab) tab.replaceChildren(el('i', { className: 'ti', textContent: '📦' }), el('span', { className: 'tl', textContent: 'Ventes' }), n ? el('span', { className: 'count', textContent: n }) : '');
}

// ---------- Liste ----------
async function loadShip() {
  const list = $('#shipList');
  stateMsg(list, 'Chargement de tes ventes…');
  try {
    ship.list = await vinted('sales', { pages: 3 });
    ship.idx = await skuIndexLoad();
    ship.buy = (await chrome.storage.local.get('excelIndex')).excelIndex?.buy || {};
    ship.loaded = true;
    const s = await chrome.storage.local.get('printedLabels');
    ship.printed = new Set(s.printedLabels || []);
    renderShip();
    if (!$('#retoursView').hidden) renderReturns();
    if (!$('#suiviView').hidden) renderSuivi();
    refreshStats();
  } catch (e) {
    stateMsg(list, 'Impossible de charger tes ventes', e.message);
  }
}

function shownSales() {
  const f = settings.shipFilter || 'toship';
  if (f === 'toship') return ship.list.filter(toShip);
  if (f === 'progress') return ship.list.filter((o) => o.userStatus === 'waiting');
  return ship.list;
}

function renderShip() {
  const list = $('#shipList');
  const shown = shownSales();
  ship.selected = new Set([...ship.selected].filter((id) => shown.some((o) => o.transactionId === id && o.shipmentId)));
  const n = ship.selected.size;
  $('#shipPrint').disabled = !n;
  $('#shipPrint').textContent = n ? `Imprimer ${n} bordereau${n > 1 ? 'x' : ''}` : 'Coche les ventes à imprimer';
  updateShipTab();
  if (!shown.length) return stateMsg(list, (settings.shipFilter || 'toship') === 'toship' ? 'Rien à expédier 🎉' : 'Aucune vente', 'Les nouvelles ventes apparaîtront ici.');
  list.replaceChildren(...shown.map(shipRow));
}

function shipRow(o) {
  const canPrint = !!o.shipmentId;
  const chk = el('input', { type: 'checkbox', checked: ship.selected.has(o.transactionId), disabled: !canPrint });
  chk.addEventListener('change', () => { chk.checked ? ship.selected.add(o.transactionId) : ship.selected.delete(o.transactionId); renderShip(); });
  const found = resolveSkus(o, ship.idx);
  const cost = found.reduce((a, k) => (a == null || ship.buy?.[k] == null ? null : a + ship.buy[k]), found.length ? 0 : null);
  const skus = el('div', { className: 'skus' }, found.length ? found.map((s) => el('span', { className: 'sku-chip', textContent: s, title: o.skus.length ? 'SKU du titre' : 'SKU retrouvé (annonce créée par Nova ou fichier Excel)' })) : el('span', { className: 'hint', textContent: 'pas de SKU trouvé' }));
  const sub = el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }), ' · ' + (o.statusTitle || '').trim());
  if (cost != null && o.price) sub.append(el('span', { className: 'tag ' + (o.price - cost >= 0 ? 'ok' : 'err'), textContent: `marge ${o.price - cost >= 0 ? '+' : ''}${euro(o.price - cost)}`, title: `Prix d'achat (Excel) : ${euro(cost)}` }));
  if (o.isReturn) sub.append(el('span', { className: 'tag err', textContent: 'retour' }));
  else if (ship.printed.has(o.transactionId)) sub.append(el('span', { className: 'tag ok', textContent: 'imprimé' }));
  else if (toShip(o)) sub.append(el('span', { className: 'tag warn', textContent: 'à expédier' }));
  const eta = !o.isReturn && o.eta && o.userStatus === 'waiting' ? el('div', { className: 'eta', textContent: '🚚 Livraison estimée : ' + etaText(o.eta) }) : null;
  const conv = el('button', { className: 'btn ghost', textContent: 'Conversation' });
  conv.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/inbox/${o.conversationId}` }));
  const one = el('button', { className: 'btn', textContent: 'Imprimer', disabled: !canPrint });
  one.addEventListener('click', () => printLabels([o]));
  return el('div', { className: 'row-item' + (ship.selected.has(o.transactionId) ? ' sel' : '') },
    chk, el('img', { src: o.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }), sub, eta, skus),
    el('div', { className: 'row-actions' }, one, conv));
}

// ---------- Retours ----------
function renderReturns() {
  const list = $('#retList');
  const rets = ship.list.filter(isActiveReturn);
  if (!rets.length) stateMsg(list, 'Aucun retour en cours 🎉', 'Quand un acheteur signale un problème ou demande un retour, la commande apparaît ici.');
  else list.replaceChildren(...rets.map(returnRow));
  const refunds = ship.list.filter((o) => o.userStatus === 'failed' && /rembours/i.test(o.statusTitle || '')).slice(0, 10);
  $('#refundsH').hidden = !refunds.length;
  $('#refundList').replaceChildren(...refunds.map((o) => el('div', { className: 'row-item done' }, el('img', { src: o.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }),
      el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }), ' · ' + (o.statusTitle || '') + (o.date ? ' · ' + fmtDay(o.date, { day: 'numeric', month: 'short' }) : ''))))));
}
function returnRow(o) {
  const r = o.returnInfo || {};
  const sub = el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }),
    r.refund ? ` · remboursement prévu ${euro(r.refund)}` : '',
    el('span', { className: 'tag err', textContent: RET_TYPE[r.type] || 'Retour' }), r.escalated ? el('span', { className: 'tag warn', textContent: 'escaladé à Vinted' }) : '');
  const step = el('div', { className: 'step', textContent: '➜ ' + (o.lastEvent?.title || o.txStatusTitle || o.statusTitle || 'Retour en cours') + (o.lastEvent?.at ? ' · ' + fmtDay(o.lastEvent.at, { day: 'numeric', month: 'short' }) : '') });
  const eta = el('div', { className: 'eta' + (o.eta ? '' : ' muted'), textContent: o.eta ? '📅 Arrivée estimée du colis retour : ' + etaText(o.eta) : "📅 Date d'arrivée : dès que l'acheteur aura expédié le colis" });
  const msg = r.message ? el('details', { className: 'buyer-msg' }, el('summary', { textContent: "Message de l'acheteur" }), el('p', { textContent: r.message })) : null;
  const rs = resolveSkus(o, ship.idx);
  const skus = rs.length ? el('div', { className: 'skus' }, rs.map((s) => el('span', { className: 'sku-chip', textContent: s }))) : null;
  const conv = el('button', { className: 'btn primary', textContent: 'Conversation' });
  conv.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/inbox/${o.conversationId}` }));
  return el('div', { className: 'row-item ret' }, el('img', { src: o.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }), sub, skus, step, eta, msg),
    el('div', { className: 'row-actions' }, conv));
}
$('#retReload').addEventListener('click', async () => { await loadShip(); renderReturns(); });

// ---------- Impression ----------
async function printLabels(orders) {
  const btn = $('#shipPrint');
  btn.disabled = true;
  const idx = await skuIndexLoad();
  const doc = await labelDocCreate();
  let ok = 0;
  for (let k = 0; k < orders.length; k++) {
    const o = orders[k];
    btn.textContent = `Préparation ${k + 1} / ${orders.length}…`;
    try {
      await labelAppend(doc, o, () => vinted('labelUrl', { shipmentId: o.shipmentId }), { skuPos: settings.skuPos, orient: settings.labelOrient, idx });
      ship.printed.add(o.transactionId);
      ok++;
    } catch (e) {
      toast(`${resolveSkus(o, idx).join(', ') || o.title} : ${e.message}`);
    }
  }
  await chrome.storage.local.set({ printedLabels: [...ship.printed].slice(-500) });
  if (ok) {
    const blob = new Blob([await doc.pdf.save()], { type: 'application/pdf' });
    chrome.tabs.create({ url: URL.createObjectURL(blob) });
    toast(`${ok} bordereau(x) prêt(s) : imprime avec Ctrl+P`);
  }
  btn.disabled = false;
  renderShip();
}

// ---------- Boutons ----------
$('#shipReload').addEventListener('click', loadShip);
$('#shipSelectAll').addEventListener('click', () => {
  const free = shownSales().filter((o) => o.shipmentId);
  const all = free.length && free.every((o) => ship.selected.has(o.transactionId));
  free.forEach((o) => (all ? ship.selected.delete(o.transactionId) : ship.selected.add(o.transactionId)));
  $('#shipSelectAll').textContent = all ? 'Tout cocher' : 'Tout décocher';
  renderShip();
});
$('#shipPrint').addEventListener('click', () => printLabels(ship.list.filter((o) => ship.selected.has(o.transactionId))));
['#skuPos', '#shipFilter', '#labelOrient'].forEach((s) => $(s).addEventListener('change', () => {
  settings.skuPos = $('#skuPos').value; settings.labelOrient = $('#labelOrient').value; settings.shipFilter = $('#shipFilter').value; saveSettings(); renderShip();
}));
document.querySelector('.tab[data-tab=bordereaux]').addEventListener('click', () => { if (!ship.loaded) loadShip(); else renderShip(); });

$('#shipAlerts').addEventListener('change', () => { settings.shipAlerts = $('#shipAlerts').checked; saveSettings(); });
(async () => {
  const s = await chrome.storage.local.get('settings');
  $('#shipAlerts').checked = s.settings?.shipAlerts !== false;
  $('#skuPos').value = s.settings?.skuPos || 'top';
  $('#labelOrient').value = s.settings?.labelOrient || 'portrait';
  $('#shipFilter').value = s.settings?.shipFilter || 'toship';
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (tab) refreshStats();
  setInterval(async () => { const [t] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' }); if (t) refreshStats(); }, 5 * 60000);
})();

// Ouvert depuis l'appli mobile (#print) : imprime tous les bordereaux à expédier
if (location.hash === '#print') {
  (async () => {
    showTab('bordereaux'); await loadShip();
    const todo = ship.list.filter(toShip);
    if (todo.length) await printLabels(todo); else toast('Rien à expédier');
  })();
}

// ---------- Suivi des ventes : en route, livrées (clôture), terminées + portefeuille en cours ----------
const isDelivered = (o) => !!o.deliveredAt || /livr[ée]/i.test(o.statusTitle || '') && !/estim/i.test(o.statusTitle || '');
function suiviGroups() {
  const live = ship.list.filter((o) => o.userStatus === 'waiting' && !o.isReturn);
  const toShipL = live.filter(toShip);
  const delivered = live.filter((o) => !toShip(o) && isDelivered(o)).sort((a, b) => (a.closeAt || 0) - (b.closeAt || 0));
  const transit = live.filter((o) => !toShip(o) && !isDelivered(o));
  const done = ship.list.filter((o) => o.userStatus === 'completed' && (o.closedAt || o.deliveredAt)).slice(0, 15);
  return { toShipL, transit, delivered, done };
}
function renderSuivi() {
  const g = suiviGroups();
  const sum = (l) => l.reduce((a, o) => a + (o.price || 0), 0);
  const total = sum(g.toShipL) + sum(g.transit) + sum(g.delivered);
  const next = g.delivered.find((o) => o.closeAt);
  const tile = (icon, label, l, cls) => el('div', { className: 'wt ' + (cls || '') }, el('span', { textContent: `${icon} ${label}` }), el('b', { textContent: euro(sum(l)) }), el('small', { textContent: `${l.length} vente${l.length > 1 ? 's' : ''}` }));
  $('#walletBox').replaceChildren(el('div', { className: 'wallet sheet' },
    el('div', { className: 'wtotal' }, el('span', { textContent: '💰 Portefeuille en cours' }), el('b', { textContent: euro(total) }),
      el('small', { textContent: next ? `Prochain versement : ${euro(next.price)} le ${fmtDay(next.closeAt)}` : 'Argent des ventes pas encore versé dans ton porte-monnaie Vinted' })),
    tile('📦', 'À expédier', g.toShipL, 'warn'), tile('🚚', 'En route', g.transit), tile('📬', 'Livrées', g.delivered, 'ok')));
  const row = (o, line, cls) => {
    const rs = resolveSkus(o, ship.idx);
    const conv = el('button', { className: 'btn ghost', textContent: 'Conversation' });
    conv.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/inbox/${o.conversationId}` }));
    return el('div', { className: 'row-item ' + (cls || '') }, el('img', { src: o.photo, alt: '' }),
      el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }),
        el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }), ...rs.map((k) => el('span', { className: 'sku-chip', textContent: k }))), line),
      el('div', { className: 'row-actions' }, conv));
  };
  const daysTo = (t) => { const d = Math.round((new Date(t).setHours(12) - new Date().setHours(12)) / 864e5); return d <= 0 ? "aujourd'hui" : d === 1 ? 'demain' : `dans ${d} j`; };
  const sec = (title, list, mk) => (list.length ? [el('h3', { className: 'suivi-h', textContent: `${title} (${list.length})` }), el('div', { className: 'rows' }, list.map(mk))] : []);
  const blocks = [
    ...sec('🚚 En route vers l’acheteur', g.transit, (o) => row(o, el('div', { className: 'eta', textContent: o.eta ? '📅 Livraison estimée : ' + etaText(o.eta) : '📅 Expédié · ' + (o.lastEvent?.title || o.statusTitle || 'en transit') }))),
    ...sec('📬 Livrées, en attente de clôture', g.delivered, (o) => row(o, el('div', { className: 'eta ok' }, `✅ Livré${o.deliveredAt ? ' le ' + fmtDay(o.deliveredAt) : ''}`, o.closeAt ? ` · clôture le ${fmtDay(o.closeAt)} (${daysTo(o.closeAt)})` : ''), 'delivered')),
    ...sec('✅ Terminées (argent versé)', g.done, (o) => row(o, el('div', { className: 'eta muted', textContent: `Livré${o.deliveredAt ? ' le ' + fmtDay(o.deliveredAt) : ''}${o.closedAt ? ' · clôturée le ' + fmtDay(o.closedAt) : ''}` }), 'done')),
  ];
  if (!blocks.length) stateMsg($('#suiviList'), 'Aucune vente en route', 'Les commandes expédiées apparaissent ici avec leur date de livraison, puis la date de clôture.');
  else $('#suiviList').replaceChildren(...blocks);
}
$('#suiviReload').addEventListener('click', async () => { await loadShip(); renderSuivi(); });
