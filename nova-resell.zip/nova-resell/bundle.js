// ===== Nova Resell – offres groupées : une personne a mis plusieurs de tes articles en favori =====
// Partagé entre le panneau (bouton « Envoyer ») et l'arrière-plan (mode automatique).
const BUNDLE_TEMPLATE = `Coucou {pseudo} 😊
J'ai vu que tu aimes {nb} de mes articles : {articles}.
Si tu les prends ensemble, je te fais le lot à {prix_lot} € au lieu de {total} € (-{remise}).
Ajoute-les dans un lot depuis mon dressing (« Acheter en lot ») et fais-moi l'offre, je l'accepte 👍`;

const bundleKey = (g) => `${g.userId}:${g.items.map((i) => i.id).sort((a, b) => a - b).join(',')}`;

// favs : liste des favoris (favorites), items : Map id → annonce en ligne, done : Set des lots déjà proposés
function bundleGroups(favList, items, done = new Set()) {
  const byUser = new Map();
  for (const f of favList) {
    const it = items.get(f.itemId); if (!it) continue;
    const g = byUser.get(f.userId) || { userId: f.userId, pseudo: f.pseudo, items: [], last: 0 };
    if (!g.items.some((x) => x.id === it.id)) g.items.push(it);
    g.last = Math.max(g.last, new Date(f.date).getTime() || 0);
    byUser.set(f.userId, g);
  }
  return [...byUser.values()].filter((g) => g.items.length >= 2).map((g) => ({ ...g, key: bundleKey(g) }))
    .filter((g) => !done.has(g.key)).sort((a, b) => b.last - a.last);
}

function bundlePrice(settings, g) {
  const total = g.items.reduce((s, i) => s + (Number(i.price) || 0), 0);
  const pct = Math.min(60, Math.max(0, Number(settings.bundleDiscount ?? 15) || 0));
  return { total: Math.round(total * 100) / 100, lot: Math.max(1, Math.round(total * (1 - pct / 100))), pct };
}

function bundleMessage(settings, g) {
  const { total, lot, pct } = bundlePrice(settings, g);
  const names = g.items.map((i) => String(i.title || '').replace(/\s*\(#?P\d+\)\s*$/i, '').trim());
  const articles = names.length > 1 ? names.slice(0, -1).join(', ') + ' et ' + names[names.length - 1] : names[0];
  return (settings.bundleTemplate || BUNDLE_TEMPLATE)
    .replaceAll('{pseudo}', g.pseudo).replaceAll('{nb}', String(g.items.length)).replaceAll('{articles}', articles)
    .replaceAll('{total}', String(total)).replaceAll('{prix_lot}', String(lot)).replaceAll('{remise}', pct + ' %');
}
