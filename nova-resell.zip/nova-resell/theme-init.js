// Thème choisi (bleu nuit par défaut), appliqué avant l'affichage pour éviter un flash blanc
(function () {
  var t = 'dark';
  try { t = localStorage.getItem('novaTheme') || 'dark'; } catch (e) { /* stockage indisponible */ }
  document.documentElement.setAttribute('data-theme', t);
})();
