// Réponses rapides par défaut (modifiables dans l'onglet Réponses)
const DEFAULT_REPLIES = [
  { title: 'Disponible ?', text: "Bonjour {pseudo} ! Oui, l'article est toujours disponible 😊 Tu peux l'acheter directement ou me faire une offre." },
  { title: 'Mesures', text: 'Bonjour {pseudo} ! Voici les mesures à plat :\nLongueur : … cm\nAisselle à aisselle : … cm\nManches : … cm' },
  { title: 'Envoi', text: "J'envoie sous 24/48h, bien emballé et protégé 📦" },
  { title: 'Prix ferme', text: "Merci pour ton offre ! Le prix est déjà bien placé, je ne peux pas descendre plus bas désolé. N'hésite pas si tu as d'autres questions 😊" },
  { title: 'Lot', text: 'Tu peux faire un lot avec mes autres articles, je fais une réduction sur les lots 😉' },
  { title: 'État', text: "L'article est en très bon état, sans défaut visible. Je peux t'envoyer d'autres photos si tu veux !" },
  { title: 'Échange', text: "Désolé, je ne fais pas d'échange, uniquement de la vente." },
  { title: 'Merci achat', text: "Merci beaucoup pour ton achat {pseudo} ! Je l'envoie très vite 😊" },
  { title: 'Avis', text: "Ton colis est bien arrivé ? N'hésite pas à me laisser une évaluation, ça m'aide beaucoup. Merci et bonne journée !" },
];
