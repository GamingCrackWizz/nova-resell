// ===== Nova Resell – pont dans la page Vinted (monde « MAIN ») =====
// Les requêtes passent par le fetch de la page, comme celles du site Vinted
// (protections anti-robot incluses). Reçoit les demandes du script de l'extension via postMessage.
(() => {
  if (window.__novaBridge) return;
  window.__novaBridge = true;
  window.addEventListener('message', async (e) => {
    if (e.source !== window || !e.data || e.data.__nova !== 'req') return;
    const { id, url, method, headers, body, form } = e.data;
    try {
      let payload = body;
      if (form) {
        payload = new FormData();
        for (const [k, v, name] of form) (v instanceof Blob ? payload.append(k, v, name || 'file') : payload.append(k, v));
      }
      const r = await window.fetch(url, { method, headers, body: payload, credentials: 'include' });
      const text = await r.text();
      window.postMessage({ __nova: 'res', id, status: r.status, ok: r.ok, text }, location.origin);
    } catch (err) {
      window.postMessage({ __nova: 'res', id, error: String(err && err.message || err) }, location.origin);
    }
  });
  window.postMessage({ __nova: 'ready' }, location.origin);
})();
