importScripts('usage.js', 'nova-cloud.js', 'activity.js');
// Ouvre le panneau latéral quand on clique sur l'icône de l'extension
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.alarms.create('health', { periodInMinutes: 360 });
  chrome.alarms.create('autoFav', { periodInMinutes: 3 });
});
chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.alarms.create('health', { periodInMinutes: 360 });
  chrome.alarms.create('autoFav', { periodInMinutes: 3 });
});

// Diagnostic en arrière-plan toutes les 6 h (si un onglet Vinted est ouvert) + notification Windows en cas de problème
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'health') return;
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (!tab) return;
  let r;
  try { r = await chrome.tabs.sendMessage(tab.id, { va: 'healthcheck' }); } catch { return; }
  if (!r?.ok) return;
  const result = { ...r.data, time: new Date().toISOString() };
  await chrome.storage.local.set({ lastHealth: result });
  const fails = result.loggedOut ? [] : result.checks.filter((c) => !c.ok);
  if (fails.length) {
    chrome.notifications.create('va-health', {
      type: 'basic',
      iconUrl: 'icon128.png',
      title: 'Nova Resell : problème détecté',
      message: `Vinted a changé quelque chose (${fails.map((f) => f.name).join(', ')}). Ouvre l'extension → « Copier le rapport » et envoie-le à Claude.`,
      priority: 2,
    });
  }
});
chrome.notifications.onClicked.addListener(() => chrome.windows.getCurrent((w) => chrome.sidePanel.open({ windowId: w.id }).catch(() => {})));


// ===== Favoris automatiques 24h/24 : un message par nouveau favori, au plus 1 envoi toutes les 3 min =====
const DEFAULT_TEMPLATE = `Bonjour {pseudo} 😊
Merci d'avoir mis en favori mon article {article} !
Je te le propose à {prix_remise} € au lieu de {prix} € ({remise} de remise).
Envoi rapide et soigné, n'hésite pas si tu as une question !`;

function favMessage(settings, f, item) {
  const v = Number(settings.favDiscount ?? 10) || 0;
  const remise = Math.max(1, Math.round(settings.favDiscountType === 'eur' ? item.price - v : item.price * (1 - v / 100)));
  const body = (settings.favTemplate || DEFAULT_TEMPLATE)
    .replaceAll('{pseudo}', f.pseudo)
    .replaceAll('{article}', item.title.replace(/\s*\(#P\d+\)\s*$/, ''))
    .replaceAll('{prix}', item.price)
    .replaceAll('{prix_remise}', remise)
    .replaceAll('{remise}', settings.favDiscountType === 'eur' ? `${v} €` : `${v} %`);
  return { body, remise };
}
async function vintedTabBg() {
  let [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (!tab) {
    const wins = await chrome.windows.getAll();
    if (!wins.length) {
      // Chrome tourne en arrière-plan sans fenêtre : on ouvre une fenêtre réduite
      const w = await chrome.windows.create({ url: 'https://www.vinted.fr/', state: 'minimized' });
      tab = w.tabs[0];
    } else tab = await chrome.tabs.create({ url: 'https://www.vinted.fr/', active: false, pinned: true });
    await new Promise((r) => setTimeout(r, 8000));
  }
  return tab;
}
let actVia = 'auto'; // qui déclenche : auto (24h/24), mobile, planifié
async function callVinted(tab, va, rawArgs = {}) {
  const { _t, _who, ...args } = rawArgs;
  const via = actVia;
  let r;
  try { r = await chrome.tabs.sendMessage(tab.id, { va, args }); }
  catch { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['vinted-main.js'], world: 'MAIN' }); await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['vinted.js'] }); r = await chrome.tabs.sendMessage(tab.id, { va, args }); }
  if (!r?.ok) { logVintedCall(va, rawArgs, r?.error || 'Vinted ne répond pas', via); throw new Error(r?.error || 'Vinted ne répond pas'); }
  logVintedCall(va, rawArgs, null, via);
  return r.data;
}
async function logAuto(entry) {
  const { favAutoLog = [] } = await chrome.storage.local.get('favAutoLog');
  favAutoLog.push({ ...entry, time: new Date().toISOString() });
  await chrome.storage.local.set({ favAutoLog: favAutoLog.slice(-50) });
}

let autoRunning = false;
async function autoFavTick() {
  if (autoRunning) return;
  const { settings = {}, favContacted = [] } = await chrome.storage.local.get(['settings', 'favContacted']);
  if (!settings.favAuto) return;
  autoRunning = true;
  try {
    const today = new Date().toISOString().slice(0, 10);
    const { favAutoCount = {} } = await chrome.storage.local.get('favAutoCount');
    const sentToday = favAutoCount[today] || 0;
    const cap = Number(settings.favDailyCap ?? 40);
    if (sentToday >= cap) return;

    const tab = await vintedTabBg();
    if (await captchaBlocked(tab)) return;
    const favs = await callVinted(tab, 'favorites');
    const since = Number(settings.favAutoSince) || Date.now();
    const contacted = new Set(favContacted);
    const fresh = favs.filter((f) => new Date(f.date).getTime() >= since && !contacted.has(`${f.itemId}-${f.userId}`));
    if (!fresh.length) return;
    const items = await callVinted(tab, 'wardrobe');
    const byId = new Map(items.map((i) => [i.id, i]));
    const f = fresh.find((x) => byId.has(x.itemId));
    if (!f) return;
    const item = byId.get(f.itemId);
    const { body, remise } = favMessage(settings, f, item);
    contacted.add(`${f.itemId}-${f.userId}`);
    await chrome.storage.local.set({ favContacted: [...contacted] });
    try {
      const r = await callVinted(tab, 'contactFav', { itemId: f.itemId, userId: f.userId, body, offerPrice: settings.favOffer !== false ? remise : null, _t: item.title, _who: f.pseudo });
      favAutoCount[today] = sentToday + 1;
      await chrome.storage.local.set({ favAutoCount });
      await logAuto({ ok: true, pseudo: f.pseudo, article: item.title, offered: r.offered, price: remise });
    } catch (e) {
      await logAuto({ ok: false, pseudo: f.pseudo, article: item.title, error: e.message });
    }
  } catch (e) {
    await logAuto({ ok: false, error: e.message });
  } finally {
    autoRunning = false;
  }
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'autoFav') { autoFavTick(); aiReplyTick(); } });
chrome.alarms.get('autoFav', (a) => { if (!a) chrome.alarms.create('autoFav', { periodInMinutes: 3 }); });
chrome.runtime.onMessage.addListener((m) => { if (m?.va === 'autoFavNow') autoFavTick(); if (m?.va === 'aiReplyNow') aiReplyTick(); });


// ===== Agent IA : répond aux messages des acheteurs (automatique ou à valider) =====
let aiRunning = false;
async function aiReplyTick() {
  if (aiRunning) return;
  const st = await chrome.storage.local.get(['settings', 'quickReplies', 'aiHandled', 'aiQueue']);
  const settings = st.settings || {};
  if (!settings.aiAuto || !settings.apiKey) return;
  aiRunning = true;
  try {
    const handled = st.aiHandled || {};
    const queue = st.aiQueue || [];
    const tab = await vintedTabBg();
    if (await captchaBlocked(tab)) return;
    const pending = await callVinted(tab, 'inboxPending', { maxAgeHours: 72, handled });
    for (const c of pending) {
      if (queue.some((q) => q.conversationId === c.conversationId && q.lastId === c.lastId)) continue;

      // --- Offre de l'acheteur : négociation automatique ---
      if (c.offer) {
        if (settings.aiNegotiate === false || !c.offer.amount || !c.item.price || !c.offer.transactionId) { handled[c.conversationId] = c.lastId; await chrome.storage.local.set({ aiHandled: handled }); await logAi({ ok: true, skipped: true, pseudo: c.pseudo, reason: 'offre à traiter toi-même' }); continue; }
        const floor = Math.ceil(c.item.price * Number(settings.aiMinPct ?? 85) / 100);
        const ok = c.offer.amount >= floor;
        const price = ok ? c.offer.amount : Math.max(floor, Math.round((c.offer.amount + c.item.price) / 2));
        const message = ok
          ? `Ça marche pour ${c.offer.amount} € ! Je t'envoie l'offre, tu n'as plus qu'à valider 😊`
          : `Merci pour ton offre ! Je ne peux pas descendre à ${c.offer.amount} €, mais je te propose ${price} € 😊 Je t'envoie l'offre.`;
        handled[c.conversationId] = c.lastId;
        await chrome.storage.local.set({ aiHandled: handled });
        if ((settings.aiMode || 'validate') === 'auto') {
          try {
            await callVinted(tab, 'sellerOffer', { transactionId: c.offer.transactionId, price });
            await callVinted(tab, 'reply', { conversationId: c.conversationId, body: message, _who: c.pseudo || '', _t: c.item?.title || '' });
            await logAi({ ok: true, pseudo: c.pseudo, message: `offre ${c.offer.amount} € → ${ok ? 'acceptée' : 'contre-offre ' + price + ' €'}` });
          } catch (e) { await logAi({ ok: false, pseudo: c.pseudo, error: e.message }); }
        } else {
          queue.push({ conversationId: c.conversationId, lastId: c.lastId, pseudo: c.pseudo, article: c.item.title, question: `Offre de ${c.offer.amount} € (prix ${c.item.price} €)`, message, offerPrice: price, transactionId: c.offer.transactionId, time: new Date().toISOString() });
          await chrome.storage.local.set({ aiQueue: queue.slice(-30) });
        }
        continue;
      }

      let ans;
      try { ans = await askAgent(settings, st.quickReplies || [], c); }
      catch (e) { await logAi({ ok: false, pseudo: c.pseudo, error: e.message }); continue; }
      handled[c.conversationId] = c.lastId;
      await chrome.storage.local.set({ aiHandled: handled });
      if (ans.action !== 'reply' || !ans.message) {
        await logAi({ ok: true, skipped: true, pseudo: c.pseudo, reason: ans.reason || 'question à traiter toi-même', conversationId: c.conversationId });
        continue;
      }
      if ((settings.aiMode || 'validate') === 'auto') {
        try {
          await callVinted(tab, 'reply', { conversationId: c.conversationId, body: ans.message, _who: c.pseudo || '', _t: c.item?.title || '' });
          await logAi({ ok: true, pseudo: c.pseudo, message: ans.message, conversationId: c.conversationId });
        } catch (e) { await logAi({ ok: false, pseudo: c.pseudo, error: e.message }); }
        await new Promise((r) => setTimeout(r, 4000 + Math.random() * 6000));
      } else {
        queue.push({ conversationId: c.conversationId, lastId: c.lastId, pseudo: c.pseudo, article: c.item.title, question: c.history.filter((h) => h.who === 'acheteur').slice(-1)[0]?.text || '', message: ans.message, time: new Date().toISOString() });
        await chrome.storage.local.set({ aiQueue: queue.slice(-30) });
      }
    }
  } catch (e) {
    await logAi({ ok: false, error: e.message });
  } finally {
    aiRunning = false;
  }
}

async function logAi(entry) {
  const { aiLog = [] } = await chrome.storage.local.get('aiLog');
  aiLog.push({ ...entry, time: new Date().toISOString() });
  await chrome.storage.local.set({ aiLog: aiLog.slice(-40) });
}

async function askAgent(settings, faq, c) {
  const minPct = Number(settings.aiMinPct ?? 85);
  const system = `Tu es l'assistant d'un vendeur de vêtements d'occasion sur Vinted France. Tu réponds à sa place aux messages des acheteurs.
Style : français, tutoiement, chaleureux, court (1 à 3 phrases), 1 emoji maximum, pas de signature.
Règles strictes :
- Base-toi UNIQUEMENT sur les infos de l'article, la conversation et les réponses types ci-dessous. N'invente jamais une mesure, une matière ou un défaut.
- Si tu n'as pas l'info (ex. mesures absentes), ou si la demande est inhabituelle (litige, retour, problème de colis, réclamation, insulte, demande de paiement hors Vinted, échange de coordonnées), réponds {"action":"skip"} : le vendeur répondra lui-même.
- Prix : le prix affiché est ${c.item.price || '?'} €. Ne propose JAMAIS moins de ${minPct} % de ce prix (soit ${c.item.price ? Math.ceil(c.item.price * minPct / 100) : '?'} €). Pour accepter une offre, invite l'acheteur à faire l'offre via le bouton Vinted.
- Jamais de paiement, de rendez-vous ou de contact en dehors de Vinted. Ne communique aucune donnée personnelle.
- Si l'article est déjà vendu à cette personne, réponds simplement et poliment (remerciement, délai d'envoi 24/48h).
${settings.aiRules ? 'Consignes du vendeur : ' + settings.aiRules : ''}

Réponses types du vendeur (à réutiliser et adapter) :
${faq.map((r) => `- ${r.title} : ${r.text}`).join('\n')}

Réponds UNIQUEMENT en JSON : {"action":"reply","message":"..."} ou {"action":"skip","reason":"..."}`;
  const user = `Article : ${c.item.title}${c.isBundle ? ` (lot de ${c.itemCount} articles)` : ''}
Description : ${c.item.description || '(non disponible)'}
Statut : ${c.sold ? 'déjà vendu à cet acheteur' : 'en vente'}
Acheteur : ${c.pseudo}

Conversation (du plus ancien au plus récent) :
${c.history.map((h) => `[${h.who}] ${h.text}`).join('\n')}

Écris la réponse au dernier message de l'acheteur.`;
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': settings.apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
    body: JSON.stringify({ model: settings.model || 'claude-haiku-5-5', max_tokens: 400, system, messages: [{ role: 'user', content: user }] }),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error?.message || 'Erreur API ' + res.status);
  await recordUsage('agent', settings.model || 'claude-haiku-5-5', j.usage);
  const text = (j.content || []).map((b) => b.text || '').join('');
  const m = text.match(/\{[\s\S]*\}/);
  return m ? JSON.parse(m[0]) : { action: 'skip', reason: 'réponse illisible' };
}

// ===== Alertes de vente et rappels d'expédition =====
chrome.alarms.get('salesWatch', (a) => { if (!a) chrome.alarms.create('salesWatch', { periodInMinutes: 20 }); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'salesWatch') salesWatch(); });

async function salesWatch() {
  const { settings = {}, saleSeen = {} } = await chrome.storage.local.get(['settings', 'saleSeen']);
  if (settings.shipAlerts === false) return;
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (!tab) return; // pas d'onglet Vinted : on ne force pas l'ouverture juste pour ça
  if (await captchaBlocked(tab)) return;
  let sales;
  try { sales = await callVinted(tab, 'sales', { pages: 1 }); } catch { return; }
  const firstRun = !Object.keys(saleSeen).length;
  const now = Date.now();
  for (const o of sales) {
    const toShip = o.userStatus === 'waiting' && !o.isReturn && o.shipmentId && (o.shipmentStatus == null || o.shipmentStatus < 300);
    const id = String(o.transactionId);
    const seen = saleSeen[id] || (saleSeen[id] = { first: now, reminded: 0 });
    if (o.isReturn && o.userStatus === 'waiting') {
      const sku = o.skus?.length ? o.skus.join(' + ') : o.title;
      if (!seen.returnNotified) { seen.returnNotified = true; logActivity({ cat: 'sale', icon: '↩️', title: 'Retour demandé par l’acheteur', detail: o.title, via: 'vinted' }); if (!firstRun) notify('ret-' + id, '↩️ Retour demandé', `${sku} : l'acheteur a signalé un problème. Ouvre l'onglet Ventes → Retours.`); }
      if (o.eta && !seen.returnEta) { seen.returnEta = true; notify('reteta-' + id, '📦 Colis retour expédié', `${sku} revient vers toi : arrivée estimée ${o.eta.text}.`); }
      seen.done = true; continue;
    }
    if (!toShip) { seen.done = true; continue; }
    if (seen.done) continue;
    const sku = o.skus?.length ? o.skus.join(' + ') : 'sans SKU';
    if (!seen.notified) {
      seen.notified = true;
      logActivity({ cat: 'sale', icon: '🎉', title: 'Nouvelle vente', detail: `${o.title} · ${o.price} €`, via: 'vinted' });
      if (!firstRun) notify('sale-' + id, '🎉 Nouvelle vente !', `${sku} · ${o.title} · ${o.price} €. Imprime le bordereau dans l'onglet Ventes.`);
    }
    const days = (now - seen.first) / 86400000;
    if (days >= 2 && seen.reminded < 1) { seen.reminded = 1; notify('ship-' + id, '📦 Pense à expédier', `${sku} est vendu depuis 2 jours. Dépose le colis avant la date limite de Vinted.`); }
    else if (days >= 4 && seen.reminded < 2) { seen.reminded = 2; notify('ship2-' + id, '⚠️ Expédition urgente', `${sku} n'est toujours pas expédié : la commande risque d'être annulée.`); }
  }
  // ménage : on garde 200 ventes
  const ids = Object.keys(saleSeen); if (ids.length > 200) ids.slice(0, ids.length - 200).forEach((k) => delete saleSeen[k]);
  await chrome.storage.local.set({ saleSeen });
}
function notify(id, title, message) {
  chrome.notifications.create(id, { type: 'basic', iconUrl: 'icon128.png', title, message, priority: 2 });
}

// ===== Synchronisation entre tes PC via ton compte Google Chrome (chrome.storage.sync) =====
// Partagé : réglages (SANS la clé API), réponses rapides, favoris déjà contactés, conversations déjà traitées par l'agent.
const LOCAL_ONLY = ['apiKey', 'phonePath', 'phoneDlId', 'phoneSince', 'vintedMaxSku', 'favAuto', 'aiAuto', 'favAutoSince'];
const pick = (o, drop) => Object.fromEntries(Object.entries(o || {}).filter(([k]) => !drop.includes(k)));
let applyingSync = false;
let pushTimer = null;

async function pushSync() {
  const { settings = {}, quickReplies, favContacted = [], aiHandled = {} } = await chrome.storage.local.get(['settings', 'quickReplies', 'favContacted', 'aiHandled']);
  if (settings.syncEnabled === false) return;
  const data = {
    s_settings: pick(settings, LOCAL_ONLY),
    s_replies: quickReplies || null,
    s_fav: favContacted.slice(-300),
    s_ai: Object.fromEntries(Object.entries(aiHandled).slice(-150)),
  };
  const cur = await chrome.storage.sync.get(Object.keys(data));
  const changed = Object.fromEntries(Object.entries(data).filter(([k, v]) => JSON.stringify(cur[k]) !== JSON.stringify(v)));
  if (Object.keys(changed).length) { try { await chrome.storage.sync.set(changed); } catch (e) { console.warn('sync', e.message); } }
}

async function pullSync() {
  const { settings = {} } = await chrome.storage.local.get('settings');
  if (settings.syncEnabled === false) return;
  const r = await chrome.storage.sync.get(['s_settings', 's_replies', 's_fav', 's_ai']);
  const loc = await chrome.storage.local.get(['settings', 'quickReplies', 'favContacted', 'aiHandled']);
  const upd = {};
  if (r.s_settings) {
    const merged = { ...loc.settings, ...r.s_settings, ...Object.fromEntries(LOCAL_ONLY.filter((k) => k in (loc.settings || {})).map((k) => [k, loc.settings[k]])) };
    merged.nextSku = Math.max(loc.settings?.nextSku || 1, r.s_settings.nextSku || 1);
    if (JSON.stringify(merged) !== JSON.stringify(loc.settings)) upd.settings = merged;
  }
  if (r.s_replies && JSON.stringify(r.s_replies) !== JSON.stringify(loc.quickReplies)) upd.quickReplies = r.s_replies;
  if (r.s_fav) { const u = [...new Set([...(loc.favContacted || []), ...r.s_fav])]; if (u.length !== (loc.favContacted || []).length) upd.favContacted = u; }
  if (r.s_ai) { const m = { ...(loc.aiHandled || {}), ...r.s_ai }; if (JSON.stringify(m) !== JSON.stringify(loc.aiHandled)) upd.aiHandled = m; }
  if (Object.keys(upd).length) { applyingSync = true; await chrome.storage.local.set(upd); setTimeout(() => (applyingSync = false), 500); }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync') { pullSync(); return; }
  if (area === 'local' && !applyingSync && (changes.settings || changes.quickReplies || changes.favContacted || changes.aiHandled)) {
    clearTimeout(pushTimer); pushTimer = setTimeout(pushSync, 3000);
  }
});
chrome.runtime.onStartup.addListener(pullSync);
chrome.runtime.onInstalled.addListener(() => pullSync().then(pushSync));


// ===== Vérification anti-robot Vinted (captcha) : pause des automatismes + notification =====
async function captchaBlocked(tab) {
  const { captcha } = await chrome.storage.local.get('captcha');
  if (!captcha) return false;
  // petite vérification : si une requête passe à nouveau, le drapeau est levé tout seul
  try { await callVinted(tab, 'me'); } catch { /* toujours bloqué */ }
  const s2 = await chrome.storage.local.get('captcha');
  return !!s2.captcha;
}
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !c.captcha) return;
  if (c.captcha.newValue && !c.captcha.oldValue) {
    logActivity({ cat: 'error', icon: '🛡️', title: 'Vinted demande une vérification anti-robot', detail: 'Automatismes en pause jusqu’à la vérification', via: 'vinted' });
    chrome.notifications.create('nova-captcha', { type: 'basic', iconUrl: 'icon128.png', priority: 2, requireInteraction: true,
      title: '🛡️ Vérification Vinted requise',
      message: "Vinted demande de prouver que tu n'es pas un robot. Ouvre vinted.fr et passe la vérification : les automatismes Nova sont en pause." });
  } else if (!c.captcha.newValue && c.captcha.oldValue) {
    chrome.notifications.clear('nova-captcha');
    chrome.notifications.create('nova-captcha-ok', { type: 'basic', iconUrl: 'icon128.png', title: '✅ Vérification passée', message: 'Les automatismes Nova Resell reprennent.' });
  }
});
chrome.notifications.onClicked.addListener(async (id) => {
  if (id !== 'nova-captcha') return;
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (tab) { await chrome.tabs.update(tab.id, { active: true }); await chrome.tabs.reload(tab.id); chrome.windows.update(tab.windowId, { focused: true }); }
  else chrome.tabs.create({ url: 'https://www.vinted.fr/' });
});


// ===== Après « Réactualiser » : recharge les onglets Vinted pour charger les nouveaux scripts =====
async function reloadVintedTabsIfAsked() {
  const { reloadTabsAfter } = await chrome.storage.local.get('reloadTabsAfter');
  if (!reloadTabsAfter) return;
  await chrome.storage.local.remove('reloadTabsAfter');
  if (Date.now() - reloadTabsAfter > 60000) return;
  for (const t of await chrome.tabs.query({ url: 'https://www.vinted.fr/*' })) chrome.tabs.reload(t.id);
  chrome.notifications.create('nova-reloaded', { type: 'basic', iconUrl: 'icon128.png', title: 'Nova Resell réactualisé ✓', message: `Version ${chrome.runtime.getManifest().version} chargée. Rouvre le panneau avec l'icône Nova Resell.` });
}
chrome.runtime.onInstalled.addListener(reloadVintedTabsIfAsked);
reloadVintedTabsIfAsked();


// ===== Appli mobile : état du compte + actions demandées depuis l'iPhone =====
const favCache = { at: 0, list: [] };
async function mobileState() {
  const tab = await vintedTabBg();
  const st = await chrome.storage.local.get(['aiQueue', 'captcha', 'pubSchedule', 'settings', 'favContacted', 'mobileRepostDone']);
  const sched = st.pubSchedule || {};
  const settings = st.settings || {};
  const [items, drafts, sales] = await Promise.all([callVinted(tab, 'wardrobe'), callVinted(tab, 'drafts'), callVinted(tab, 'sales', { pages: 2 })]);
  const dash = { online: items.length, drafts: drafts.length };
  if (!favCache.at || Date.now() - favCache.at > 10 * 60000) { try { favCache.list = await callVinted(tab, 'favorites'); favCache.at = Date.now(); } catch { /* on garde l'ancienne liste */ } }
  const byId = new Map(items.map((i) => [i.id, i]));
  const contacted = new Set(st.favContacted || []);
  const favs = (favCache.list || []).filter((f) => byId.has(f.itemId) && !contacted.has(`${f.itemId}-${f.userId}`)).slice(0, 40).map((f) => {
    const it = byId.get(f.itemId); const { remise } = favMessage(settings, f, it);
    return { itemId: f.itemId, userId: f.userId, pseudo: f.pseudo, title: it.title, price: it.price, remise, photo: it.photo, date: f.date };
  });
  const age = Number(settings.repostAge ?? 14);
  const repostItems = [...items].sort((a, b) => (a.ts || 0) - (b.ts || 0)).slice(0, 60).map((i) => ({ id: i.id, title: i.title, price: i.price, photo: i.photo, favs: i.favs, views: i.views, days: i.ts ? Math.floor((Date.now() - i.ts) / 86400000) : null, due: i.ts ? Date.now() - i.ts > age * 86400000 : false }));
  const now = new Date();
  const sameMonth = (d) => { const t = new Date(d); return !isNaN(t) && t.getMonth() === now.getMonth() && t.getFullYear() === now.getFullYear(); };
  const toShip = sales.filter((o) => o.userStatus === 'waiting' && !o.isReturn && o.shipmentId && (o.shipmentStatus == null || o.shipmentStatus < 300));
  const returns = sales.filter((o) => o.userStatus === 'waiting' && o.isReturn);
  const transit = sales.filter((o) => o.userStatus === 'waiting' && !o.isReturn && o.eta);
  return {
    version: chrome.runtime.getManifest().version,
    captcha: !!st.captcha,
    stats: { toShip: toShip.length, drafts: dash.drafts, online: dash.online, month: sales.filter((o) => o.userStatus !== 'failed' && sameMonth(o.date)).reduce((a, o) => a + (o.price || 0), 0) },
    favs, repostItems, repostDiscount: Number(settings.repostDiscount) || 0,
    drafts: drafts.slice(0, 40).map((d) => ({ id: d.id, title: d.title, price: d.price, photo: d.photo || '', brand: d.brand || '', size: d.size || '', scheduledAt: sched[d.id]?.at || null, schedError: sched[d.id]?.failed ? sched[d.id].error : null })),
    sales: toShip.slice(0, 30).map((o) => ({ title: o.title, skus: o.skus || [], price: o.price, statusTitle: o.statusTitle || '', photo: o.photo || '' })),
    returns: returns.slice(0, 20).map((o) => ({ title: o.title, skus: o.skus || [], price: o.price, photo: o.photo || '', step: o.lastEvent?.title || o.txStatusTitle || '', eta: o.eta || null, type: o.returnInfo?.type || '', refund: o.returnInfo?.refund || null, conversationId: o.conversationId })),
    transit: transit.slice(0, 30).map((o) => ({ title: o.title, skus: o.skus || [], price: o.price, photo: o.photo || '', eta: o.eta, step: o.lastEvent?.title || '' })),
    aiQueue: (st.aiQueue || []).slice(0, 20).map((q) => ({ conversationId: q.conversationId, lastId: q.lastId, pseudo: q.pseudo, article: q.article, question: q.question, message: q.message, offerPrice: q.offerPrice || null, transactionId: q.transactionId || null })),
  };
}
async function mobileAction(action, p) {
  actVia = 'mobile';
  try { return await mobileActionInner(action, p); } finally { actVia = 'auto'; }
}
async function mobileActionInner(action, p) {
  const tab = await vintedTabBg();
  if (action === 'publishDraft') return callVinted(tab, 'publishDraft', { id: p.id, _t: p.title || '' });
  if (action === 'aiSend') {
    if (p.offerPrice && p.transactionId) await callVinted(tab, 'sellerOffer', { transactionId: p.transactionId, price: p.offerPrice });
    await callVinted(tab, 'reply', { conversationId: p.conversationId, body: p.body, _who: p.pseudo || '' });
    const { aiQueue = [] } = await chrome.storage.local.get('aiQueue');
    await chrome.storage.local.set({ aiQueue: aiQueue.filter((q) => !(String(q.conversationId) === String(p.conversationId) && String(q.lastId) === String(p.lastId))) });
    return true;
  }
  if (action === 'repost') {
    if (await captchaBlocked(tab)) throw new Error('Vérification Vinted à faire sur le PC');
    const { settings = {} } = await chrome.storage.local.get('settings');
    const d = Number(settings.repostDiscount) || 0;
    const price = d ? Math.max(1, Math.round(Number(p.price) * (1 - d / 100))) : Number(p.price);
    const r = await callVinted(tab, 'repost', { id: p.id, _t: p.title || '', price, mode: settings.repostMode || 'publish' });
    if ((settings.repostMode || 'publish') === 'publish' && !r.deleted) {
      try { await callVinted(tab, 'deleteItem', { id: p.id }); } catch { throw new Error("Copie publiée, mais l'ancienne annonce n'a pas pu être supprimée : supprime-la à la main"); }
    }
    return true;
  }
  if (action === 'favSend') {
    if (await captchaBlocked(tab)) throw new Error('Vérification Vinted à faire sur le PC');
    const { settings = {}, favContacted = [] } = await chrome.storage.local.get(['settings', 'favContacted']);
    const key = `${p.itemId}-${p.userId}`;
    if (favContacted.includes(key)) return true;
    const items = await callVinted(tab, 'wardrobe');
    const item = items.find((i) => i.id === Number(p.itemId));
    if (!item) throw new Error("L'article n'est plus en ligne");
    const { body, remise } = favMessage(settings, { pseudo: p.pseudo || '' }, item);
    const r = await callVinted(tab, 'contactFav', { itemId: p.itemId, userId: p.userId, body, offerPrice: settings.favOffer !== false ? remise : null, _t: item.title, _who: p.pseudo });
    await chrome.storage.local.set({ favContacted: [...favContacted, key].slice(-2000) });
    await logAuto({ ok: true, pseudo: p.pseudo, article: item.title, offered: r.offered, price: remise, via: 'mobile' });
    return true;
  }
  if (action === 'scheduleDraft') {
    const { pubSchedule = {} } = await chrome.storage.local.get('pubSchedule');
    if (p.at) pubSchedule[p.id] = { at: Number(p.at), title: p.title || '' }; else delete pubSchedule[p.id];
    logActivity({ cat: 'publish', icon: '🕒', title: p.at ? 'Publication planifiée le ' + new Date(Number(p.at)).toLocaleString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Planification annulée', detail: p.title || '', via: 'mobile' });
    await chrome.storage.local.set({ pubSchedule });
    return true;
  }
  if (action === 'printLabels') { await chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html#print'), active: true }); return true; }
  throw new Error('Action inconnue : ' + action);
}
// Si des photos arrivent du mobile et que le panneau Nova n'est pas ouvert, on l'ouvre dans un onglet de travail
async function ensureWorker() {
  const { panelAlive = 0 } = await chrome.storage.local.get('panelAlive');
  if (Date.now() - panelAlive < 25000) return;
  const url = chrome.runtime.getURL('sidepanel.html#worker');
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('sidepanel.html') + '*' });
  if (!tabs.length) await chrome.tabs.create({ url, active: false, pinned: true });
}
chrome.runtime.onMessage.addListener((m, _s, sendResponse) => {
  if (m?.va === 'mobileState') { mobileState().then((data) => sendResponse({ ok: true, data })).catch((e) => sendResponse({ ok: false, error: e.message })); return true; }
  if (m?.va === 'mobileAction') { mobileAction(m.action, m.payload).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: e.message })); return true; }
  if (m?.va === 'mobileInboxAdded') { ensureWorker(); return false; }
  return false;
});


// ===== Compte Nova (Supabase) : synchronisation avec l'appli mobile, toutes les 30 s =====
chrome.alarms.get('novaCloud', (a) => { if (!a) chrome.alarms.create('novaCloud', { periodInMinutes: 0.5 }); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'novaCloud') cloudTick(); });
let cloudRunning = false, lastStatePush = 0;
// Anti-pause : même sans être connecté, l'extension « réveille » le projet Nova une fois par jour
async function keepAlive(c) {
  if (!c.url || !c.key) return;
  const { novaPing = 0 } = await chrome.storage.local.get('novaPing');
  if (Date.now() - novaPing < 20 * 3600e3) return;
  try { await fetch(`${c.url}/rest/v1/jobs?select=id&limit=1`, { headers: { apikey: c.key, authorization: `Bearer ${c.key}` } }); await chrome.storage.local.set({ novaPing: Date.now() }); } catch { /* réessai au prochain passage */ }
}
async function cloudTick(force = false) {
  if (cloudRunning) return;
  const c = await NovaCloud.cfg();
  if (!c.session?.refresh_token) { keepAlive(c); return; }
  cloudRunning = true;
  try {
    // 1. nouveaux articles envoyés depuis le téléphone
    const jobs = await NovaCloud.rest('GET', 'jobs?status=eq.new&select=id,photos&order=created_at.asc&limit=10');
    for (const j of jobs || []) {
      await NovaCloud.rest('PATCH', `jobs?id=eq.${j.id}`, { status: 'pc', updated_at: new Date().toISOString() });
      try {
        const photos = [];
        for (const p of j.photos || []) photos.push(await blobToDataUrl(await NovaCloud.download(p)));
        const { mobileInbox = [] } = await chrome.storage.local.get('mobileInbox');
        mobileInbox.push({ jobId: 'cloud:' + j.id, photos, ts: Date.now() });
        logActivity({ cat: 'draft', icon: '📱', title: `Photos reçues du téléphone (${photos.length})`, detail: 'Analyse et brouillon en cours sur le PC', via: 'mobile' });
        await chrome.storage.local.set({ mobileInbox });
        NovaCloud.removePhotos(j.photos);  // les photos sont maintenant sur le PC : on libère l'espace
        ensureWorker();
      } catch (e) {
        await NovaCloud.rest('PATCH', `jobs?id=eq.${j.id}`, { status: 'error', error: e.message });
      }
    }
    // 2. actions demandées depuis le téléphone
    const acts = await NovaCloud.rest('GET', 'actions?status=eq.new&select=id,type,payload&order=created_at.asc&limit=10');
    let heavyDone = false;
    for (const a of acts || []) {
      const heavy = a.type === 'repost' || a.type === 'favSend' || a.type === 'publishDraft';
      if (heavy && heavyDone) continue; // une action Vinted « lourde » par passage (~30 s) pour rester discret
      if (heavy) heavyDone = true;
      await NovaCloud.rest('PATCH', `actions?id=eq.${a.id}`, { status: 'running' });
      try { await mobileAction(a.type, a.payload || {}); await NovaCloud.rest('PATCH', `actions?id=eq.${a.id}`, { status: 'done', error: null }); force = true; }
      catch (e) { await NovaCloud.rest('PATCH', `actions?id=eq.${a.id}`, { status: 'error', error: e.message }); }
    }
    // 3. état du compte (stats, brouillons, ventes, réponses IA) toutes les 3 min
    if (force || Date.now() - lastStatePush > 180000) {
      const data = await mobileState();
      const uid = (await NovaCloud.cfg()).session?.user?.id;
      await NovaCloud.rest('POST', 'state?on_conflict=user_id', { user_id: uid, data, updated_at: new Date().toISOString() }, 'resolution=merge-duplicates');
      lastStatePush = Date.now();
    }
    await NovaCloud.save({ lastSync: Date.now(), lastError: null });
  } catch (e) {
    await NovaCloud.save({ lastError: e.message });
  } finally { cloudRunning = false; }
}
// résultats du panneau (analyse, brouillon) → compte Nova
chrome.storage.onChanged.addListener(async (c, area) => {
  if (area !== 'local' || !c.mobileResults) return;
  const nv = c.mobileResults.newValue || {}, ov = c.mobileResults.oldValue || {};
  for (const [id, p] of Object.entries(nv)) {
    if (!id.startsWith('cloud:') || JSON.stringify(p) === JSON.stringify(ov[id])) continue;
    NovaCloud.rest('PATCH', `jobs?id=eq.${id.slice(6)}`, { status: p.status, title: p.title ?? null, sku: p.sku ?? null, price: p.price ?? null, error: p.error ?? null, draft_id: p.draftId ?? null, updated_at: new Date().toISOString() }).catch(() => {});
  }
});
chrome.runtime.onMessage.addListener((m) => { if (m?.va === 'cloudNow') cloudTick(true); });

// ===== Publication planifiée des brouillons (une par minute au plus, à l'heure choisie) =====
chrome.alarms.get('pubSchedule', (a) => { if (!a) chrome.alarms.create('pubSchedule', { periodInMinutes: 1 }); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'pubSchedule') scheduleTick(); });
let schedRunning = false;
async function scheduleTick() {
  if (schedRunning) return;
  const { pubSchedule = {} } = await chrome.storage.local.get('pubSchedule');
  const due = Object.entries(pubSchedule).filter(([, s]) => s.at <= Date.now() && !s.failed).sort((a, b) => a[1].at - b[1].at);
  if (!due.length) return;
  schedRunning = true;
  const [id, s] = due[0];
  let patch;
  try {
    const tab = await vintedTabBg();
    if (await captchaBlocked(tab)) return;
    actVia = 'planifié';
    try { await callVinted(tab, 'publishDraft', { id: Number(id), _t: s.title || '' }); } finally { actVia = 'auto'; }
    patch = null;
    notify('nova-sched-' + id, 'Annonce publiée ✓', `« ${s.title || 'Brouillon'} » est en ligne sur Vinted (publication planifiée).`);
    const { pubScheduleLog = [] } = await chrome.storage.local.get('pubScheduleLog');
    pubScheduleLog.push({ id, title: s.title, at: Date.now(), ok: true });
    await chrome.storage.local.set({ pubScheduleLog: pubScheduleLog.slice(-30) });
  } catch (e) {
    const tries = (s.tries || 0) + 1;
    patch = { ...s, tries, error: e.message, at: Date.now() + 10 * 60000, failed: tries >= 3 };
    if (patch.failed) notify('nova-sched-' + id, 'Publication planifiée impossible', `« ${s.title || 'Brouillon'} » : ${e.message}. Ouvre l'onglet Brouillons pour le compléter.`);
  } finally {
    const cur = (await chrome.storage.local.get('pubSchedule')).pubSchedule || {};
    if (cur[id]?.at === s.at) { if (patch) cur[id] = patch; else delete cur[id]; await chrome.storage.local.set({ pubSchedule: cur }); }
    schedRunning = false;
  }
}

// ===== Mises à jour : vérifie la dernière version publiée sur le GitHub de Nova Resell =====
const NOVA_UPDATE_URL = 'https://gamingcrackwizz.github.io/nova-resell/version.json';
const newer = (a, b) => { const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); } return false; };
async function checkUpdate() {
  try {
    const r = await fetch(NOVA_UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return;
    const v = await r.json();
    const cur = chrome.runtime.getManifest().version;
    if (v?.version && newer(v.version, cur)) {
      const { updateAvail } = await chrome.storage.local.get('updateAvail');
      await chrome.storage.local.set({ updateAvail: { ...v, checkedAt: Date.now() } });
      if (updateAvail?.version !== v.version) {
        notify('nova-update', `✨ Nova Resell ${v.version} est disponible`, (v.notes || []).slice(0, 2).join(' · ') || 'Ouvre le panneau Nova pour l’installer.');
        logActivity({ cat: 'sale', icon: '✨', title: `Mise à jour ${v.version} disponible`, detail: (v.notes || []).join(' · '), via: 'pc' });
      }
    } else await chrome.storage.local.remove('updateAvail');
  } catch { /* hors ligne : on réessaiera */ }
}
chrome.alarms.get('updateCheck', (a) => { if (!a) chrome.alarms.create('updateCheck', { periodInMinutes: 360, delayInMinutes: 1 }); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'updateCheck') checkUpdate(); });
chrome.runtime.onStartup.addListener(checkUpdate);
chrome.runtime.onInstalled.addListener(() => { chrome.storage.local.remove('updateAvail'); setTimeout(checkUpdate, 5000); });
chrome.runtime.onMessage.addListener((m) => { if (m?.va === 'checkUpdate') checkUpdate(); });
