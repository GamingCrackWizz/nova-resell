// ===== Nova Resell – écran de bienvenue (premier lancement) : compte Nova puis clé API =====
(() => {
  const ob = $('#onboard');
  let obMode = 'up';
  const step = (n) => {
    document.querySelectorAll('#onboard .ob-step').forEach((s) => { s.hidden = s.dataset.step !== String(n); });
    document.querySelectorAll('#onboard .ob-steps li').forEach((li) => { li.classList.toggle('on', Number(li.dataset.s) <= n); });
    if (n === 3) fillDone();
    ob.scrollTop = 0;
  };
  const setMode = (m) => {
    obMode = m;
    document.querySelectorAll('#onboard .seg-btn[data-ob]').forEach((b) => b.classList.toggle('active', b.dataset.ob === m));
    $('#obPass2Wrap').hidden = m !== 'up'; $('#obForgot').hidden = m !== 'in';
    $('#obAccGo').textContent = m === 'up' ? 'Créer mon compte' : 'Me connecter';
    $('#obPass').autocomplete = m === 'up' ? 'new-password' : 'current-password';
    $('#obErr').textContent = '';
  };
  async function fillDone() {
    const c = await NovaCloud.cfg();
    const { settings: st = {} } = await chrome.storage.local.get('settings');
    $('#obDoneAcc').textContent = c.session?.refresh_token ? `✅ Compte Nova : ${c.session.user?.email}` : '⏭️ Compte Nova : plus tard (⚙︎ → Compte)';
    $('#obDoneKey').textContent = st.apiKey ? '✅ Clé API enregistrée' : '⏭️ Clé API : plus tard (⚙︎ → API Claude)';
    $('#obAppUrl').textContent = NOVA_APP_URL.replace(/^https:\/\//, '');
  }
  async function nextAfterAccount() {
    const { settings: st = {} } = await chrome.storage.local.get('settings');
    step(st.apiKey ? 3 : 2);
  }
  async function finish() {
    const { settings: st = {} } = await chrome.storage.local.get('settings');
    await chrome.storage.local.set({ settings: { ...st, onboarded: true } });
    if (typeof settings !== 'undefined') settings.onboarded = true;
    ob.hidden = true;
  }
  async function start(force) {
    if (/worker|print/.test(location.hash)) return;
    const c = await NovaCloud.cfg();
    const { settings: st = {} } = await chrome.storage.local.get('settings');
    const hasAcc = !!c.session?.refresh_token;
    if (!force && (st.onboarded || (hasAcc && st.apiKey))) return;
    ob.hidden = false;
    setMode('up');
    if (hasAcc) nextAfterAccount(); else step(1);
  }

  document.querySelectorAll('#onboard .seg-btn[data-ob]').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.ob)));
  $('#obAccGo').addEventListener('click', async () => {
    const email = $('#obMail').value.trim(), pass = $('#obPass').value, err = $('#obErr');
    err.textContent = '';
    try {
      if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('Adresse e-mail invalide');
      if (pass.length < 6) throw new Error('Mot de passe : 6 caractères minimum');
      $('#obAccGo').disabled = true;
      if (obMode === 'up') {
        if (pass !== $('#obPass2').value) throw new Error('Les deux mots de passe ne sont pas identiques : retape-les');
        const r = await NovaCloud.signUp(email, pass);
        if (r.confirm) { setMode('in'); err.textContent = '📧 Compte créé ! Clique sur le lien reçu par e-mail, puis connecte-toi ici.'; return; }
      } else await NovaCloud.signIn(email, pass);
      $('#obPass').value = ''; $('#obPass2').value = '';
      chrome.runtime.sendMessage({ va: 'cloudNow' }).catch(() => {});
      toast('Compte Nova connecté ✓');
      if (obMode === 'in') {
        try {
          const b = await NovaCloud.downloadBackup();
          if (b) { await applyBackup(b); const { settings: st } = await chrome.storage.local.get('settings'); if (typeof settings !== 'undefined') { Object.assign(settings, st); fillSettings(); } toast('☁️ Tes réglages ont été récupérés depuis ton compte'); }
        } catch { /* pas de sauvegarde */ }
      }
      nextAfterAccount();
    } catch (e) {
      err.textContent = e.message;
      if (/existe déjà/.test(e.message)) setMode('in'), (err.textContent = e.message);
    } finally { $('#obAccGo').disabled = false; }
  });
  $('#obForgot').addEventListener('click', (e) => { e.preventDefault(); forgotPassword($('#obMail').value.trim(), $('#obErr')); });
  $('#obSkipAcc').addEventListener('click', nextAfterAccount);

  $('#obConsole').addEventListener('click', () => chrome.tabs.create({ url: 'https://console.anthropic.com/settings/keys' }));
  $('#obKeyGo').addEventListener('click', async () => {
    const key = $('#obKey').value.trim(), err = $('#obKeyErr');
    err.textContent = 'Vérification…'; $('#obKeyGo').disabled = true;
    try {
      await testApiKey(key);
      settings.apiKey = key; await saveSettings(); fillSettings();
      $('#obKey').value = ''; err.textContent = '';
      toast('Clé API enregistrée ✓');
      step(3);
    } catch (e) { err.textContent = '⚠︎ ' + e.message; }
    finally { $('#obKeyGo').disabled = false; }
  });
  $('#obSkipKey').addEventListener('click', () => step(3));
  $('#obCopyUrl').addEventListener('click', (e) => { e.preventDefault(); navigator.clipboard.writeText(NOVA_APP_URL).then(() => toast('Lien copié')); });
  $('#obDone').addEventListener('click', finish);
  $('#obRestart').addEventListener('click', () => { $('#settings').hidden = true; start(true); });

  start(false);
})();
