// ===== Nova Resell – compte Nova (Supabase) partagé entre l'extension (PC) et l'appli mobile =====
// Utilisé par le panneau (connexion) et par l'arrière-plan (synchronisation). Aucune bibliothèque : API REST Supabase.
const NOVA_APP_URL = 'https://gamingcrackwizz.github.io/nova-resell/';  // appli mobile (aussi page de nouveau mot de passe)
const NOVA_DEFAULT = { url: 'https://btbohxtqruyudzxbgwvt.supabase.co', key: 'sb_publishable_VHJLxRBOdQoLWDkRK-ecIg_8RsPcusj' };

const NovaCloud = {
  async cfg() {
    const { novaCloud = {} } = await chrome.storage.local.get('novaCloud');
    const url = (novaCloud.url || (NOVA_DEFAULT.url.startsWith('http') ? NOVA_DEFAULT.url : '')).replace(/\/+$/, '');
    const key = novaCloud.key || (NOVA_DEFAULT.key.startsWith('__') ? '' : NOVA_DEFAULT.key);
    return { ...novaCloud, url, key };
  },
  async save(patch) {
    const { novaCloud = {} } = await chrome.storage.local.get('novaCloud');
    await chrome.storage.local.set({ novaCloud: { ...novaCloud, ...patch } });
  },
  async auth(path, body) {
    const c = await this.cfg();
    if (!c.url || !c.key) throw new Error('Adresse et clé du projet Nova manquantes');
    const r = await fetch(`${c.url}/auth/v1/${path}`, { method: 'POST', headers: { apikey: c.key, 'content-type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(NovaCloud.fr(j.error_description || j.msg || j.message || `Erreur ${r.status}`));
    return j;
  },
  keep(j) { return { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: Math.floor(Date.now() / 1000) + (j.expires_in || 3600), user: { id: j.user?.id, email: j.user?.email } }; },
  async signIn(email, password) {
    const j = await this.auth('token?grant_type=password', { email, password });
    await this.save({ session: this.keep(j) });
    return j.user;
  },
  async signUp(email, password) {
    const j = await this.auth('signup', { email, password });
    if (j.access_token) { await this.save({ session: this.keep(j) }); return { ok: true }; }
    return { confirm: true };
  },
  // E-mail « mot de passe oublié » : le lien ouvre l'appli Nova, qui demande le nouveau mot de passe
  async recover(email) {
    const c = await this.cfg();
    if (!c.url || !c.key) throw new Error('Adresse et clé du projet Nova manquantes');
    const r = await fetch(`${c.url}/auth/v1/recover?redirect_to=${encodeURIComponent(NOVA_APP_URL)}`, { method: 'POST', headers: { apikey: c.key, 'content-type': 'application/json' }, body: JSON.stringify({ email }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(NovaCloud.fr(j.msg || j.error_description || j.message || `Erreur ${r.status}`)); }
    return true;
  },
  fr(m) {
    return /invalid login/i.test(m) ? 'E-mail ou mot de passe incorrect'
      : /not confirmed/i.test(m) ? "E-mail pas encore confirmé : clique sur le lien reçu par e-mail"
      : /already (registered|exists)/i.test(m) ? 'Un compte existe déjà avec cet e-mail : connecte-toi'
      : /rate limit|too many|security purposes/i.test(m) ? 'Trop de demandes : attends quelques minutes puis réessaie'
      : /password/i.test(m) && /6|short|least/i.test(m) ? 'Mot de passe : 6 caractères minimum'
      : /valid email|invalid.*email|email.*invalid/i.test(m) ? "Adresse e-mail invalide"
      : m;
  },
  async signOut() { await this.save({ session: null }); },
  async token() {
    const c = await this.cfg();
    const s = c.session;
    if (!s?.refresh_token) return null;
    if (s.expires_at - 90 > Date.now() / 1000) return { c, s };
    try {
      const j = await this.auth('token?grant_type=refresh_token', { refresh_token: s.refresh_token });
      const ns = this.keep(j); await this.save({ session: ns });
      return { c, s: ns };
    } catch (e) { await this.save({ session: null, lastError: 'Session expirée : reconnecte-toi' }); return null; }
  },
  async rest(method, path, body, prefer) {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/rest/v1/${path}`, { method, headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': 'application/json', ...(prefer ? { prefer } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const txt = await r.text(); let j = null; try { j = txt ? JSON.parse(txt) : null; } catch { /* vide */ }
    if (!r.ok) throw new Error(j?.message || `Erreur ${r.status}`);
    return j;
  },
  async download(path) {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/storage/v1/object/authenticated/photos/${path}`, { headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}` } });
    if (!r.ok) throw new Error('Photo introuvable (' + r.status + ')');
    return r.blob();
  },
  async removePhotos(paths) {
    if (!paths?.length) return;
    const t = await this.token(); if (!t) return;
    await fetch(`${t.c.url}/storage/v1/object/photos`, { method: 'DELETE', headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': 'application/json' }, body: JSON.stringify({ prefixes: paths }) }).catch(() => {});
  },
};

async function blobToDataUrl(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return `data:${blob.type || 'image/jpeg'};base64,${btoa(bin)}`;
}
