// ===== Nova Resell – bordereaux : SKU retrouvé + bande SKU sur l'étiquette (partagé panneau / arrière-plan) =====
const normTitle = (t) => String(t || '').toLowerCase().replace(/\(#?p\d+\)/g, '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();

// Index des SKU : annonces créées par Nova (id → SKU), titres avec SKU, et ton fichier Excel
async function skuIndexLoad() {
  const { skuIndex = {}, excelIndex = {} } = await chrome.storage.local.get(['skuIndex', 'excelIndex']);
  return { items: skuIndex.items || {}, titles: { ...(excelIndex.titles || {}), ...(skuIndex.titles || {}) } };
}
async function skuIndexAdd(entries) {
  const { skuIndex = {} } = await chrome.storage.local.get('skuIndex');
  const items = skuIndex.items || {}, titles = skuIndex.titles || {};
  for (const e of entries) { if (!e.sku) continue; if (e.id) items[e.id] = e.sku; if (e.title) titles[normTitle(e.title)] = e.sku; }
  const trim = (o) => Object.fromEntries(Object.entries(o).slice(-3000));
  await chrome.storage.local.set({ skuIndex: { items: trim(items), titles: trim(titles) } });
}
function resolveSkus(o, idx) {
  if (o.skus?.length) return o.skus;
  const out = new Set();
  for (const id of o.itemIds || []) if (idx?.items?.[id]) out.add(idx.items[id]);
  for (const t of [...(o.itemTitles || []), o.title]) { const k = idx?.titles?.[normTitle(t)]; if (k) out.add(k); }
  return [...out].map((s) => String(s).replace(/^#/, '').toUpperCase());
}
function labelText(o, idx) {
  const skus = resolveSkus(o, idx);
  return (skus.length ? skus.join(' + ') : 'SANS SKU') + '   ·   ' + (o.itemTitles?.length > 1 ? `Lot ${o.itemTitles.length} articles` : String(o.title || '').replace(/\s*\(#P\d+\)\s*$/i, '')).slice(0, 48);
}

async function labelDocCreate() {
  const { PDFDocument, StandardFonts } = PDFLib;
  const pdf = await PDFDocument.create();
  return { pdf, font: await pdf.embedFont(StandardFonts.HelveticaBold) };
}
// Ajoute le bordereau d'une vente (avec sa bande SKU) au document
async function labelAppend(doc, o, getUrl, { skuPos = 'top', idx } = {}) {
  const { PDFDocument, rgb, degrees } = PDFLib;
  const url = await getUrl();
  const res = await fetch(url);
  if (!res.ok) throw new Error('téléchargement impossible (' + res.status + ')');
  const type = res.headers.get('content-type') || '';
  const bytes = await res.arrayBuffer();
  let pages = [];
  if (type.includes('pdf') || new TextDecoder().decode(new Uint8Array(bytes.slice(0, 5))) === '%PDF-') {
    const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
    pages = await doc.pdf.copyPages(src, src.getPageIndices());
    pages.forEach((p) => doc.pdf.addPage(p));
  } else {
    const img = type.includes('png') ? await doc.pdf.embedPng(bytes) : await doc.pdf.embedJpg(bytes);
    const p = doc.pdf.addPage([595, 842]);
    const sc = Math.min(555 / img.width, 760 / img.height);
    p.drawImage(img, { x: (595 - img.width * sc) / 2, y: 842 - 60 - img.height * sc, width: img.width * sc, height: img.height * sc });
    pages = [p];
  }
  const text = labelText(o, idx);
  for (const p of pages) stampSku(p, text, doc.font, rgb, degrees, skuPos);
  return true;
}

// Ajoute une bande avec le SKU AU-DESSUS (ou en dessous) du bordereau, sans rien masquer du bordereau
function stampSku(page, text, font, rgb, degrees, skuPos = 'top') {
  const { x: bx, y: by, width, height } = page.getMediaBox();
  const rot = ((page.getRotation().angle % 360) + 360) % 360;
  const side = rot === 90 || rot === 270;
  const span = side ? height : width;               // largeur visible de la bande
  let size = Math.max(12, Math.min(26, span / 20));
  while (font.widthOfTextAtSize(text, size) > span - 30 && size > 8) size -= 1;
  const w = font.widthOfTextAtSize(text, size);
  const band = size + 22;
  const top = (skuPos || 'top') === 'top';
  const setBox = (x, y, w2, h2) => { page.setMediaBox(x, y, w2, h2); page.setCropBox(x, y, w2, h2); };
  if (!side) {
    const y0 = top ? by + height : by - band;
    setBox(bx, top ? by : by - band, width, height + band);
    page.drawRectangle({ x: bx + (width - w) / 2 - 12, y: y0 + 5, width: w + 24, height: band - 10, color: rgb(1, 1, 1), borderColor: rgb(0, 0, 0), borderWidth: 2 });
    page.drawText(text, { x: bx + (width - w) / 2, y: y0 + 5 + (band - 10 - size) / 2 + size * 0.22, size, font, color: rgb(0, 0, 0) });
  } else {
    // page affichée tournée de 90° : la bande « haut » visible correspond au côté droit (90) ou gauche (270)
    const right = (rot === 90) === top;
    const x0 = right ? bx + width : bx - band;
    setBox(right ? bx : bx - band, by, width + band, height);
    const ang = rot === 90 ? 90 : 270;
    page.drawRectangle({ x: x0 + 5, y: by + (height - w) / 2 - 12, width: band - 10, height: w + 24, color: rgb(1, 1, 1), borderColor: rgb(0, 0, 0), borderWidth: 2 });
    const tx = ang === 90 ? x0 + 5 + (band - 10) / 2 + size * 0.35 : x0 + 5 + (band - 10) / 2 - size * 0.35;
    const ty = ang === 90 ? by + (height - w) / 2 : by + (height + w) / 2;
    page.drawText(text, { x: tx, y: ty, size, font, color: rgb(0, 0, 0), rotate: degrees(ang) });
  }
}

