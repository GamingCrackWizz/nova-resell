// ===== Nova Resell – connexion automatique à Vinted + voyant d'état dans l'en-tête =====
(() => {
  if (/print/.test(location.hash)) return;
  const pill = $('#vStatus'), label = pill.querySelector('.lbl');
  let state = 'connecting', user = null, busy = false, timer = null;
  const LABEL = { connecting: 'Connexion…', ok: 'Connecté', off: 'Déconnecté', captcha: 'Vérification', error: 'Hors ligne' };
  const TIP = {
    connecting: 'Connexion à Vinted en cours…',
    ok: () => `Connecté à Vinted${user ? ' en tant que ' + user : ''}. Clique pour revérifier.`,
    off: "Tu n'es pas connecté à Vinted : clique pour ouvrir la page de connexion.",
    captcha: 'Vinted demande une vérification anti-robot : clique pour l’ouvrir.',
    error: 'Vinted ne répond pas : clique pour réessayer.',
  };
  function show(s) {
    state = s;
    pill.dataset.state = s;
    label.textContent = LABEL[s];
    pill.title = typeof TIP[s] === 'function' ? TIP[s]() : TIP[s];
    pill.setAttribute('aria-label', 'Vinted : ' + LABEL[s]);
  }
  const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rj) => setTimeout(() => rj(new Error('timeout')), ms))]);

  async function ensureTab() {
    let [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
    if (!tab) {
      tab = await chrome.tabs.create({ url: 'https://www.vinted.fr/', active: false, pinned: true });
      await withTimeout(waitLoaded(tab.id), 30000).catch(() => {});
    }
    return tab;
  }

  async function check({ open = true } = {}) {
    if (busy) return;
    busy = true;
    if (state !== 'ok') show('connecting');
    try {
      const { captcha } = await chrome.storage.local.get('captcha');
      if (captcha) { show('captcha'); return; }
      const [existing] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
      if (!existing && !open) { show('error'); return; }
      await ensureTab();
      const me = await withTimeout(vintedRaw('me'), 20000);
      user = me?.login || null;
      show(me?.id ? 'ok' : 'off');
    } catch (e) {
      const m = String(e.message || '');
      if (/CAPTCHA/i.test(m)) show('captcha');
      else if (/401|authori|connect|login|session/i.test(m)) show('off');
      else show('error');
    } finally { busy = false; }
  }

  pill.addEventListener('click', async () => {
    if (state === 'off') { chrome.tabs.create({ url: 'https://www.vinted.fr/', active: true }); return; }
    if (state === 'captcha') { const [t] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' }); if (t) chrome.tabs.update(t.id, { active: true }); else chrome.tabs.create({ url: 'https://www.vinted.fr/' }); return; }
    show('connecting'); check();
  });

  // revérifie : toutes les 2 min, quand l'onglet Vinted change, et quand une vérification est signalée/levée
  const soon = () => { clearTimeout(timer); timer = setTimeout(() => check({ open: false }), 1500); };
  chrome.tabs.onRemoved.addListener(soon);
  chrome.tabs.onUpdated.addListener((_id, info, tab) => { if (info.status === 'complete' && /^https:\/\/www\.vinted\.fr\//.test(tab.url || '')) soon(); });
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.captcha) (c.captcha.newValue ? show('captcha') : soon()); });
  setInterval(() => check({ open: false }), 120000);

  show('connecting');
  check({ open: true }); // à l'ouverture du panneau : ouvre Vinted (onglet épinglé discret) si besoin, puis vérifie la connexion
})();
