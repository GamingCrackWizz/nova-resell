// ===== Nova Resell – affichage du journal d'activité (⚙︎ → Journal) =====
(() => {
  const CATS = [['all', 'Tout'], ['publish', '🚀 Publications'], ['draft', '📝 Brouillons'], ['repost', '🔁 Republications'], ['fav', '❤️ Favoris'], ['msg', '💬 Messages'], ['sale', '🎉 Ventes'], ['error', '⚠️ Erreurs']];
  const VIA = { pc: ['🖥️', 'depuis le PC'], mobile: ['📱', 'depuis le téléphone'], auto: ['🤖', 'automatique'], 'planifié': ['🕒', 'planifié'], vinted: ['🛍️', 'Vinted'] };
  let filter = 'all';
  const dayLabel = (t) => {
    const d = new Date(t), today = new Date(); const y = new Date(); y.setDate(today.getDate() - 1);
    if (d.toDateString() === today.toDateString()) return "Aujourd'hui";
    if (d.toDateString() === y.toDateString()) return 'Hier';
    return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
  };
  async function render() {
    const { activityLog = [] } = await chrome.storage.local.get('activityLog');
    const all = [...activityLog].reverse();
    $('#actFilters').replaceChildren(...CATS.map(([k, label]) => {
      const n = k === 'all' ? all.length : all.filter((e) => e.cat === k).length;
      const b = el('button', { className: 'chip' + (filter === k ? ' active' : ''), textContent: `${label}${n ? ' ' + n : ''}` });
      b.addEventListener('click', () => { filter = k; render(); });
      return b;
    }));
    const today = all.filter((e) => new Date(e.t).toDateString() === new Date().toDateString());
    const cnt = (c) => today.filter((e) => e.cat === c).length;
    $('#actSummary').textContent = today.length ? `Aujourd'hui : ${cnt('publish')} publication(s), ${cnt('repost')} action(s) de republication, ${cnt('fav')} message(s) aux favoris, ${cnt('msg')} réponse(s), ${cnt('error')} erreur(s).` : "Rien aujourd'hui pour l'instant.";
    const shown = filter === 'all' ? all : all.filter((e) => e.cat === filter);
    const list = $('#actList');
    if (!shown.length) { list.replaceChildren(el('div', { className: 'state-msg' }, el('b', { textContent: 'Aucune action' }), 'Les actions de Nova apparaîtront ici.')); return; }
    const out = []; let lastDay = '';
    for (const e of shown.slice(0, 300)) {
      const day = dayLabel(e.t);
      if (day !== lastDay) { out.push(el('div', { className: 'act-day', textContent: day })); lastDay = day; }
      const v = VIA[e.via] || VIA.pc;
      out.push(el('div', { className: 'act-row' + (e.cat === 'error' ? ' err' : '') },
        el('span', { className: 'act-ico', textContent: e.icon || '•' }),
        el('div', { className: 'act-main' }, el('div', { className: 'act-title', textContent: e.title }),
          e.detail ? el('div', { className: 'act-detail', textContent: e.detail }) : null,
          e.err ? el('div', { className: 'act-err', textContent: e.err }) : null),
        el('div', { className: 'act-meta' }, el('span', { textContent: new Date(e.t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) }), el('span', { title: v[1], textContent: v[0] }))));
    }
    list.replaceChildren(...out);
  }
  $('#actClear').addEventListener('click', async () => { if (!confirm('Vider tout le journal d’activité ?')) return; await chrome.storage.local.set({ activityLog: [] }); render(); });
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.activityLog && !document.querySelector('.set-pane[data-set=journal]').hidden) render(); });
  document.querySelector('#settings .seg-btn[data-set=journal]').addEventListener('click', render);
})();
