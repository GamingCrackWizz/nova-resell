// ===== Diagnostic : détecte quand une mise à jour de Vinted casse l'extension =====

const VERSION = chrome.runtime.getManifest().version;
const IGNORE = /clé API|annulé|\[CAPTCHA\]/i;

async function logError(action, message) {
  if (action === 'healthcheck' || IGNORE.test(message)) return;
  const { errorLog = [] } = await chrome.storage.local.get('errorLog');
  errorLog.push({ action, message: String(message).slice(0, 400), time: new Date().toISOString(), version: VERSION });
  await chrome.storage.local.set({ errorLog: errorLog.slice(-30) });
  renderHealth();
}

async function runHealthcheck({ quiet = false } = {}) {
  const btn = $('#healthRun');
  if (btn) { btn.disabled = true; btn.textContent = 'Vérification…'; }
  let result;
  try {
    result = await vintedRaw('healthcheck');
  } catch (e) {
    result = { checks: [{ name: 'Accès à Vinted', ok: false, detail: e.message }], unreachable: true };
  }
  result.time = new Date().toISOString();
  await chrome.storage.local.set({ lastHealth: result });
  if (btn) { btn.disabled = false; btn.textContent = 'Lancer un diagnostic'; }
  renderHealth();
  if (!quiet) toast(healthFailures(result).length ? 'Problème détecté' : 'Tout fonctionne ✓');
  return result;
}

const healthFailures = (h) => (h && !h.unreachable && !h.loggedOut ? h.checks.filter((c) => !c.ok) : []);

async function buildReport() {
  const { lastHealth, errorLog = [] } = await chrome.storage.local.get(['lastHealth', 'errorLog']);
  const lines = [
    `RAPPORT NOVA RESELL v${VERSION} — ${new Date().toLocaleString('fr-FR')}`,
    `Navigateur : ${navigator.userAgent.match(/Chrome\/[\d.]+/)?.[0] || '?'}`,
    '',
    'Diagnostic :',
    ...(lastHealth?.checks || []).map((c) => `${c.ok ? 'OK ' : 'KO '} ${c.name}${c.ok ? '' : ' → ' + c.detail}`),
    '',
    'Dernières erreurs :',
    ...(errorLog.slice(-10).map((e) => `${e.time.slice(0, 16)} [${e.action}] ${e.message}`)),
  ];
  if (!errorLog.length) lines.push('(aucune)');
  return lines.join('\n');
}

async function renderHealth() {
  const { lastHealth, errorLog = [], healthDismissed = 0 } = await chrome.storage.local.get(['lastHealth', 'errorLog', 'healthDismissed']);
  const fails = healthFailures(lastHealth);
  const recentErr = errorLog.filter((e) => new Date(e.time).getTime() > healthDismissed && Date.now() - new Date(e.time).getTime() < 3 * 86400000);
  const banner = $('#healthBanner');
  const problem = fails.length || recentErr.length;
  banner.hidden = !problem;
  if (problem) {
    $('#healthText').textContent = fails.length
      ? `Vinted a probablement changé quelque chose : ${fails.map((f) => f.name).join(', ')}.`
      : `${recentErr.length} erreur(s) récente(s) : ${recentErr[recentErr.length - 1].message.slice(0, 120)}`;
  }
  // panneau de diagnostic dans les réglages
  const list = $('#healthList');
  if (list) {
    list.replaceChildren(...(lastHealth?.checks || []).map((c) => el('div', { className: 'hc ' + (c.ok ? 'ok' : 'ko') }, el('b', { textContent: c.ok ? '✓' : '✕' }), ' ' + c.name, c.ok ? '' : el('small', { textContent: ' — ' + c.detail }))));
    $('#healthTime').textContent = lastHealth ? 'Dernière vérification : ' + new Date(lastHealth.time).toLocaleString('fr-FR') : 'Jamais vérifié';
  }
  const dot = $('#toggleSettings');
  dot.classList.toggle('alert-dot', !!problem);
}

$('#healthCopy').addEventListener('click', async () => {
  await navigator.clipboard.writeText(await buildReport());
  toast('Rapport copié : colle-le à Claude dans ta conversation');
});
$('#healthCopy2').addEventListener('click', async () => {
  await navigator.clipboard.writeText(await buildReport());
  toast('Rapport copié');
});
$('#healthDismiss').addEventListener('click', async () => {
  await chrome.storage.local.set({ healthDismissed: Date.now() });
  const { lastHealth } = await chrome.storage.local.get('lastHealth');
  if (lastHealth) { lastHealth.checks.forEach((c) => (c.ok = true)); await chrome.storage.local.set({ lastHealth }); }
  renderHealth();
});
$('#healthRun').addEventListener('click', () => runHealthcheck());
$('#healthClear').addEventListener('click', async () => { await chrome.storage.local.set({ errorLog: [] }); renderHealth(); toast('Journal vidé'); });

// Vérification automatique : à l'ouverture (si la dernière date de plus de 6 h) puis toutes les 6 h
(async () => {
  renderHealth();
  const { lastHealth } = await chrome.storage.local.get('lastHealth');
  const old = !lastHealth || Date.now() - new Date(lastHealth.time).getTime() > 6 * 3600000;
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (old && tab) runHealthcheck({ quiet: true });
  setInterval(async () => {
    const [t] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
    if (t) runHealthcheck({ quiet: true });
  }, 6 * 3600000);
})();

$('#aboutVersion').textContent = VERSION;

// ---------- Bandeau vérification anti-robot ----------
async function renderCaptcha() {
  const { captcha } = await chrome.storage.local.get('captcha');
  $('#captchaBanner').hidden = !captcha;
}
$('#captchaOpen').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (tab) { await chrome.tabs.update(tab.id, { active: true }); chrome.tabs.reload(tab.id); } else chrome.tabs.create({ url: 'https://www.vinted.fr/' });
});
$('#captchaDone').addEventListener('click', async () => {
  try { await vintedRaw('me'); await chrome.storage.local.remove('captcha'); toast('Vérification OK, les automatismes reprennent'); }
  catch (e) { toast(/CAPTCHA/.test(e.message) ? 'Vinted demande encore la vérification' : 'Erreur : ' + e.message); }
  renderCaptcha();
});
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.captcha) renderCaptcha(); });
renderCaptcha();
