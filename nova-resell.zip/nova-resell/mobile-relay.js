// ===== Nova Resell – pont avec l'appli mobile (page Claude « Nova Resell Mobile ») =====
// Tourne dans les pages Claude. Ne fait rien tant que la page ne s'est pas présentée comme Nova Resell Mobile.
(() => {
  if (window.__novaRelay) return;
  window.__novaRelay = true;
  let paired = false;
  const known = new Set();
  const post = (msg) => window.postMessage({ ...msg, __novaMobile: 'ext' }, '*');
  const toDataUrl = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });

  async function resync() {
    const { mobileResults = {} } = await chrome.storage.local.get('mobileResults');
    for (const [id, patch] of Object.entries(mobileResults)) post({ type: 'job-status', id, patch });
  }

  window.addEventListener('message', async (e) => {
    const m = e.data;
    if (e.source !== window || !m || m.__novaMobile !== 'page') return;
    if (m.type === 'page-hello') {
      if (!paired) { paired = true; resync(); }
      post({ type: 'hello', version: chrome.runtime.getManifest().version });
      return;
    }
    if (!paired) return;
    try {
      if (m.type === 'job') {
        known.add(m.id);
        const photos = [];
        for (const b of m.photos || []) photos.push(await toDataUrl(b));
        const { mobileInbox = [] } = await chrome.storage.local.get('mobileInbox');
        if (!mobileInbox.some((x) => x.jobId === m.id)) mobileInbox.push({ jobId: m.id, photos, ts: Date.now() });
        await chrome.storage.local.set({ mobileInbox });
        chrome.runtime.sendMessage({ va: 'mobileInboxAdded' }).catch(() => {});
      } else if (m.type === 'state-request') {
        const r = await chrome.runtime.sendMessage({ va: 'mobileState' });
        if (r?.ok) post({ type: 'state', state: r.data });
      } else if (m.type === 'action') {
        const r = await chrome.runtime.sendMessage({ va: 'mobileAction', action: m.action, payload: m.payload });
        post({ type: 'action-result', id: m.id, ok: !!r?.ok, error: r?.ok ? null : (r?.error || 'Extension indisponible') });
      }
    } catch (err) {
      if (m.type === 'job') post({ type: 'job-status', id: m.id, patch: { status: 'error', error: String(err.message || err) } });
      if (m.type === 'action') post({ type: 'action-result', id: m.id, ok: false, error: String(err.message || err) });
    }
  });

  // résultats renvoyés par le panneau Nova (analyse, brouillon…)
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local' || !c.mobileResults || !paired) return;
    const nv = c.mobileResults.newValue || {}, ov = c.mobileResults.oldValue || {};
    for (const [id, patch] of Object.entries(nv)) if (JSON.stringify(patch) !== JSON.stringify(ov[id])) post({ type: 'job-status', id, patch });
  });

  // au cas où la page était déjà prête avant nous
  post({ type: 'hello', version: chrome.runtime.getManifest().version, probe: true });
})();
