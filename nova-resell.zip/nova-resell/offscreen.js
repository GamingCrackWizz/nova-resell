// Document invisible : recadre les bordereaux pour l'appli téléphone (appelé par l'arrière-plan)
chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m?.target !== 'nova-offscreen' || m.type !== 'crop') return false;
  const bin = atob(m.b64); const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  novaLabelCrop(u8).then((boxes) => send({ boxes })).catch(() => send({ boxes: null }));
  return true;
});
