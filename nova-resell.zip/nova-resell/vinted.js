// ===== Nova Resell – script qui tourne dans les pages vinted.fr =====
// Il utilise ta session Vinted (tu es connecté) pour lire tes annonces,
// republier et préremplir les messages. Il n'envoie JAMAIS de message tout seul.

(() => {
  if (window.__vintedAssistant) return;
  window.__vintedAssistant = true;

  const csrf = () => (document.documentElement.innerHTML.match(/CSRF_TOKEN\\?"?\s*[:=]\s*\\?"([0-9a-f-]{20,})/) || [])[1] || '';
  const anon = () => (document.cookie.match(/anon_id=([^;]+)/) || [])[1] || '';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  let captchaFlag = false;
  chrome.storage.local.get('captcha').then((s) => { captchaFlag = !!s.captcha; }).catch(() => {});

  // ---------- Pont vers la page (fetch de Vinted, avec ses protections) ----------
  const pending = new Map();
  let bridgeOk = null;
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__nova !== 'res') return;
    const p = pending.get(e.data.id); if (!p) return;
    pending.delete(e.data.id); p(e.data);
  });
  function viaPage(url, { method = 'GET', headers = {}, body, form } = {}) {
    return new Promise((resolve, reject) => {
      const id = Math.random().toString(36).slice(2) + Date.now();
      const t = setTimeout(() => { pending.delete(id); reject(new Error('pont-timeout')); }, 60000);
      pending.set(id, (r) => { clearTimeout(t); r.error ? reject(new Error(r.error)) : resolve(r); });
      window.postMessage({ __nova: 'req', id, url, method, headers, body, form }, location.origin);
    });
  }
  async function bridgeReady() {
    if (bridgeOk !== null) return bridgeOk;
    try {
      await Promise.race([viaPage('/api/v2/conversations/stats', { headers: { accept: 'application/json' } }), new Promise((_, rj) => setTimeout(() => rj(new Error('x')), 2500))]);
      bridgeOk = true;
    } catch { bridgeOk = false; }
    return bridgeOk;
  }
  // Requête HTTP : par la page si possible, sinon fetch direct
  async function http(url, opts) {
    if (await bridgeReady()) {
      const r = await viaPage(url, opts);
      let data = null; try { data = r.text ? JSON.parse(r.text) : null; } catch { /* pas du JSON */ }
      return { status: r.status, ok: r.ok, data, captcha: r.status === 403 && /captcha-delivery|datadome/i.test(r.text || '') };
    }
    let body = opts.body;
    if (opts.form) { body = new FormData(); for (const [k, v, n] of opts.form) (v instanceof Blob ? body.append(k, v, n || 'file') : body.append(k, v)); }
    const res = await fetch(url, { method: opts.method, headers: opts.headers, body, credentials: 'include' });
    const text = await res.text();
    let data = null; try { data = JSON.parse(text); } catch { /* vide */ }
    return { status: res.status, ok: res.ok, data, captcha: res.status === 403 && /captcha-delivery|datadome/i.test(text) };
  }

  // Renouvelle la session Vinted (comme le site le fait tout seul quand le jeton expire)
  let refreshing = null;
  async function refreshSession() {
    refreshing ||= http('/web/api/auth/refresh', { method: 'POST', headers: { accept: 'application/json', 'x-csrf-token': csrf(), 'x-anon-id': anon() } })
      .then((r) => r.ok).catch(() => false).finally(() => setTimeout(() => (refreshing = null), 1000));
    return refreshing;
  }

  async function api(path, { method = 'GET', body, json, form, headers = {} } = {}, retried = false) {
    const h = { accept: 'application/json', 'x-csrf-token': csrf(), 'x-anon-id': anon(), ...headers };
    let payload = body;
    if (json !== undefined) { h['content-type'] = 'application/json'; payload = JSON.stringify(json); }
    const url = path.startsWith('http') ? path : '/api/v2' + path;
    const res = await http(url, { method, body: payload, form, headers: h });
    if (res.status === 401 && !retried) {
      if (await refreshSession()) return api(path, { method, body, json, form, headers }, true);
    }
    const data = res.data;
    if (res.captcha) {
      await chrome.storage.local.set({ captcha: { since: Date.now(), url: data?.url || '' } }).catch(() => {});
      captchaFlag = true;
      throw new Error('[CAPTCHA] Vinted demande une vérification anti-robot : ouvre vinted.fr et passe-la, puis réessaie.');
    }
    if (res.ok && captchaFlag) { captchaFlag = false; chrome.storage.local.remove('captcha').catch(() => {}); }
    if (!res.ok || (data && data.code && data.code !== 0)) {
      const detail = data?.errors?.map((e) => e.value || e.field).filter(Boolean).join(', ');
      const hint = res.status === 401 ? ' (session Vinted expirée : recharge la page vinted.fr et reconnecte-toi si besoin)' : '';
      throw new Error((data?.message || 'Erreur Vinted') + (detail ? ' : ' + detail : '') + hint + ` [HTTP ${res.status} ${method} ${url.replace(/\d{5,}/g, 'N').split('?')[0]}]`);
    }
    return data || {};
  }

  const priceOf = (p) => (p && typeof p === 'object' ? Number(p.amount) : Number(p)) || 0;

  async function me() {
    return (await api('/users/current')).user;
  }

  // Tes annonces en ligne (hors brouillons, vendues, réservées, masquées)
  async function wardrobe() {
    const user = await me();
    const items = [];
    for (let page = 1; page <= 10; page++) {
      const j = await api(`/wardrobe/${user.id}/items?page=${page}&per_page=96&order=newest_first`);
      items.push(...(j.items || []));
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    return items
      .filter((i) => !i.is_draft && !i.is_closed && !i.is_reserved && !i.is_hidden)
      .map((i, idx) => ({
        id: i.id,
        title: i.title,
        price: priceOf(i.price),
        photo: i.photos?.[0]?.url || '',
        favs: i.favourite_count || 0,
        views: i.view_count || 0,
        rank: idx, // 0 = la plus récente
        ts: (i.photos?.[0]?.high_resolution?.timestamp || 0) * 1000, // date de mise en ligne (photos)
      }));
  }

  async function uploadPhoto(blob, uuid, n) {
    const form = [['photo[type]', 'item'], ['photo[file]', new Blob([blob], { type: blob.type || 'image/jpeg' }), `photo${n}.jpg`], ['photo[temp_uuid]', uuid]];
    const r = await api('/photos', { method: 'POST', form });
    const pid = r.id ?? r.photo?.id;
    if (!pid) throw new Error("Échec de l'envoi d'une photo");
    return pid;
  }

  // ---------- Références Vinted (catégories, couleurs, tailles…) ----------
  let refsCache = null;
  async function refs() {
    if (refsCache) return refsCache;
    const cat = await api('/item_upload/catalogs');
    const leaves = [];
    const walk = (c, path) => {
      const p = [...path, c.title];
      if (c.catalogs?.length) c.catalogs.forEach((x) => walk(x, p));
      else leaves.push({ id: c.id, path: p.join(' > ') });
    };
    (cat.catalogs || []).forEach((c) => walk(c, []));
    const colors = ((await api('/item_upload/colors')).colors || []).map((c) => ({ id: c.id, t: c.title }));
    refsCache = { leaves, colors };
    return refsCache;
  }

  async function attributes({ catalogId }) {
    const j = await api('/item_upload/attributes', { method: 'POST', json: { attributes: [{ code: 'category', value: [catalogId] }] } });
    const flat = (opts, group) => (opts || []).flatMap((o) => (o.options?.length ? flat(o.options, o.title) : [{ id: o.id, t: o.title, g: group || '' }]));
    const out = {};
    for (const a of j.attributes || []) if (a.configuration?.options) out[a.code] = flat(a.configuration.options);
    let packages = [];
    try {
      const ps = await api(`https://api.vinted.fr/shipping-estimation/external/catalogs/${catalogId}/package_sizes`);
      packages = (ps.package_sizes || []).filter((x) => x.standard).map((x) => ({ id: x.id, code: x.code }));
    } catch { /* tailles de colis par défaut */ }
    out.packages = packages;
    return out;
  }

  async function brand({ keyword }) {
    if (!keyword) return null;
    const j = await api('/item_upload/brands?keyword=' + encodeURIComponent(keyword));
    const list = j.brands || [];
    const norm = (x) => String(x).toLowerCase().replace(/[^a-z0-9]/g, '');
    return list.find((b) => norm(b.title) === norm(keyword)) || list[0] || null;
  }

  function buildDraft(d, uuid, photoIds) {
    const attrs = [];
    if (d.condition_id) attrs.push({ code: 'condition', ids: [d.condition_id] });
    if (d.size_id) attrs.push({ code: 'size', ids: [d.size_id] });
    if (d.material_ids?.length) attrs.push({ code: 'material', ids: d.material_ids.slice(0, 3) });
    return {
      id: d.id || null, currency: 'EUR', temp_uuid: uuid,
      title: d.title, description: d.description,
      brand_id: d.brand_id || null, brand: d.brand || '',
      catalog_id: d.catalog_id || null, isbn: null, is_unisex: false, ai_photo: false,
      price: d.price, package_size_id: d.package_size_id || null,
      shipment_prices: { domestic: null, international: null },
      color_ids: (d.color_ids || []).slice(0, 2),
      assigned_photos: photoIds.map((id) => ({ id, orientation: 0 })),
      measurement_length: null, measurement_width: null,
      item_attributes: attrs, manufacturer: null, manufacturer_labelling: null,
    };
  }
  async function uploadAll(dataUrls, uuid) {
    const ids = [];
    for (const u of dataUrls) ids.push(await uploadPhoto(await (await fetch(u)).blob(), uuid, ids.length + 1));
    return ids;
  }

  // Crée un brouillon Vinted à partir des photos (dataURL) et des champs déjà résolus en identifiants
  async function createDraft(d) {
    const uuid = crypto.randomUUID();
    const photoIds = await uploadAll(d.photos, uuid);
    const r = await api('/item_upload/drafts', { method: 'POST', json: { draft: buildDraft(d, uuid, photoIds), parcel: null, upload_session_id: uuid } });
    const id = r.draft?.id ?? r.item?.id ?? r.id;
    if (!id) throw new Error("Vinted n'a pas confirmé le brouillon");
    return { id, photoIds };
  }

  // Met à jour un brouillon existant (photos ré-envoyées seulement si elles ont changé)
  async function updateDraft(d) {
    const uuid = crypto.randomUUID();
    const photoIds = d.photos ? await uploadAll(d.photos, uuid) : d.photoIds;
    await api(`/item_upload/drafts/${d.id}`, { method: 'PUT', json: { draft: buildDraft(d, uuid, photoIds), parcel: null, upload_session_id: uuid } });
    return { id: d.id, photoIds };
  }

  // Fourchette de prix conseillée par Vinted
  async function priceSuggestion({ catalog_id, brand_id, condition_id, size_id }) {
    const body = { category_id: Number(catalog_id), brand_id: brand_id ? Number(brand_id) : null, condition_id: condition_id ? Number(condition_id) : null };
    if (size_id) body.attributes = [{ code: 'size', value: [Number(size_id)] }];
    const j = await api('https://api.vinted.fr/upload-form-suggestions/item_price_suggestions', { method: 'POST', json: body });
    const s = j.price_suggestion;
    if (!s) return null;
    return { min: Number(s.minimum?.amount) || 0, mid: Number(s.midpoint?.amount) || 0, max: Number(s.maximum?.amount) || 0 };
  }

  // Contacte une personne qui a mis un article en favori : vraie offre Vinted + message
  async function contactFav({ itemId, userId, body, offerPrice }) {
    const c = await api('/conversations', { method: 'POST', json: { initiator: 'seller_enters_notification', item_id: Number(itemId), opposite_user_id: Number(userId) } });
    const conv = c.conversation;
    if (!conv?.id) throw new Error('Conversation non créée');
    let offered = false;
    const tid = conv.transaction?.id;
    if (offerPrice && tid) {
      try {
        await api(`/transactions/${tid}/offers`, { method: 'POST', json: { offer: { price: Number(offerPrice).toFixed(2), currency: 'EUR' } } });
        offered = true;
      } catch (e) { /* l'offre peut être refusée (prix trop bas…) : on envoie quand même le message */ }
    }
    if (body) {
      await api(`/conversations/${conv.id}/replies`, { method: 'POST', json: { reply: { body, photo_temp_uuids: [], is_personal_data_sharing_check_skipped: false } } });
    }
    return { conversationId: conv.id, offered };
  }

  // Tes brouillons Vinted
  async function drafts() {
    const user = await me();
    const out = [];
    for (let page = 1; page <= 10; page++) {
      const j = await api(`/wardrobe/${user.id}/items?page=${page}&per_page=96&order=newest_first`);
      out.push(...(j.items || []).filter((i) => i.is_draft));
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    return out.map((i) => ({
      id: i.id, title: i.title, price: priceOf(i.price), photo: i.photos?.[0]?.url || '',
      brand: i.brand_title || i.brand || '', size: i.size_title || i.size || '',
      ts: (i.photos?.[0]?.high_resolution?.timestamp || 0) * 1000,
    }));
  }

  // Item complet (format formulaire Vinted) à partir d'une annonce ou d'un brouillon existant
  function toUploadItem(it, { id, uuid, photoIds, price }) {
    return {
      id, currency: it.currency || 'EUR', temp_uuid: uuid,
      title: it.title, description: it.description,
      brand_id: it.brand_id, brand: it.brand_dto?.title || '',
      catalog_id: it.catalog_id, isbn: it.isbn || null, is_unisex: !!it.is_unisex, ai_photo: !!it.ai_photo,
      price: price ?? priceOf(it.price), package_size_id: it.package_size_id,
      shipment_prices: { domestic: null, international: null },
      color_ids: [it.color1_id, it.color2_id].filter(Boolean),
      assigned_photos: photoIds.map((pid) => ({ id: pid, orientation: 0 })),
      measurement_length: it.measurement_length ?? null, measurement_width: it.measurement_width ?? null,
      item_attributes: it.item_attributes || [],
      manufacturer: it.manufacturer ?? null, manufacturer_labelling: it.manufacturer_labelling ?? null,
    };
  }

  // Publie un brouillon (comme le bouton « Ajouter » de Vinted)
  async function publishDraft({ id }) {
    const it = (await api(`/item_upload/items/${id}`)).item;
    if (!it) throw new Error('Brouillon introuvable');
    const missing = [];
    if (!it.catalog_id) missing.push('catégorie');
    if (!it.package_size_id) missing.push('format de colis');
    if (!(it.item_attributes || []).some((a) => a.code === 'condition')) missing.push('état');
    if (missing.length) throw new Error('Il manque : ' + missing.join(', ') + '. Ouvre le brouillon pour compléter.');
    const uuid = crypto.randomUUID();
    const photoIds = [...(it.photos || [])].sort((a, b) => (a.image_no || 0) - (b.image_no || 0)).map((p) => p.id);
    const draft = toUploadItem(it, { id, uuid, photoIds });
    await api(`/item_upload/drafts/${id}/completion`, { method: 'POST', json: { draft, push_up: false, parcel: null, upload_session_id: uuid } });
    return { id };
  }

  async function deleteDraft({ id }) {
    await api(`/item_upload/drafts/${id}`, { method: 'DELETE' });
    return { id };
  }

  // Republier : copie l'annonce (photos comprises), vérifie la copie, puis supprime l'ancienne
  async function repost({ id, price, mode = 'publish' }) {
    const it = (await api(`/item_upload/items/${id}`)).item;
    if (!it) throw new Error('Annonce introuvable');
    const uuid = crypto.randomUUID();

    // 1. Ré-envoi des photos
    const photos = [...(it.photos || [])].sort((a, b) => (a.image_no || 0) - (b.image_no || 0));
    const photoIds = [];
    for (const p of photos) photoIds.push(await uploadPhoto(await (await fetch(p.full_size_url || p.url)).blob(), uuid, photoIds.length + 1));

    // 2. Copie de l'annonce
    const item = toUploadItem(it, { id: null, uuid, photoIds, price });

    let created;
    if (mode === 'draft') {
      created = await api('/item_upload/drafts', { method: 'POST', json: { draft: item, parcel: null, upload_session_id: uuid } });
    } else {
      created = await api('/item_upload/items', {
        method: 'POST',
        json: { item, push_up: false, parcel: null, upload_session_id: uuid },
        headers: { 'X-Upload-Form': 'true' },
      });
    }
    const newId = created.item?.id ?? created.draft?.id ?? created.id;
    if (!newId) throw new Error("Vinted n'a pas confirmé la nouvelle annonce : l'ancienne est conservée");

    // 3. Vérification puis suppression de l'ancienne (seulement en mode publication)
    if (mode === 'draft') return { newId, deleted: false };
    let lastErr = null;
    for (const wait of [2000, 4000, 8000]) {
      await sleep(wait);
      try {
        await api(`/items/${id}/delete`, { method: 'POST' });
        return { newId, deleted: true };
      } catch (e) { lastErr = e; }
    }
    return { newId, deleted: false, warning: "Copie publiée mais l'ancienne n'a pas pu être supprimée : " + (lastErr?.message || '') };
  }

  async function deleteItem({ id }) {
    await api(`/items/${id}/delete`, { method: 'POST' });
    return { id };
  }

  // Personnes qui ont mis tes articles en favori (notifications)
  async function favorites() {
    const out = [];
    for (let page = 1; page <= 5; page++) {
      const j = await api(`https://api.vinted.fr/inbox-notifications/v1/notifications?page=${page}&per_page=20`);
      for (const n of j.notifications || []) {
        if (n.entry_type !== 20) continue;
        const q = new URL(String(n.link || '').replace(/^[a-z]+:\/\//, 'https://x/')).searchParams;
        const body = String(n.body || '');
        out.push({
          id: n.id,
          itemId: Number(q.get('item_id') || n.subject_id),
          userId: Number(q.get('user_id')),
          pseudo: body.split(' ')[0],
          article: (body.match(/ton article (.+?) comme favori/) || [])[1] || '',
          photo: n.small_photo_url || n.photo?.url || '',
          date: n.updated_at,
        });
      }
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    return out.filter((f) => f.userId && f.itemId);
  }

  // ---------- Ventes & bordereaux ----------
  const skusOf = (titles) => [...new Set(titles.flatMap((t) => [...String(t || '').matchAll(/#\s*(P\d+)/gi)].map((m) => m[1].toUpperCase())))];

  async function sales({ pages = 3 } = {}) {
    const orders = [];
    for (let page = 1; page <= pages; page++) {
      const j = await api(`/my_orders?type=sold&status=all&page=${page}&per_page=20`);
      orders.push(...(j.my_orders || []));
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    const out = [];
    for (const o of orders) {
      const row = {
        transactionId: o.transaction_id, conversationId: o.conversation_id, title: o.title,
        price: priceOf(o.price), date: o.date, photo: o.photo?.url || o.photo_url || '',
        // « needs_action » = une action est attendue de toi (ex. expédier) : c'est une vente en cours comme « waiting »
        userStatus: o.transaction_user_status === 'needs_action' ? 'waiting' : o.transaction_user_status, needsAction: o.transaction_user_status === 'needs_action',
        statusTitle: o.status, skus: skusOf([o.title]),
      };
      if (row.userStatus === 'waiting') {
        try {
          const t = (await api(`/transactions/${o.transaction_id}`)).transaction;
          const titles = (t.order?.items || []).map((i) => i.title).concat(t.item_title || [], t.title || []);
          row.itemTitles = (t.order?.items || []).map((i) => i.title);
          row.itemIds = [...new Set([...(t.order?.items || []).map((i) => i.id || i.item_id), t.item_id].filter(Boolean))];
          row.skus = skusOf(titles.length ? titles : [o.title]);
          row.shipmentId = t.shipment?.id;
          row.shipmentStatus = t.shipment?.status;
          row.statusTitle = t.shipment?.status_title || row.statusTitle;
          row.txStatus = t.status; row.txStatusTitle = t.status_title || '';
          row.isReturn = !!t.suspending_complaint_id || /retour|litige/i.test(t.status_title || '');
          if (row.isReturn) {
            row.complaintId = t.suspending_complaint_id || null;
            if (row.complaintId) {
              try {
                const c = (await api(`/complaints/${row.complaintId}`)).complaint || {};
                row.returnInfo = {
                  type: c.type || '', notAsDescribed: !!c.is_snad, resolution: c.preferred_resolution || '',
                  refund: priceOf(c.estimated_release?.total_estimated_refund) || null,
                  message: String(c.message || '').slice(0, 400), escalated: !!c.escalated,
                };
              } catch { /* litige indisponible */ }
            }
          }
          // Suivi : dernière étape + date de livraison estimée (écrite par Vinted dans la conversation)
          if (row.isReturn || (row.shipmentStatus >= 300 && o.conversation_id)) {
            try { Object.assign(row, await trackingOf(o.conversation_id, row.isReturn)); } catch { /* suivi indisponible */ }
          }
        } catch { /* détail indisponible */ }
      }
      out.push(row);
    }
    return out;
  }

  const MONTHS = { janv: 0, jan: 0, févr: 1, fevr: 1, fév: 1, fev: 1, mars: 2, mar: 2, avr: 3, mai: 4, juin: 5, juil: 6, août: 7, aout: 7, sept: 8, sep: 8, oct: 9, nov: 10, déc: 11, dec: 11 };
  // « 19 oct. - 21 oct. » · « 19 - 21 oct. » · « 19 oct. » → { from, to } (horodatages)
  function parseEta(txt) {
    const parts = [...String(txt).matchAll(/(\d{1,2})(?:\s*([a-zéèûô]{3,5})\.?)?/gi)].map((m) => ({ d: Number(m[1]), m: m[2] ? MONTHS[m[2].toLowerCase()] : undefined }));
    if (!parts.length) return null;
    const lastM = [...parts].reverse().find((p) => p.m !== undefined)?.m;
    if (lastM === undefined) return null;
    const now = new Date();
    const mk = (p) => { const m = p.m ?? lastM; let y = now.getFullYear(); if (m < now.getMonth() - 6) y++; if (m > now.getMonth() + 6) y--; return new Date(y, m, p.d, 12).getTime(); };
    const from = mk(parts[0]), to = mk(parts[parts.length - 1]);
    return { from, to: Math.max(from, to) };
  }
  async function trackingOf(conversationId, isReturn) {
    const conv = (await api(`/conversations/${conversationId}`)).conversation || {};
    const msgs = (conv.messages || []).filter((m) => m.entity_type !== 'message');
    let start = 0;
    if (isReturn) { const k = msgs.map((m) => m.entity?.title || '').findLastIndex((t) => /suspendu|probl[eè]me|retour|litige/i.test(t)); if (k >= 0) start = k; }
    const after = msgs.slice(start);
    const out = {};
    const last = [...after].reverse().find((m) => (m.entity?.title || '').trim());
    if (last) out.lastEvent = { title: last.entity.title.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(), at: last.created_at_ts || null };
    for (const m of [...after].reverse()) {
      const txt = JSON.stringify(m.entity || {}).replace(/\\u003c|<[^>]+>/g, ' ');
      const mm = txt.match(/Livraison estim[ée]+e?\s*:\s*([^"\\]+?)(?:\s{2,}|informations|\\n|"|$)/i);
      if (mm) { const eta = parseEta(mm[1]); if (eta) { out.eta = { ...eta, text: mm[1].trim() }; break; } }
    }
    return out;
  }

  async function labelUrl({ shipmentId }) {
    const j = await api(`/shipments/${shipmentId}/label_url`);
    if (!j.label_url) throw new Error("Bordereau pas encore disponible (génère-le d'abord sur Vinted)");
    return j.label_url;
  }

  async function dashboard() {
    const user = await me();
    let online = 0, drafts = 0;
    for (let page = 1; page <= 10; page++) {
      const j = await api(`/wardrobe/${user.id}/items?page=${page}&per_page=96&order=newest_first`);
      for (const i of j.items || []) { if (i.is_draft) drafts++; else if (!i.is_closed && !i.is_reserved && !i.is_hidden) online++; }
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    return { online, drafts };
  }

  // ---------- Agent IA : conversations où l'acheteur attend une réponse ----------
  async function inboxPending({ maxAgeHours = 72, handled = {} } = {}) {
    const user = await me();
    const inbox = (await api('/inbox?page=1&per_page=20')).conversations || [];
    const out = [];
    for (const c of inbox) {
      if (Date.now() - new Date(c.updated_at).getTime() > maxAgeHours * 3600000) continue;
      const conv = (await api('/conversations/' + c.id)).conversation;
      if (!conv?.allow_reply || conv.transaction?.current_user_side !== 'seller') continue;
      const msgs = (conv.messages || []).filter((m) => (m.entity_type === 'message' && m.entity?.body) || m.entity_type === 'offer_request_message');
      const last = msgs[msgs.length - 1];
      if (!last || last.entity.user_id === user.id) continue;       // dernier message = le mien → rien à faire
      const lastId = String(last.entity.id ?? last.entity.offer_request_id ?? last.created_at_ts);
      if (handled[c.id] === lastId) continue;                       // déjà traité
      let offer = null;
      if (last.entity_type === 'offer_request_message') {
        const st = String(last.entity.status_title || '') + ' ' + String(last.entity.status ?? '');
        if (/accept|refus|declin|expir|annul/i.test(st)) { continue; }
        const amount = Number(String(last.entity.price_label || last.entity.body || '').replace(/\s/g, '').match(/(\d+(?:[.,]\d+)?)\s*€/)?.[1]?.replace(',', '.'));
        offer = { amount: amount || null, transactionId: last.entity.transaction_id || conv.transaction?.id };
      }
      const t = conv.transaction || {};
      let item = { title: t.item_title || '', description: '', price: priceOf(t.offer_price) };
      if (t.item_id && !t.is_bundle) {
        try {
          const it = (await api(`/item_upload/items/${t.item_id}`)).item;
          item = { title: it.title, description: it.description, price: priceOf(it.price) };
        } catch { /* article vendu ou supprimé */ }
      }
      out.push({
        conversationId: c.id, lastId, offer, transactionId: conv.transaction?.id, pseudo: conv.opposite_user?.login || '',
        sold: [230, 300, 400, 450, 500].includes(t.status) || /vendu|payé|expédi/i.test(t.status_title || ''),
        isBundle: !!t.is_bundle, itemCount: t.item_count || 1, item,
        history: (conv.messages || []).slice(-12).map((m) => {
          if (m.entity_type === 'message') return { who: m.entity.user_id === user.id ? 'vendeur' : 'acheteur', text: m.entity.body };
          if (m.entity_type === 'offer_request_message') return { who: 'système', text: `Offre de l'acheteur : ${m.entity.price_label || ''} (${m.entity.status_title || ''})` };
          return m.entity?.title ? { who: 'système', text: m.entity.title } : null;
        }).filter(Boolean),
      });
      if (out.length >= 5) break;
    }
    return out;
  }

  async function sellerOffer({ transactionId, price }) {
    await api(`/transactions/${transactionId}/offers`, { method: 'POST', json: { offer: { price: Number(price).toFixed(2), currency: 'EUR' } } });
    return { ok: true };
  }

  async function reply({ conversationId, body }) {
    await api(`/conversations/${conversationId}/replies`, { method: 'POST', json: { reply: { body, photo_temp_uuids: [], is_personal_data_sharing_check_skipped: false } } });
    return { ok: true };
  }

  // ---------- SKU : plus grand numéro déjà utilisé sur le compte ----------
  async function allMyItems() {
    const user = await me();
    const items = [];
    for (let page = 1; page <= 15; page++) {
      const j = await api(`/wardrobe/${user.id}/items?page=${page}&per_page=96&order=newest_first`);
      items.push(...(j.items || []));
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    return items;
  }
  async function maxSku() {
    let max = 0;
    for (const i of await allMyItems()) for (const m of String(i.title || '').matchAll(/#\s*P(\d+)/gi)) max = Math.max(max, Number(m[1]));
    try {
      const j = await api('/my_orders?type=sold&status=all&page=1&per_page=20');
      for (const o of j.my_orders || []) for (const m of String(o.title || '').matchAll(/#\s*P(\d+)/gi)) max = Math.max(max, Number(m[1]));
    } catch { /* ignore */ }
    return max;
  }

  // ---------- Statistiques : ventes + date de mise en ligne des articles vendus ----------
  async function statsData() {
    const orders = [];
    for (let page = 1; page <= 6; page++) {
      const j = await api(`/my_orders?type=sold&status=all&page=${page}&per_page=20`);
      orders.push(...(j.my_orders || []));
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    const items = await allMyItems();
    return {
      sales: orders.map((o) => ({ title: o.title, price: priceOf(o.price), date: o.date, status: o.transaction_user_status })),
      items: items.map((i) => ({ title: i.title, price: priceOf(i.price), brand: i.brand_title || (typeof i.brand === 'string' ? i.brand : i.brand?.title) || '', listed: (i.photos?.[0]?.high_resolution?.timestamp || 0) * 1000, sold: i.item_closing_action === 'sold' || (i.is_closed && !i.is_draft), draft: i.is_draft, favs: i.favourite_count || 0, views: i.view_count || 0 })),
    };
  }

  // ---------- Évaluations reçues (avis des acheteurs) et réponse publique sous l'avis ----------
  async function feedbacks({ pages = 2 } = {}) {
    const user = await me(); const out = [];
    for (let page = 1; page <= pages; page++) {
      const j = await api(`/user_feedbacks?user_id=${user.id}&page=${page}&per_page=40&by=user`);
      for (const f of j.user_feedbacks || []) {
        if (f.system_feedback) continue;
        out.push({ id: f.id, rating: f.rating, text: f.feedback || '', date: f.created_at_ts || f.created_at, canComment: !!f.can_comment, replied: !!f.comment?.comment, author: f.user?.login || '', photo: f.user?.photo?.thumbnails?.[0]?.url || f.user?.photo?.url || '', itemId: f.item_id });
      }
      if (!j.pagination || page >= j.pagination.total_pages) break;
    }
    return out;
  }
  async function feedbackReply({ id, comment }) {
    await api(`/user_feedbacks/${id}/comment`, { method: 'PUT', json: { comment } });
    return true;
  }

  // ---------- Diagnostic : vérifie (en lecture seule) que tout ce qu'utilise l'extension marche encore ----------
  async function healthcheck() {
    const checks = [];
    const run = async (name, fn) => {
      try { const detail = await fn(); checks.push({ name, ok: true, detail: detail || '' }); }
      catch (e) { checks.push({ name, ok: false, detail: e.message }); }
    };
    const must = (cond, msg) => { if (!cond) throw new Error(msg); };
    let user = null;
    await run('Jeton de sécurité Vinted', async () => must(csrf(), 'CSRF_TOKEN introuvable dans la page'));
    await run('Connexion au compte', async () => { user = await me(); must(user?.id, 'utilisateur introuvable'); });
    if (!user) return { checks, loggedOut: true };
    await run('Lecture des annonces', async () => { const j = await api(`/wardrobe/${user.id}/items?page=1&per_page=2`); must(Array.isArray(j.items), 'format « items » changé'); must(!j.items[0] || ('is_draft' in j.items[0] && j.items[0].photos), 'champs des annonces changés'); });
    await run('Catégories', async () => { const r = await refs(); must(r.leaves.length > 500, 'liste des catégories vide'); must(r.colors.length > 10, 'liste des couleurs vide'); });
    await run('Tailles / états / matières', async () => { const a = await attributes({ catalogId: 190 }); must(a.condition?.length, 'champ « condition » absent'); must(a.size?.length, 'champ « size » absent'); });
    await run('Marques', async () => { const b = await brand({ keyword: 'Nike' }); must(b?.id, 'recherche de marque vide'); });
    await run('Prix conseillé', async () => { const p = await priceSuggestion({ catalog_id: 190, brand_id: 94, condition_id: 2 }); must(p?.max, 'format de suggestion changé'); });
    await run('Ventes', async () => { const j = await api('/my_orders?type=sold&status=all&page=1&per_page=2'); must(Array.isArray(j.my_orders), 'format des commandes changé'); });
    await run('Messagerie', async () => { const j = await api('/inbox?page=1&per_page=2'); must(Array.isArray(j.conversations), 'format de la messagerie changé'); });
    await run('Favoris (notifications)', async () => { const j = await api('https://api.vinted.fr/inbox-notifications/v1/notifications?page=1&per_page=2'); must(Array.isArray(j.notifications), 'format des notifications changé'); });
    return { checks, loggedOut: false };
  }

  // Messages reçus depuis le panneau latéral
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    const handlers = { ping: async () => 'pong', me, wardrobe, repost, favorites, refs, attributes, brand, createDraft, updateDraft, priceSuggestion, contactFav, deleteItem, drafts, publishDraft, deleteDraft, healthcheck, sales, labelUrl, dashboard, inboxPending, reply, sellerOffer, maxSku, statsData, feedbacks, feedbackReply };
    const fn = handlers[msg?.va];
    if (!fn) return false;
    fn(msg.args || {})
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  });

  // Préremplissage du message dans une conversation (tu cliques toi-même sur Envoyer)
  async function prefill() {
    if (!location.pathname.startsWith('/inbox')) return;
    const { pendingPrefill: p } = await chrome.storage.local.get('pendingPrefill');
    if (!p || Date.now() - p.ts > 3 * 60 * 1000) return;
    let ta = null;
    for (let i = 0; i < 40 && !ta; i++) { ta = document.querySelector('#composerInput, textarea[data-testid="composer--input"]'); if (!ta) await sleep(400); }
    if (!ta) return;
    await chrome.storage.local.remove('pendingPrefill');
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, p.text);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.focus();
    const tip = document.createElement('div');
    tip.textContent = '✦ Message préparé par Nova Resell : relis-le puis envoie-le';
    Object.assign(tip.style, {
      position: 'fixed', left: '50%', bottom: '24px', transform: 'translateX(-50%)', zIndex: 99999,
      background: 'linear-gradient(135deg,#0B1226,#1E2A5A)', color: '#fff', border: '1px solid #22D3EE', padding: '10px 16px', borderRadius: '10px',
      font: '600 14px system-ui, sans-serif', boxShadow: '0 6px 20px rgba(0,0,0,.2)',
    });
    document.body.append(tip);
    setTimeout(() => tip.remove(), 6000);
  }
  prefill();
})();

// ===== Réponses rapides dans les conversations Vinted =====
(() => {
  if (window.__vaReplies) return;
  window.__vaReplies = true;
  let ctx = { id: null, pseudo: '', article: '', prix: '' };

  async function context() {
    const id = location.pathname.match(/\/inbox\/(\d+)/)?.[1];
    if (!id) return ctx;
    if (ctx.id === id) return ctx;
    ctx = { id, pseudo: '', article: '', prix: '' };
    try {
      const csrf = (document.documentElement.innerHTML.match(/CSRF_TOKEN\\?"?\s*[:=]\s*\\?"([0-9a-f-]{20,})/) || [])[1] || '';
      const r = await fetch('/api/v2/conversations/' + id, { headers: { accept: 'application/json', 'x-csrf-token': csrf } });
      const c = (await r.json()).conversation;
      ctx.pseudo = c?.opposite_user?.login || '';
      ctx.article = (c?.transaction?.item_title || '').replace(/\s*\(#P\d+\)\s*$/, '');
      ctx.prix = c?.transaction?.offer_price?.amount ? String(Math.round(Number(c.transaction.offer_price.amount))) : '';
    } catch { /* variables vides */ }
    return ctx;
  }

  function insert(ta, text) {
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, ta.value ? ta.value.replace(/\s*$/, '') + '\n' + text : text);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.focus();
  }

  async function mount() {
    if (!location.pathname.startsWith('/inbox/')) return;
    const ta = document.querySelector('#composerInput, textarea[data-testid="composer--input"]');
    if (!ta || document.getElementById('va-quick')) return;
    const { quickReplies } = await chrome.storage.local.get('quickReplies');
    const list = quickReplies?.length ? quickReplies : (typeof DEFAULT_REPLIES !== 'undefined' ? DEFAULT_REPLIES : []);
    if (!list.length) return;
    const bar = document.createElement('div');
    bar.id = 'va-quick';
    Object.assign(bar.style, { display: 'flex', gap: '6px', overflowX: 'auto', padding: '8px 10px', borderTop: '1px solid #e5e7eb', background: '#F2FAFF', scrollbarWidth: 'thin' });
    const label = document.createElement('span');
    label.textContent = '✦';
    label.title = 'Réponses rapides (Nova Resell)';
    Object.assign(label.style, { alignSelf: 'center', fontSize: '15px' });
    bar.append(label);
    for (const r of list) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = r.title;
      b.title = r.text;
      Object.assign(b.style, { flex: 'none', border: '1px solid #22D3EE', color: '#0B1226', background: '#fff', borderRadius: '99px', padding: '4px 10px', font: '600 12.5px system-ui, sans-serif', cursor: 'pointer' });
      b.addEventListener('click', async () => {
        const c = await context();
        const ta2 = document.querySelector('#composerInput, textarea[data-testid="composer--input"]');
        if (!ta2) return;
        insert(ta2, r.text.replaceAll('{pseudo}', c.pseudo).replaceAll('{article}', c.article).replaceAll('{prix}', c.prix));
      });
      bar.append(b);
    }
    // place la barre juste au-dessus de la zone de saisie
    let host = ta;
    for (let i = 0; i < 4 && host.parentElement; i++) { host = host.parentElement; if (host.offsetWidth > 300) break; }
    host.parentElement.insertBefore(bar, host);
  }

  const obs = new MutationObserver(() => { if (!document.getElementById('va-quick')) mount(); });
  obs.observe(document.documentElement, { childList: true, subtree: true });
  chrome.storage.onChanged.addListener((c) => { if (c.quickReplies) { document.getElementById('va-quick')?.remove(); mount(); } });
  mount();
})();
