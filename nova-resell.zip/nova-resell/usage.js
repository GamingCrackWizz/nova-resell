// ===== Suivi de la consommation de l'API Claude (partagé panneau + arrière-plan) =====
// Tarifs en $ par million de tokens (docs Anthropic, oct. 2026)
const PRICES = {
  'claude-haiku-5-5': { in: 0.10, out: 0.50 },
  'claude-sonnet-5-5': { in: 2.00, out: 10.00 },
};
const USAGE_LABELS = { annonce: 'Création d’annonce (photos)', categorie: 'Choix de catégorie', agent: 'Agent IA (réponses)' };

async function recordUsage(action, model, usage) {
  if (!usage) return;
  const p = PRICES[model] || PRICES['claude-haiku-5-5'];
  const inTok = (usage.input_tokens || 0) + (usage.cache_creation_input_tokens || 0) + (usage.cache_read_input_tokens || 0);
  const outTok = usage.output_tokens || 0;
  const cost = (inTok * p.in + outTok * p.out) / 1e6;
  const month = new Date().toISOString().slice(0, 7);
  const { apiUsage = {} } = await chrome.storage.local.get('apiUsage');
  const m = (apiUsage[month] ||= {});
  const a = (m[action] ||= { calls: 0, in: 0, out: 0, cost: 0 });
  a.calls++; a.in += inTok; a.out += outTok; a.cost += cost;
  // on garde 12 mois
  const keys = Object.keys(apiUsage).sort();
  while (keys.length > 12) delete apiUsage[keys.shift()];
  await chrome.storage.local.set({ apiUsage });
}
