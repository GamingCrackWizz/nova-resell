// ===== Nova Resell – journal d'activité (partagé entre le panneau et l'arrière-plan) =====
// Affichage de la version : 1.0.0 → V1.0 · 1.2.3 → V1.2.3
const novaVer = (v = chrome.runtime.getManifest().version) => 'V' + String(v).replace(/\.0$/, '');
const ACT_KINDS = {
  createDraft: ['draft', '📝', 'Brouillon créé sur Vinted'],
  publishDraft: ['publish', '🚀', 'Annonce publiée'],
  repost: ['repost', '🔁', 'Annonce republiée'],
  deleteItem: ['repost', '🗑️', 'Ancienne annonce supprimée'],
  deleteDraft: ['draft', '🗑️', 'Brouillon supprimé'],
  contactFav: ['fav', '❤️', 'Message envoyé à un favori'],
  reply: ['msg', '💬', 'Réponse envoyée à un acheteur'],
  sellerOffer: ['msg', '💶', 'Offre envoyée'],
};
let actQueue = Promise.resolve();
function logActivity(e) {
  // file d'attente : évite que deux écritures simultanées s'écrasent
  actQueue = actQueue.then(async () => {
    const { activityLog = [] } = await chrome.storage.local.get('activityLog');
    activityLog.push({ t: Date.now(), via: 'pc', ...e });
    await chrome.storage.local.set({ activityLog: activityLog.slice(-500) });
  }).catch(() => {});
  return actQueue;
}
function logVintedCall(action, args = {}, error, via) {
  const k = ACT_KINDS[action];
  if (!k) return;
  let title = k[2];
  if (action === 'repost' && args.mode === 'draft') title = 'Annonce copiée en brouillon';
  const detail = [args._t || args.title || '', action === 'repost' && args.price ? `${args.price} €` : '', action === 'contactFav' && args._who ? '@' + args._who : '', action === 'reply' && args._who ? '@' + args._who : ''].filter(Boolean).join(' · ');
  logActivity(error ? { cat: 'error', icon: '⚠️', title: title + ' : échec', detail, err: String(error).slice(0, 200), via } : { cat: k[0], icon: k[1], title, detail, via });
}
