// ===== Nova Resell – recadrage automatique des bordereaux =====
// Vinted fournit une page A4 (consignes + ciseaux + étiquette). On rend la page avec pdf.js,
// on repère le bloc de l'étiquette et on renvoie son cadre en coordonnées PDF.
// Utilisé par le panneau et par le document « offscreen » (pour l'appli téléphone).
(() => {
  if (globalThis.pdfjsLib && !pdfjsLib.GlobalWorkerOptions.workerSrc) pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';

  // suites de valeurs non nulles, fusionnées si l'écart est ≤ tol
  function runs(prof, tol) {
    const out = []; let s = -1, last = -1;
    for (let i = 0; i < prof.length; i++) {
      if (prof[i] > 0) { if (s < 0) s = i; else if (i - last - 1 > tol) { out.push([s, last]); s = i; } last = i; }
    }
    if (s >= 0) out.push([s, last]);
    return out;
  }

  // Trouve le cadre de l'étiquette sur une image (W×H, ink(x,y) = pixel non blanc). Unités : pixels ; pt = taille d'1 point PDF.
  function findLabel(W, H, ink, pt) {
    const rowsIn = (x0, x1) => { const p = new Uint32Array(H); for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) if (ink(x, y)) p[y]++; return p; };
    const colsIn = (y0, y1) => { const p = new Uint32Array(W); for (let y = y0; y <= y1; y++) for (let x = 0; x < W; x++) if (ink(x, y)) p[x]++; return p; };
    // 1) bandes horizontales : la plus haute = l'étiquette (les lignes de texte des consignes font ~10 pt)
    const rr = runs(rowsIn(0, W - 1), Math.round(2 * pt));
    if (!rr.length) return null;
    const tall = (r) => r[1] - r[0];
    let i = rr.reduce((b, r, k) => (tall(r) > tall(rr[b]) ? k : b), 0);
    let [y0, y1] = rr[i];
    // on rattache les blocs voisins assez hauts (étiquette sans cadre, coupée par un blanc)
    for (let k = i - 1; k >= 0 && y0 - rr[k][1] < 14 * pt && tall(rr[k]) > 28 * pt; k--) y0 = rr[k][0];
    for (let k = i + 1; k < rr.length && rr[k][0] - y1 < 14 * pt && tall(rr[k]) > 28 * pt; k++) y1 = rr[k][1];
    if (y1 - y0 < 0.18 * H) return null; // rien qui ressemble à une étiquette : on garde la page entière
    // 2) dans cette bande, le bloc le plus large (au cas où les consignes seraient à côté)
    const cr = runs(colsIn(y0, y1), Math.round(14 * pt));
    const [x0, x1] = cr.reduce((b, r) => (r[1] - r[0] > b[1] - b[0] ? r : b), cr[0]);
    // 3) cadre serré sur ces colonnes
    const r2 = runs(rowsIn(x0, x1).map((v, y) => (y >= y0 && y <= y1 ? v : 0)), Math.round(14 * pt));
    const t = r2.reduce((b, r) => (r[1] - r[0] > b[1] - b[0] ? r : b), r2[0]);
    const box = { x0, x1, y0: t[0], y1: t[1] };
    if ((box.x1 - box.x0) * (box.y1 - box.y0) > 0.85 * W * H) return null; // déjà une étiquette seule
    return box;
  }

  // bytes : ArrayBuffer/Uint8Array d'un PDF → [{x, y, w, h} | null] par page (coordonnées PDF)
  async function labelCropBoxes(bytes) {
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(bytes).slice(), isEvalSupported: false, disableFontFace: false }).promise;
    const out = [];
    for (let n = 1; n <= pdf.numPages; n++) {
      try {
        const page = await pdf.getPage(n);
        const scale = 1.5;
        const vp = page.getViewport({ scale });
        const c = document.createElement('canvas');
        c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
        const ctx = c.getContext('2d', { willReadFrequently: true });
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
        await page.render({ canvasContext: ctx, viewport: vp }).promise;
        const d = ctx.getImageData(0, 0, c.width, c.height).data, W = c.width;
        const ink = (x, y) => { const k = (y * W + x) * 4; return d[k] < 200 || d[k + 1] < 200 || d[k + 2] < 200; };
        const b = findLabel(W, c.height, ink, scale);
        if (!b) { out.push(null); continue; }
        const m = 5 * scale; // petite marge autour de l'étiquette
        const [ax, ay] = vp.convertToPdfPoint(Math.max(0, b.x0 - m), Math.max(0, b.y0 - m));
        const [bx, by] = vp.convertToPdfPoint(Math.min(W, b.x1 + m), Math.min(c.height, b.y1 + m));
        out.push({ x: Math.min(ax, bx), y: Math.min(ay, by), w: Math.abs(bx - ax), h: Math.abs(by - ay) });
      } catch { out.push(null); }
    }
    pdf.destroy();
    return out;
  }
  globalThis.novaLabelCrop = labelCropBoxes;
  globalThis.__novaFindLabel = findLabel;
})();
