// ===== Envois : ventes à expédier + impression des bordereaux avec le SKU + compteurs du haut =====

const ship = { loaded: false, list: [], selected: new Set(), printed: new Set() };
const toShip = (o) => o.userStatus === 'waiting' && !o.isReturn && o.shipmentId && (o.shipmentStatus == null || o.shipmentStatus < 300);
const isActiveReturn = (o) => o.userStatus === 'waiting' && o.isReturn;
const fmtDay = (t, opt = { weekday: 'short', day: 'numeric', month: 'short' }) => new Date(t).toLocaleDateString('fr-FR', opt);
function etaText(eta) {
  if (!eta) return '';
  const same = new Date(eta.from).toDateString() === new Date(eta.to).toDateString();
  const days = Math.round((new Date(eta.to).setHours(12) - new Date().setHours(12)) / 86400000);
  const when = same ? fmtDay(eta.from) : `${fmtDay(eta.from)} → ${fmtDay(eta.to)}`;
  const rel = days < 0 ? ' (date dépassée)' : days === 0 ? " (aujourd'hui)" : days === 1 ? ' (demain)' : ` (dans ${days} j)`;
  return when + rel;
}
const RET_TYPE = { snad: 'Article non conforme', damaged: 'Article endommagé', not_received: 'Colis non reçu', counterfeit: 'Contrefaçon signalée' };
const euro = (n) => (Math.round(n * 100) / 100).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' €';

// ---------- Compteurs du haut ----------
async function refreshStats() {
  try {
    const [dash, sales] = await Promise.all([vinted('dashboard'), ship.loaded ? Promise.resolve(ship.list) : vinted('sales', { pages: 2 })]);
    if (!ship.loaded) { ship.list = sales; ship.loaded = true; }
    const now = new Date();
    const month = sales.filter((o) => o.userStatus !== 'failed' && o.date && sameMonth(o.date, now));
    $('#stShip').textContent = sales.filter(toShip).length;
    $('#stDrafts').textContent = dash.drafts;
    $('#stOnline').textContent = dash.online;
    $('#stMonth').textContent = euro(month.reduce((s, o) => s + (o.price || 0), 0)).replace(',00', '');
    updateShipTab();
  } catch { /* Vinted pas ouvert : on garde les tirets */ }
}
function sameMonth(d, now) {
  const t = new Date(d);
  if (!isNaN(t)) return t.getMonth() === now.getMonth() && t.getFullYear() === now.getFullYear();
  // dates de type "14/10/2026" ou "14 octobre 2026"
  const m = String(d).match(/(\d{1,2})[/.](\d{1,2})[/.](\d{4})/);
  return m ? Number(m[2]) - 1 === now.getMonth() && Number(m[3]) === now.getFullYear() : false;
}
document.querySelectorAll('.stat[data-go]').forEach((b) => b.addEventListener('click', () => {
  showTab(b.dataset.go);
  if (b.dataset.go === 'bordereaux') ship.loaded ? renderShip() : loadShip();
}));

function updateShipTab() {
  const nr = ship.list.filter(isActiveReturn).length;
  const sb = $('#segRetours'); if (sb) sb.replaceChildren('↩️ Retours', nr ? el('span', { className: 'count', textContent: nr }) : '');
  const n = ship.list.filter(toShip).length + nr;
  const tab = document.querySelector('.tab[data-tab=bordereaux]');
  if (tab) tab.replaceChildren(el('i', { className: 'ti', textContent: '📦' }), el('span', { className: 'tl', textContent: 'Ventes' }), n ? el('span', { className: 'count', textContent: n }) : '');
}

// ---------- Liste ----------
async function loadShip() {
  const list = $('#shipList');
  stateMsg(list, 'Chargement de tes ventes…');
  try {
    ship.list = await vinted('sales', { pages: 3 });
    ship.loaded = true;
    const s = await chrome.storage.local.get('printedLabels');
    ship.printed = new Set(s.printedLabels || []);
    renderShip();
    if (!$('#retoursView').hidden) renderReturns();
    refreshStats();
  } catch (e) {
    stateMsg(list, 'Impossible de charger tes ventes', e.message);
  }
}

function shownSales() {
  const f = settings.shipFilter || 'toship';
  if (f === 'toship') return ship.list.filter(toShip);
  if (f === 'progress') return ship.list.filter((o) => o.userStatus === 'waiting');
  return ship.list;
}

function renderShip() {
  const list = $('#shipList');
  const shown = shownSales();
  ship.selected = new Set([...ship.selected].filter((id) => shown.some((o) => o.transactionId === id && o.shipmentId)));
  const n = ship.selected.size;
  $('#shipPrint').disabled = !n;
  $('#shipPrint').textContent = n ? `Imprimer ${n} bordereau${n > 1 ? 'x' : ''}` : 'Coche les ventes à imprimer';
  updateShipTab();
  if (!shown.length) return stateMsg(list, (settings.shipFilter || 'toship') === 'toship' ? 'Rien à expédier 🎉' : 'Aucune vente', 'Les nouvelles ventes apparaîtront ici.');
  list.replaceChildren(...shown.map(shipRow));
}

function shipRow(o) {
  const canPrint = !!o.shipmentId;
  const chk = el('input', { type: 'checkbox', checked: ship.selected.has(o.transactionId), disabled: !canPrint });
  chk.addEventListener('change', () => { chk.checked ? ship.selected.add(o.transactionId) : ship.selected.delete(o.transactionId); renderShip(); });
  const skus = el('div', { className: 'skus' }, o.skus.length ? o.skus.map((s) => el('span', { className: 'sku-chip', textContent: s })) : el('span', { className: 'hint', textContent: 'pas de SKU dans le titre' }));
  const sub = el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }), ' · ' + (o.statusTitle || '').trim());
  if (o.isReturn) sub.append(el('span', { className: 'tag err', textContent: 'retour' }));
  else if (ship.printed.has(o.transactionId)) sub.append(el('span', { className: 'tag ok', textContent: 'imprimé' }));
  else if (toShip(o)) sub.append(el('span', { className: 'tag warn', textContent: 'à expédier' }));
  const eta = !o.isReturn && o.eta && o.userStatus === 'waiting' ? el('div', { className: 'eta', textContent: '🚚 Livraison estimée : ' + etaText(o.eta) }) : null;
  const conv = el('button', { className: 'btn ghost', textContent: 'Conversation' });
  conv.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/inbox/${o.conversationId}` }));
  const one = el('button', { className: 'btn', textContent: 'Imprimer', disabled: !canPrint });
  one.addEventListener('click', () => printLabels([o]));
  return el('div', { className: 'row-item' + (ship.selected.has(o.transactionId) ? ' sel' : '') },
    chk, el('img', { src: o.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }), sub, eta, skus),
    el('div', { className: 'row-actions' }, one, conv));
}

// ---------- Retours ----------
function renderReturns() {
  const list = $('#retList');
  const rets = ship.list.filter(isActiveReturn);
  if (!rets.length) stateMsg(list, 'Aucun retour en cours 🎉', 'Quand un acheteur signale un problème ou demande un retour, la commande apparaît ici.');
  else list.replaceChildren(...rets.map(returnRow));
  const refunds = ship.list.filter((o) => o.userStatus === 'failed' && /rembours/i.test(o.statusTitle || '')).slice(0, 10);
  $('#refundsH').hidden = !refunds.length;
  $('#refundList').replaceChildren(...refunds.map((o) => el('div', { className: 'row-item done' }, el('img', { src: o.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }),
      el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }), ' · ' + (o.statusTitle || '') + (o.date ? ' · ' + fmtDay(o.date, { day: 'numeric', month: 'short' }) : ''))))));
}
function returnRow(o) {
  const r = o.returnInfo || {};
  const sub = el('div', { className: 'sub' }, el('b', { textContent: euro(o.price) }),
    r.refund ? ` · remboursement prévu ${euro(r.refund)}` : '',
    el('span', { className: 'tag err', textContent: RET_TYPE[r.type] || 'Retour' }), r.escalated ? el('span', { className: 'tag warn', textContent: 'escaladé à Vinted' }) : '');
  const step = el('div', { className: 'step', textContent: '➜ ' + (o.lastEvent?.title || o.txStatusTitle || o.statusTitle || 'Retour en cours') + (o.lastEvent?.at ? ' · ' + fmtDay(o.lastEvent.at, { day: 'numeric', month: 'short' }) : '') });
  const eta = el('div', { className: 'eta' + (o.eta ? '' : ' muted'), textContent: o.eta ? '📅 Arrivée estimée du colis retour : ' + etaText(o.eta) : "📅 Date d'arrivée : dès que l'acheteur aura expédié le colis" });
  const msg = r.message ? el('details', { className: 'buyer-msg' }, el('summary', { textContent: "Message de l'acheteur" }), el('p', { textContent: r.message })) : null;
  const skus = o.skus.length ? el('div', { className: 'skus' }, o.skus.map((s) => el('span', { className: 'sku-chip', textContent: s }))) : null;
  const conv = el('button', { className: 'btn primary', textContent: 'Conversation' });
  conv.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/inbox/${o.conversationId}` }));
  return el('div', { className: 'row-item ret' }, el('img', { src: o.photo, alt: '' }),
    el('div', { className: 'meta' }, el('div', { className: 'title', textContent: o.title }), sub, skus, step, eta, msg),
    el('div', { className: 'row-actions' }, conv));
}
$('#retReload').addEventListener('click', async () => { await loadShip(); renderReturns(); });

// ---------- Impression ----------
async function printLabels(orders) {
  const btn = $('#shipPrint');
  const { PDFDocument, StandardFonts, rgb, degrees } = PDFLib;
  btn.disabled = true;
  const out = await PDFDocument.create();
  const font = await out.embedFont(StandardFonts.HelveticaBold);
  let ok = 0;
  for (let k = 0; k < orders.length; k++) {
    const o = orders[k];
    btn.textContent = `Préparation ${k + 1} / ${orders.length}…`;
    try {
      const url = await vinted('labelUrl', { shipmentId: o.shipmentId });
      const res = await fetch(url);
      if (!res.ok) throw new Error('téléchargement impossible (' + res.status + ')');
      const type = res.headers.get('content-type') || '';
      const bytes = await res.arrayBuffer();
      let pages = [];
      if (type.includes('pdf') || new TextDecoder().decode(new Uint8Array(bytes.slice(0, 5))) === '%PDF-') {
        const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
        pages = await out.copyPages(src, src.getPageIndices());
        pages.forEach((p) => out.addPage(p));
      } else {
        const img = type.includes('png') ? await out.embedPng(bytes) : await out.embedJpg(bytes);
        const p = out.addPage([595, 842]);
        const sc = Math.min(555 / img.width, 760 / img.height);
        p.drawImage(img, { x: (595 - img.width * sc) / 2, y: 842 - 60 - img.height * sc, width: img.width * sc, height: img.height * sc });
        pages = [p];
      }
      const label = (o.skus.length ? o.skus.join(' + ') : 'SANS SKU') + '   ·   ' + (o.itemTitles?.length > 1 ? `Lot ${o.itemTitles.length} articles` : o.title.replace(/\s*\(#P\d+\)\s*$/, '')).slice(0, 48);
      for (const p of pages) stampSku(p, label, font, rgb, degrees);
      ship.printed.add(o.transactionId);
      ok++;
    } catch (e) {
      toast(`${o.skus.join(', ') || o.title} : ${e.message}`);
    }
  }
  await chrome.storage.local.set({ printedLabels: [...ship.printed].slice(-500) });
  if (ok) {
    const blob = new Blob([await out.save()], { type: 'application/pdf' });
    chrome.tabs.create({ url: URL.createObjectURL(blob) });
    toast(`${ok} bordereau(x) prêt(s) : imprime avec Ctrl+P`);
  }
  btn.disabled = false;
  renderShip();
}

// Ajoute une bande avec le SKU AU-DESSUS (ou en dessous) du bordereau, sans rien masquer du bordereau
function stampSku(page, text, font, rgb, degrees) {
  const { x: bx, y: by, width, height } = page.getMediaBox();
  const rot = ((page.getRotation().angle % 360) + 360) % 360;
  const side = rot === 90 || rot === 270;
  const span = side ? height : width;               // largeur visible de la bande
  let size = Math.max(12, Math.min(26, span / 20));
  while (font.widthOfTextAtSize(text, size) > span - 30 && size > 8) size -= 1;
  const w = font.widthOfTextAtSize(text, size);
  const band = size + 22;
  const top = (settings.skuPos || 'top') === 'top';
  const setBox = (x, y, w2, h2) => { page.setMediaBox(x, y, w2, h2); page.setCropBox(x, y, w2, h2); };
  if (!side) {
    const y0 = top ? by + height : by - band;
    setBox(bx, top ? by : by - band, width, height + band);
    page.drawRectangle({ x: bx + (width - w) / 2 - 12, y: y0 + 5, width: w + 24, height: band - 10, color: rgb(1, 1, 1), borderColor: rgb(0, 0, 0), borderWidth: 2 });
    page.drawText(text, { x: bx + (width - w) / 2, y: y0 + 5 + (band - 10 - size) / 2 + size * 0.22, size, font, color: rgb(0, 0, 0) });
  } else {
    // page affichée tournée de 90° : la bande « haut » visible correspond au côté droit (90) ou gauche (270)
    const right = (rot === 90) === top;
    const x0 = right ? bx + width : bx - band;
    setBox(right ? bx : bx - band, by, width + band, height);
    const ang = rot === 90 ? 90 : 270;
    page.drawRectangle({ x: x0 + 5, y: by + (height - w) / 2 - 12, width: band - 10, height: w + 24, color: rgb(1, 1, 1), borderColor: rgb(0, 0, 0), borderWidth: 2 });
    const tx = ang === 90 ? x0 + 5 + (band - 10) / 2 + size * 0.35 : x0 + 5 + (band - 10) / 2 - size * 0.35;
    const ty = ang === 90 ? by + (height - w) / 2 : by + (height + w) / 2;
    page.drawText(text, { x: tx, y: ty, size, font, color: rgb(0, 0, 0), rotate: degrees(ang) });
  }
}

// ---------- Boutons ----------
$('#shipReload').addEventListener('click', loadShip);
$('#shipSelectAll').addEventListener('click', () => {
  const free = shownSales().filter((o) => o.shipmentId);
  const all = free.length && free.every((o) => ship.selected.has(o.transactionId));
  free.forEach((o) => (all ? ship.selected.delete(o.transactionId) : ship.selected.add(o.transactionId)));
  $('#shipSelectAll').textContent = all ? 'Tout cocher' : 'Tout décocher';
  renderShip();
});
$('#shipPrint').addEventListener('click', () => printLabels(ship.list.filter((o) => ship.selected.has(o.transactionId))));
['#skuPos', '#shipFilter'].forEach((s) => $(s).addEventListener('change', () => {
  settings.skuPos = $('#skuPos').value; settings.shipFilter = $('#shipFilter').value; saveSettings(); renderShip();
}));
document.querySelector('.tab[data-tab=bordereaux]').addEventListener('click', () => { if (!ship.loaded) loadShip(); else renderShip(); });

$('#shipAlerts').addEventListener('change', () => { settings.shipAlerts = $('#shipAlerts').checked; saveSettings(); });
(async () => {
  const s = await chrome.storage.local.get('settings');
  $('#shipAlerts').checked = s.settings?.shipAlerts !== false;
  $('#skuPos').value = s.settings?.skuPos || 'top';
  $('#shipFilter').value = s.settings?.shipFilter || 'toship';
  const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' });
  if (tab) refreshStats();
  setInterval(async () => { const [t] = await chrome.tabs.query({ url: 'https://www.vinted.fr/*' }); if (t) refreshStats(); }, 5 * 60000);
})();

// Ouvert depuis l'appli mobile (#print) : imprime tous les bordereaux à expédier
if (location.hash === '#print') {
  (async () => {
    showTab('bordereaux'); await loadShip();
    const todo = ship.list.filter(toShip);
    if (todo.length) await printLabels(todo); else toast('Rien à expédier');
  })();
}
