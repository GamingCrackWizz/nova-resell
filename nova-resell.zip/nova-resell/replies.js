// ===== Onglet Réponses : gestion des réponses rapides =====
let replies = [];
const saveReplies = () => chrome.storage.local.set({ quickReplies: replies });

function renderReplies() {
  const list = $('#replyList');
  if (!replies.length) return stateMsg(list, 'Aucune réponse', 'Ajoute ta première réponse rapide.');
  list.replaceChildren(...replies.map((r, i) => {
    const title = el('input', { type: 'text', value: r.title, placeholder: 'Nom du bouton (ex. Mesures)' });
    const text = el('textarea', { rows: 3, value: r.text, placeholder: 'Texte de la réponse' });
    title.addEventListener('change', () => { r.title = title.value.trim() || 'Réponse'; saveReplies(); });
    text.addEventListener('change', () => { r.text = text.value; saveReplies(); });
    const up = el('button', { className: 'btn ghost', textContent: '↑', title: 'Monter', disabled: i === 0 });
    const down = el('button', { className: 'btn ghost', textContent: '↓', title: 'Descendre', disabled: i === replies.length - 1 });
    const del = el('button', { className: 'btn ghost danger', textContent: 'Supprimer' });
    const cp = el('button', { className: 'btn ghost', textContent: 'Copier' });
    const move = (d) => { const [x] = replies.splice(i, 1); replies.splice(i + d, 0, x); saveReplies(); renderReplies(); };
    up.addEventListener('click', () => move(-1));
    down.addEventListener('click', () => move(1));
    del.addEventListener('click', () => { if (confirm(`Supprimer « ${r.title} » ?`)) { replies.splice(i, 1); saveReplies(); renderReplies(); } });
    cp.addEventListener('click', () => copy(r.text, 'Réponse copiée'));
    return el('div', { className: 'reply-card' }, el('div', { className: 'reply-head' }, el('span', { className: 'chip-prev', textContent: '⚡ ' + r.title }), up, down), title, text, el('div', { className: 'actions' }, cp, el('span', { className: 'spacer' }), del));
  }));
}

$('#replyAdd').addEventListener('click', () => {
  replies.push({ title: 'Nouvelle réponse', text: '' });
  saveReplies(); renderReplies();
  const last = [...document.querySelectorAll('#replyList textarea')].pop();
  last?.focus();
});
$('#replyReset').addEventListener('click', () => {
  if (!confirm('Remplacer tes réponses par les réponses par défaut ?')) return;
  replies = DEFAULT_REPLIES.map((r) => ({ ...r }));
  saveReplies(); renderReplies();
});

(async () => {
  const s = await chrome.storage.local.get('quickReplies');
  replies = s.quickReplies?.length ? s.quickReplies : DEFAULT_REPLIES.map((r) => ({ ...r }));
  if (!s.quickReplies) saveReplies();
  renderReplies();
})();


// ---------- Agent IA ----------
async function renderAi() {
  const { aiQueue = [], aiLog = [] } = await chrome.storage.local.get(['aiQueue', 'aiLog']);
  $('#aiStatus').replaceChildren(settings.aiAuto
    ? el('span', { className: 'live' }, el('i'), (settings.aiMode || 'validate') === 'auto' ? ' Actif · répond automatiquement' : ` Actif · ${aiQueue.length} réponse(s) à valider`)
    : el('span', { textContent: settings.apiKey ? 'Désactivé' : 'Ajoute ta clé API dans ⚙︎ pour utiliser l’agent' }));
  $('#aiQueueList').replaceChildren(...aiQueue.map((q, i) => {
    const ta = el('textarea', { rows: 3, value: q.message });
    const send = el('button', { className: 'btn primary', textContent: q.offerPrice ? `Envoyer + offre ${q.offerPrice} €` : 'Envoyer' });
    const skip = el('button', { className: 'btn ghost', textContent: 'Ignorer' });
    const open = el('button', { className: 'btn ghost', textContent: 'Conversation' });
    const drop = async () => { const s = await chrome.storage.local.get('aiQueue'); const qq = (s.aiQueue || []).filter((x) => !(x.conversationId === q.conversationId && x.lastId === q.lastId)); await chrome.storage.local.set({ aiQueue: qq }); };
    send.addEventListener('click', async () => {
      send.disabled = true;
      try {
        if (q.offerPrice && q.transactionId) await vinted('sellerOffer', { transactionId: q.transactionId, price: q.offerPrice, _t: q.article, _who: q.pseudo });
        await vinted('reply', { conversationId: q.conversationId, body: ta.value, _t: q.article, _who: q.pseudo }); await drop(); toast(`Réponse envoyée à @${q.pseudo}`);
      }
      catch (e) { toast('Erreur : ' + e.message); send.disabled = false; }
    });
    skip.addEventListener('click', drop);
    open.addEventListener('click', () => chrome.tabs.create({ url: `https://www.vinted.fr/inbox/${q.conversationId}` }));
    return el('div', { className: 'reply-card ai' },
      el('div', { className: 'reply-head' }, el('span', { className: 'chip-prev', textContent: `@${q.pseudo}` }), el('small', { className: 'hint', textContent: q.article.slice(0, 30) })),
      el('div', { className: 'q', textContent: '« ' + q.question + ' »' }), ta,
      el('div', { className: 'actions' }, send, open, el('span', { className: 'spacer' }), skip));
  }));
  $('#aiLogList').replaceChildren(...aiLog.slice(-4).reverse().map((l) => el('div', { className: l.ok ? 'ok' : 'ko' },
    `${new Date(l.time).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} · `,
    l.error ? `Erreur : ${l.error}` : l.skipped ? `@${l.pseudo} : laissé pour toi (${l.reason})` : `@${l.pseudo} : « ${(l.message || '').slice(0, 60)}… »`)));
}
$('#aiAuto').addEventListener('change', async () => {
  if ($('#aiAuto').checked && !settings.apiKey) { $('#aiAuto').checked = false; return toast("Ajoute d'abord ta clé API dans ⚙︎"); }
  if ($('#aiAuto').checked && $('#aiMode').value === 'auto' && !confirm("Activer l'agent en mode 100 % automatique ?\nIl enverra ses réponses sans validation.")) { $('#aiAuto').checked = false; return; }
  settings.aiAuto = $('#aiAuto').checked; await saveSettings();
  if (settings.aiAuto) chrome.runtime.sendMessage({ va: 'aiReplyNow' }).catch(() => {});
  renderAi(); toast(settings.aiAuto ? 'Agent IA activé' : 'Agent IA désactivé');
});
$('#aiMode').addEventListener('change', async () => {
  if ($('#aiMode').value === 'auto' && settings.aiAuto && !confirm('Passer en mode 100 % automatique ?')) { $('#aiMode').value = 'validate'; return; }
  settings.aiMode = $('#aiMode').value; await saveSettings(); renderAi();
});
$('#aiMinPct').addEventListener('change', () => { settings.aiMinPct = Math.min(100, Math.max(50, Number($('#aiMinPct').value) || 85)); saveSettings(); });
$('#aiNegotiate').addEventListener('change', () => { settings.aiNegotiate = $('#aiNegotiate').checked; saveSettings(); });
$('#aiRules').addEventListener('change', () => { settings.aiRules = $('#aiRules').value.trim(); saveSettings(); });
chrome.storage.onChanged.addListener((c) => { if (c.aiQueue || c.aiLog) renderAi(); });
(async () => {
  const s = await chrome.storage.local.get('settings');
  const st = s.settings || {};
  $('#aiAuto').checked = !!st.aiAuto; $('#aiMode').value = st.aiMode || 'validate';
  $('#aiMinPct').value = st.aiMinPct ?? 85; $('#aiNegotiate').checked = st.aiNegotiate !== false;
  if (st.aiNegotiate === undefined) { settings.aiNegotiate = true; } $('#aiRules').value = st.aiRules || '';
  setTimeout(renderAi, 300);
})();
