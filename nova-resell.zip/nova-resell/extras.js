// ===== Statistiques de vente, consommation API, sauvegarde =====
const EUR_RATE = 1.1181; // 1 € = 1,1181 $ (Banque de France, 12/10/2026)
const eur = (usd) => usd / EUR_RATE;
const fmtEur = (v, d = 2) => v.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d }) + ' €';

// ---------- Consommation API ----------
async function renderUsage() {
  $('#usageRate').textContent = EUR_RATE.toLocaleString('fr-FR');
  const { apiUsage = {} } = await chrome.storage.local.get('apiUsage');
  const month = new Date().toISOString().slice(0, 7);
  const m = apiUsage[month] || {};
  const total = Object.values(m).reduce((s, a) => s + a.cost, 0);
  const rows = Object.entries(m).map(([k, a]) => el('tr', {},
    el('td', { textContent: USAGE_LABELS[k] || k }), el('td', { textContent: a.calls }),
    el('td', { textContent: fmtEur(eur(a.cost / a.calls), 4) }), el('td', { textContent: fmtEur(eur(a.cost), 3) })));
  const prev = Object.keys(apiUsage).filter((k) => k !== month).sort().slice(-3).map((k) => `${k} : ${fmtEur(eur(Object.values(apiUsage[k]).reduce((s, a) => s + a.cost, 0)))}`);
  $('#usageBox').replaceChildren(...[
    el('div', { className: 'usage-total' }, el('b', { textContent: fmtEur(eur(total)) }), ' ce mois-ci'),
    rows.length ? el('table', { className: 'usage' }, el('tr', {}, el('th', { textContent: 'Action' }), el('th', { textContent: 'Nb' }), el('th', { textContent: 'Coût moyen' }), el('th', { textContent: 'Total' })), rows)
      : el('p', { className: 'hint', textContent: 'Aucune utilisation ce mois-ci.' }),
    prev.length ? el('p', { className: 'hint', textContent: 'Mois précédents : ' + prev.join(' · ') }) : null].filter(Boolean));
}
chrome.storage.onChanged.addListener((c) => { if (c.apiUsage) renderUsage(); });
renderUsage();

// ---------- Sauvegarde / restauration ----------
const BACKUP_KEYS = ['settings', 'quickReplies', 'favContacted', 'printedLabels'];
$('#bkExport').addEventListener('click', async () => {
  const data = await chrome.storage.local.get(BACKUP_KEYS);
  data.settings = { ...data.settings };
  if (!$('#bkKey').checked) delete data.settings.apiKey;
  delete data.settings.vintedMaxSku;
  const blob = new Blob([JSON.stringify({ app: 'Nova Resell', version: chrome.runtime.getManifest().version, date: new Date().toISOString(), data }, null, 2)], { type: 'application/json' });
  const a = el('a', { href: URL.createObjectURL(blob), download: `nova-resell-sauvegarde-${new Date().toISOString().slice(0, 10)}.json` });
  a.click();
  toast('Sauvegarde téléchargée');
});
$('#bkImport').addEventListener('click', () => $('#bkFile').click());
$('#bkFile').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try {
    const j = JSON.parse(await f.text());
    if (j.app !== 'Nova Resell' || !j.data) throw new Error("ce fichier n'est pas une sauvegarde Nova Resell");
    if (!confirm(`Restaurer la sauvegarde du ${new Date(j.date).toLocaleDateString('fr-FR')} ?\nTes réglages actuels seront remplacés (ta clé API est conservée si la sauvegarde n'en contient pas).`)) return;
    const cur = await chrome.storage.local.get('settings');
    const merged = { ...(cur.settings || {}), ...(j.data.settings || {}) };
    if (!j.data.settings?.apiKey && cur.settings?.apiKey) merged.apiKey = cur.settings.apiKey;
    await chrome.storage.local.set({ ...j.data, settings: merged });
    toast('Sauvegarde restaurée, rechargement…');
    setTimeout(() => location.reload(), 900);
  } catch (err) { toast('Erreur : ' + err.message); }
});

// ---------- Statistiques de vente ----------
const BRANDS = ['Tommy Hilfiger', 'Tommy Jeans', 'Ralph Lauren', 'Polo Ralph Lauren', 'Lacoste', 'Nike', 'Adidas', 'The North Face', 'Carhartt', 'Levi’s', "Levi's", 'Levis', 'Reebok', 'Puma', 'Champion', 'Fila', 'Kappa', 'Starter', 'Columbia', 'Patagonia', 'Timberland', 'Stone Island', 'Napapijri', 'Fred Perry', 'Burberry', 'Calvin Klein', 'Guess', 'Diesel', 'Zara', 'H&M', 'Uniqlo', 'Jordan', 'New Balance', 'Converse', 'Vans', 'Dickies', 'Stüssy', 'Stussy', 'Supreme', 'Ellesse', 'Sergio Tacchini', 'Hugo Boss', 'Boss', 'Gant', 'Schott', 'Wrangler', 'Lee', 'Kenzo', 'Moncler', 'Umbro', 'Le Coq Sportif', 'Asics', 'Under Armour', 'Quiksilver', 'Billabong', 'Element', 'Dr. Martens', 'Barbour', 'Benetton', 'Pepe Jeans', 'Jack & Jones', 'Celio', 'Kiabi'];
function brandOf(title, hint) {
  if (hint) return hint;
  const t = String(title || '').toLowerCase();
  const b = BRANDS.find((x) => t.includes(x.toLowerCase()));
  if (!b) return 'Autre';
  return { "Levi’s": "Levi's", Levis: "Levi's", 'Polo Ralph Lauren': 'Ralph Lauren', Stussy: 'Stüssy', Boss: 'Hugo Boss' }[b] || b;
}
function parseDate(d) {
  const t = new Date(d);
  if (!isNaN(t)) return t;
  const m = String(d).match(/(\d{1,2})[/.](\d{1,2})[/.](\d{4})/);
  return m ? new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1])) : null;
}
const norm2 = (t) => String(t || '').toLowerCase().replace(/\s+/g, ' ').trim();
const DAYS = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];

let statsCache = null;
async function loadStats() {
  const box = $('#statsView');
  stateMsg(box, 'Calcul des statistiques…');
  try {
    statsCache = await vinted('statsData');
    statsCache.xi = (await chrome.storage.local.get('excelIndex')).excelIndex || null;
    renderStats();
  } catch (e) { stateMsg(box, 'Impossible de charger les statistiques', e.message); }
}

function bars(rows, fmt) {
  const max = Math.max(1, ...rows.map((r) => r[1]));
  return el('div', { className: 'bars' }, rows.map(([label, v, sub]) => el('div', { className: 'bar-row' },
    el('span', { className: 'bl', textContent: label }),
    el('span', { className: 'bt' }, el('i', { style: `width:${Math.max(3, (v / max) * 100)}%` })),
    el('span', { className: 'bv', textContent: fmt(v) + (sub ? ' · ' + sub : '') }))));
}

function renderStats() {
  const { sales, items } = statsCache;
  const ok = sales.filter((s) => s.status !== 'failed');
  const now = new Date();
  // CA par mois (6 derniers)
  const months = [];
  for (let k = 5; k >= 0; k--) { const d = new Date(now.getFullYear(), now.getMonth() - k, 1); months.push([d.toLocaleDateString('fr-FR', { month: 'short' }), 0, d]); }
  ok.forEach((s) => { const d = parseDate(s.date); if (!d) return; const m = months.find((x) => x[2].getMonth() === d.getMonth() && x[2].getFullYear() === d.getFullYear()); if (m) m[1] += s.price; });
  const thisMonth = months[5][1];
  const total = ok.reduce((a, s) => a + s.price, 0);
  // marques (sur les ventes)
  const byBrand = {};
  ok.forEach((s) => { const b = brandOf(s.title); (byBrand[b] ||= { n: 0, ca: 0 }); byBrand[b].n++; byBrand[b].ca += s.price; });
  const topBrands = Object.entries(byBrand).filter(([b]) => b !== 'Autre').sort((a, b) => b[1].ca - a[1].ca).slice(0, 6).map(([b, v]) => [b, v.ca, `${v.n} vente${v.n > 1 ? 's' : ''}`]);
  // délai de vente : article vendu (date de mise en ligne) ↔ date de la vente
  const listed = new Map(items.filter((i) => i.listed).map((i) => [norm2(i.title), i]));
  const delays = [];
  const byDay = DAYS.map(() => ({ n: 0, d: 0 }));
  ok.forEach((s) => {
    const it = listed.get(norm2(s.title)); const d = parseDate(s.date);
    if (!it || !d) return;
    const days = (d - it.listed) / 86400000;
    if (days < 0 || days > 365) return;
    delays.push(days);
    const wd = new Date(it.listed).getDay(); byDay[wd].n++; byDay[wd].d += days;
  });
  const avgDelay = delays.length ? delays.reduce((a, b) => a + b, 0) / delays.length : null;
  const dayRows = byDay.map((v, i) => [DAYS[i], v.n, v.n ? `${(v.d / v.n).toFixed(0)} j en moy.` : '']).filter((r) => r[1] > 0);
  const bestDay = dayRows.slice().sort((a, b) => b[1] - a[1])[0];
  // stock
  const online = items.filter((i) => !i.draft && !i.sold);
  const stockValue = online.reduce((a, i) => a + i.price, 0);
  const sleeping = online.filter((i) => i.listed && (now - i.listed) / 86400000 > 30 && i.favs === 0).length;

  const kpi = (v, l) => el('div', { className: 'kpi' }, el('b', { textContent: v }), el('span', { textContent: l }));
  // ---- Rentabilité (prix d'achat de ton fichier Excel) ----
  const xi = statsCache.xi;
  const sum = profitSummary(ok, xi, now);
  const per = ok.map((s) => { const c = costOf(s.title, xi); const it = listed.get(norm2(s.title)); const d = parseDate(s.date); const days = it && d ? (d - it.listed) / 86400000 : null;
    return { ...s, cost: c?.buy ?? null, cat: c?.cat || '', profit: c ? s.price - c.buy : null, brand: brandOf(s.title), days: days != null && days >= 0 && days < 365 ? days : null }; });
  const known = per.filter((x) => x.profit != null);
  const profitTotal = known.reduce((a, x) => a + x.profit, 0), costTotal = known.reduce((a, x) => a + x.cost, 0), caKnown = known.reduce((a, x) => a + x.price, 0);
  const group = (key) => { const g = {}; known.forEach((x) => { const k = x[key] || 'Non renseigné'; (g[k] ||= { n: 0, p: 0, ca: 0, d: 0, dn: 0 }); g[k].n++; g[k].p += x.profit; g[k].ca += x.price; if (x.days != null) { g[k].d += x.days; g[k].dn++; } }); return Object.entries(g); };
  const byCat = group('cat').sort((a, b) => b[1].p - a[1].p).map(([k, v]) => [k, v.p, `${v.n} vente${v.n > 1 ? 's' : ''} · ${fmtEur(v.p / v.n, 0)}/vente${v.dn ? ` · ${(v.d / v.dn).toFixed(0)} j` : ''}`]);
  const brandG = group('brand').filter(([k]) => k !== 'Autre');
  const byBrandP = brandG.sort((a, b) => b[1].p - a[1].p).slice(0, 6).map(([k, v]) => [k, v.p, `${v.n} · ${fmtEur(v.p / v.n, 0)}/vente${v.dn ? ` · ${(v.d / v.dn).toFixed(0)} j` : ''}`]);
  const rebuy = brandG.filter(([, v]) => v.n >= 2).map(([k, v]) => [k, (v.p / v.n) / Math.max(3, v.dn ? v.d / v.dn : 30)]).sort((a, b) => b[1] - a[1])[0];
  const profitSheet = !known.length
    ? el('div', { className: 'sheet compact' }, el('h2', { textContent: '💰 Rentabilité' }), el('p', { className: 'hint', textContent: 'Relie ton fichier Excel (onglet Excel, juste à côté) avec tes prix d’achat : Nova calculera ton bénéfice par mois, par marque et par provenance.' }))
    : [
      el('div', { className: 'kpis' },
        kpi(fmtEur(sum.month.profit, 0), 'bénéfice ce mois'), kpi(caKnown ? Math.round((profitTotal / caKnown) * 100) + ' %' : '–', 'marge moyenne'),
        kpi(costTotal ? '×' + (caKnown / costTotal).toLocaleString('fr-FR', { maximumFractionDigits: 1 }) : '–', 'prix d’achat multiplié'), kpi(fmtEur(profitTotal, 0), 'bénéfice total')),
      el('div', { className: 'sheet compact' }, el('h2', { textContent: '💰 Bénéfice (6 mois)' }), bars(sum.months.map((m) => [m.label, Math.max(0, m.profit), m.known < m.n ? `${m.known}/${m.n} ventes` : '']), (v) => fmtEur(v, 0))),
      rebuy ? el('div', { className: 'sheet compact tip-box' }, el('b', { textContent: `🔁 À racheter en priorité : ${rebuy[0]}` }), el('p', { className: 'hint', textContent: 'La marque qui te rapporte le plus par vente, et le plus vite.' })) : null,
      el('div', { className: 'sheet compact' }, el('h2', { textContent: 'Bénéfice par provenance' }), byCat.length ? bars(byCat, (v) => fmtEur(v, 0)) : el('p', { className: 'hint', textContent: 'Ajoute une colonne « Catégorie d’achat » (ballot, brocante…) dans ton Excel.' })),
      el('div', { className: 'sheet compact' }, el('h2', { textContent: 'Bénéfice par marque' }), byBrandP.length ? bars(byBrandP, (v) => fmtEur(v, 0)) : el('p', { className: 'hint', textContent: 'Pas encore assez de ventes avec une marque reconnue.' })),
      el('p', { className: 'hint center', textContent: `Prix d’achat retrouvé pour ${known.length} vente(s) sur ${ok.length} (par SKU ou par le nom de l’article dans ton Excel).` }),
    ];
  $('#statsView').replaceChildren(
    ...[profitSheet].flat().filter(Boolean),
    el('div', { className: 'kpis' },
      kpi(fmtEur(thisMonth, 0), 'CA ce mois'), kpi(String(ok.length), 'ventes au total'),
      kpi(ok.length ? fmtEur(total / ok.length, 0) : '–', 'panier moyen'), kpi(avgDelay != null ? `${avgDelay.toFixed(0)} j` : '–', 'délai de vente moyen')),
    el('div', { className: 'sheet compact' }, el('h2', { textContent: "Chiffre d'affaires (6 mois)" }), bars(months.map(([l, v]) => [l, v]), (v) => fmtEur(v, 0))),
    el('div', { className: 'sheet compact' }, el('h2', { textContent: 'Marques qui se vendent le mieux' }),
      topBrands.length ? bars(topBrands, (v) => fmtEur(v, 0)) : el('p', { className: 'hint', textContent: 'Pas encore assez de ventes avec une marque reconnue.' })),
    el('div', { className: 'sheet compact' }, el('h2', { textContent: 'Meilleur jour pour publier' }),
      dayRows.length ? [el('p', { className: 'hint', textContent: `Les articles publiés le ${bestDay[0].toLowerCase()} se vendent le plus.` }), bars(dayRows, (v) => `${v} vente${v > 1 ? 's' : ''}`)]
        : el('p', { className: 'hint', textContent: 'Pas encore assez de données (il faut des articles vendus encore visibles dans ton dressing).' })),
    el('div', { className: 'sheet compact' }, el('h2', { textContent: 'Ton stock en ligne' }),
      el('p', { className: 'hint' }, `${online.length} annonces · valeur ${fmtEur(stockValue, 0)}`, el('br'), `${sleeping} annonce(s) en ligne depuis plus de 30 jours sans aucun favori : à republier ou à baisser.`)),
    el('p', { className: 'hint center', textContent: `Basé sur tes ${sales.length} dernières ventes Vinted. Marques détectées depuis les titres.` }));
}

document.querySelectorAll('.seg-b').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.seg-b').forEach((x) => x.classList.toggle('active', x === b));
  const v = b.dataset.view;
  $('#statsView').hidden = v !== 'stats'; $('#envoisView').hidden = v !== 'envois'; $('#retoursView').hidden = v !== 'retours'; $('#excelView').hidden = v !== 'excel';
  if (v === 'stats' && !statsCache) loadStats();
  if (v === 'retours') { if (ship.loaded) renderReturns(); else loadShip(); }
}));

// ---------- Synchronisation ----------
$('#syncEnabled').addEventListener('change', () => { settings.syncEnabled = $('#syncEnabled').checked; saveSettings(); toast(settings.syncEnabled ? 'Synchronisation activée' : 'Synchronisation désactivée'); });
chrome.storage.local.get('settings').then((s) => { $('#syncEnabled').checked = s.settings?.syncEnabled !== false; });
// quand la synchro (ou l'arrière-plan) modifie les réglages, on met à jour le panneau ouvert
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !c.settings?.newValue) return;
  const nv = c.settings.newValue;
  if (JSON.stringify(nv) === JSON.stringify(settings)) return;
  Object.assign(settings, nv);
  try { fillSettings(); } catch { /* ignore */ }
});

// ---------- Bouton « Réactualiser » ----------
$('#reloadExt').addEventListener('click', async () => {
  $('#reloadExt').classList.add('spin');
  toast('Réactualisation de Nova Resell…');
  await chrome.storage.local.set({ reloadTabsAfter: Date.now() });
  setTimeout(() => chrome.runtime.reload(), 400);
});
$('#hdrVersion').textContent = novaVer();

// ---------- Compte Nova (connexion, création, mot de passe oublié) ----------
let accMode = 'in';
function setAccMode(m) {
  accMode = m;
  document.querySelectorAll('#cloudOff .seg-btn[data-acc]').forEach((b) => b.classList.toggle('active', b.dataset.acc === m));
  $('#cloudPass2Wrap').hidden = m !== 'up'; $('#cloudUp').hidden = m !== 'up'; $('#cloudIn').hidden = m !== 'in'; $('#cloudForgot').hidden = m !== 'in';
  $('#cloudPass').autocomplete = m === 'up' ? 'new-password' : 'current-password';
  $('#cloudErr').textContent = '';
}
document.querySelectorAll('#cloudOff .seg-btn[data-acc]').forEach((b) => b.addEventListener('click', () => setAccMode(b.dataset.acc)));
async function renderCloud() {
  const c = await NovaCloud.cfg();
  const on = !!c.session?.refresh_token;
  $('#cloudOn').hidden = !on; $('#cloudOff').hidden = on;
  $('#appUrlTxt').textContent = NOVA_APP_URL.replace(/^https:\/\//, '');
  if (on) { $('#bkCloudInfo').textContent = c.lastBackup ? 'Dernière sauvegarde : ' + new Date(c.lastBackup).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Pas encore de sauvegarde sur ce PC'; }
  if (on) { $('#cloudEmail').textContent = c.session.user?.email || ''; $('#cloudSync').textContent = c.lastSync ? 'Synchronisé à ' + new Date(c.lastSync).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'En attente de synchronisation…'; }
  else { $('#cloudUrl').value = c.url || ''; $('#cloudKey').value = c.key || ''; $('#cloudAdv').open = !c.url || !c.key; }
  $('#cloudErr').textContent = c.lastError || '';
}
async function cloudCreds() {
  const url = $('#cloudUrl').value.trim(), key = $('#cloudKey').value.trim();
  if (url || key) await NovaCloud.save({ url, key });
  return { email: $('#cloudMail').value.trim(), pass: $('#cloudPass').value };
}
$('#cloudIn').addEventListener('click', async () => {
  try {
    const { email, pass } = await cloudCreds(); await NovaCloud.signIn(email, pass); $('#cloudPass').value = ''; toast('Connecté au compte Nova ✓'); chrome.runtime.sendMessage({ va: 'cloudNow' }).catch(() => {});
    const b = await NovaCloud.downloadBackup().catch(() => null);
    if (b && confirm(`Une sauvegarde de tes réglages existe dans ton compte (${new Date(b.date).toLocaleDateString('fr-FR')}).\nLa restaurer sur ce PC ?`)) { await applyBackup(b); toast('Réglages restaurés, rechargement…'); setTimeout(() => location.reload(), 900); }
  }
  catch (e) { $('#cloudErr').textContent = e.message; return; }
  renderCloud();
});
$('#cloudUp').addEventListener('click', async () => {
  try {
    const { email, pass } = await cloudCreds();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('Adresse e-mail invalide');
    if (pass.length < 6) throw new Error('Mot de passe : 6 caractères minimum');
    if (pass !== $('#cloudPass2').value) throw new Error('Les deux mots de passe ne sont pas identiques');
    const r = await NovaCloud.signUp(email, pass);
    $('#cloudPass').value = ''; $('#cloudPass2').value = '';
    toast(r.confirm ? 'Compte créé : confirme ton e-mail puis connecte-toi' : 'Compte créé et connecté ✓');
    if (!r.confirm) chrome.runtime.sendMessage({ va: 'cloudNow' }).catch(() => {}); else setAccMode('in');
  } catch (e) { $('#cloudErr').textContent = e.message; return; }
  renderCloud();
});
async function forgotPassword(email, errEl) {
  if (!/^\S+@\S+\.\S+$/.test(email)) { errEl.textContent = "Écris d'abord ton adresse e-mail dans la case E-mail"; return; }
  try { await NovaCloud.recover(email); errEl.textContent = `📧 E-mail envoyé à ${email} : clique sur le lien (vérifie aussi les spams) pour choisir un nouveau mot de passe, puis reconnecte-toi ici.`; }
  catch (e) { errEl.textContent = e.message; }
}
$('#cloudForgot').addEventListener('click', (e) => { e.preventDefault(); forgotPassword($('#cloudMail').value.trim(), $('#cloudErr')); });
$('#copyAppUrl').addEventListener('click', (e) => { e.preventDefault(); navigator.clipboard.writeText(NOVA_APP_URL).then(() => toast('Lien copié : envoie-le sur ton téléphone')); });
$('#bkCloudSave').addEventListener('click', async () => {
  try { await NovaCloud.uploadBackup(await collectBackup()); toast('Réglages sauvegardés dans ton compte ✓'); renderCloud(); }
  catch (e) { toast('Sauvegarde impossible : ' + e.message); }
});
$('#bkCloudRestore').addEventListener('click', async () => {
  try {
    const b = await NovaCloud.downloadBackup();
    if (!b) return toast('Aucune sauvegarde dans ton compte pour le moment');
    if (!confirm(`Restaurer les réglages sauvegardés le ${new Date(b.date).toLocaleString('fr-FR', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })} ?\nTes réglages actuels seront remplacés (ta clé API et les modes 24h/24 de ce PC sont conservés).`)) return;
    await applyBackup(b); toast('Réglages restaurés, rechargement…'); setTimeout(() => location.reload(), 900);
  } catch (e) { toast('Restauration impossible : ' + e.message); }
});
$('#cloudOut').addEventListener('click', async () => { await NovaCloud.signOut(); renderCloud(); toast('Déconnecté du compte Nova'); });
$('#cloudSyncNow').addEventListener('click', () => { chrome.runtime.sendMessage({ va: 'cloudNow' }).catch(() => {}); toast('Synchronisation lancée'); setTimeout(renderCloud, 4000); });
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.novaCloud) renderCloud(); });
setAccMode('in');
renderCloud();

// ---------- Clé API : test et lien de création ----------
async function testApiKey(key) {
  if (!/^sk-ant-/.test(key)) throw new Error('La clé doit commencer par « sk-ant- »');
  const r = await fetch('https://api.anthropic.com/v1/models?limit=1', { headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' } });
  if (r.status === 401) throw new Error('Clé refusée : vérifie que tu l’as copiée en entier');
  if (r.status === 403) throw new Error('Clé valide mais sans accès : ajoute du crédit sur console.anthropic.com → Billing');
  if (!r.ok) throw new Error('Test impossible (erreur ' + r.status + ')');
  return true;
}
$('#apiTest').addEventListener('click', async () => {
  const out = $('#apiTestRes'); out.textContent = 'Test en cours…';
  try { await testApiKey($('#apiKey').value.trim()); out.textContent = '✅ Clé valide. Pense à cliquer sur « Enregistrer ».'; }
  catch (e) { out.textContent = '⚠︎ ' + e.message; }
});
$('#apiConsole').addEventListener('click', () => chrome.tabs.create({ url: 'https://console.anthropic.com/settings/keys' }));

// ---------- Thème (bleu nuit / clair / comme Windows) ----------
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  try { localStorage.setItem('novaTheme', t); } catch { /* stockage indisponible */ }
  document.querySelectorAll('[data-theme-set]').forEach((b) => b.classList.toggle('active', b.dataset.themeSet === t));
}
document.querySelectorAll('[data-theme-set]').forEach((b) => b.addEventListener('click', async () => {
  applyTheme(b.dataset.themeSet);
  const { settings: st = {} } = await chrome.storage.local.get('settings');
  await chrome.storage.local.set({ settings: { ...st, theme: b.dataset.themeSet } });
  if (typeof settings !== 'undefined') settings.theme = b.dataset.themeSet;
}));
chrome.storage.local.get('settings').then(({ settings: st = {} }) => applyTheme(st.theme || document.documentElement.getAttribute('data-theme') || 'dark'));
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.settings?.newValue?.theme && c.settings.newValue.theme !== document.documentElement.getAttribute('data-theme')) applyTheme(c.settings.newValue.theme); });

// statistiques de rentabilité : recalculées quand ton fichier Excel change
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !c.excelIndex || !statsCache) return;
  statsCache.xi = c.excelIndex.newValue || null;
  if (!$('#statsView').hidden) renderStats();
});
