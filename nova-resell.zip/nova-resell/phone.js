// ===== Import des photos du téléphone via un dossier synchronisé (OneDrive, Google Drive, iCloud…) =====
// Les photos prises à moins de N minutes d'intervalle sont regroupées dans le même article.

const DB = 'va-phone';
function idb(mode, fn) {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open(DB, 1);
    open.onupgradeneeded = () => open.result.createObjectStore('kv');
    open.onsuccess = () => {
      const tx = open.result.transaction('kv', mode);
      const req = fn(tx.objectStore('kv'));
      tx.oncomplete = () => resolve(req?.result);
      tx.onerror = () => reject(tx.error);
    };
    open.onerror = () => reject(open.error);
  });
}
const getDir = () => idb('readonly', (s) => s.get('dir'));
const setDir = (h) => idb('readwrite', (s) => s.put(h, 'dir'));

async function ensurePermission(dir) {
  const opts = { mode: 'read' };
  if ((await dir.queryPermission(opts)) === 'granted') return true;
  return (await dir.requestPermission(opts)) === 'granted';
}

const FOLDER = 'Nova-Resell-Photos';

// Crée le dossier Téléchargements\Nova-Resell-Photos (avec un petit fichier d'explication) et renvoie son chemin
async function createPhotoFolder() {
  const txt = "Dossier des photos pour Nova Resell.\r\nChaque sous-dossier = un article. Les photos posées ici sont importées automatiquement.\r\n";
  const url = 'data:text/plain;charset=utf-8,' + encodeURIComponent(txt);
  const id = await chrome.downloads.download({ url, filename: FOLDER + '/LISEZ-MOI.txt', conflictAction: 'overwrite', saveAs: false });
  for (let i = 0; i < 20; i++) {
    const [d] = await chrome.downloads.search({ id });
    if (d?.state === 'complete') {
      const path = d.filename.replace(/[\\/]LISEZ-MOI[^\\/]*\.txt$/i, '');
      settings.phonePath = path; settings.phoneDlId = id; await saveSettings();
      return path;
    }
    await sleep(250);
  }
  throw new Error('Impossible de créer le dossier');
}

async function setupFolder() {
  try {
    const path = await createPhotoFolder();
    toast('Dossier créé. Sélectionne « ' + FOLDER + ' » puis clique sur « Sélectionner le dossier »');
    await sleep(600);
    const dir = await window.showDirectoryPicker({ id: 'va-phone', mode: 'read', startIn: 'downloads' });
    if (dir.name !== FOLDER && !confirm(`Tu as choisi « ${dir.name} » au lieu de « ${FOLDER} ». Continuer quand même ?`)) return;
    await setDir(dir);
    settings.phoneSince = Date.now() - 24 * 3600 * 1000;
    await saveSettings();
    updatePhoneUi(dir);
    toast('Dossier relié ✓ ' + path);
  } catch (e) { if (e.name !== 'AbortError') toast('Erreur : ' + e.message); }
}

async function chooseFolder() {
  const dir = await window.showDirectoryPicker({ id: 'va-phone', mode: 'read', startIn: 'downloads' });
  await setDir(dir);
  settings.phoneSince = Date.now() - 24 * 3600 * 1000; // au premier choix : seulement les photos des dernières 24 h
  await saveSettings();
  updatePhoneUi(dir);
  return dir;
}

async function listImages(dir) {
  const out = [];
  async function walk(d, depth, group) {
    for await (const [name, h] of d.entries()) {
      if (h.kind === 'directory' && depth < 2) await walk(h, depth + 1, depth === 0 ? name : group);
      else if (h.kind === 'file' && /\.(jpe?g|png|webp)$/i.test(name)) {
        const f = await h.getFile();
        out.push({ file: f, group, key: (group ? group + '/' : '') + name + ':' + f.size });
      }
    }
  }
  await walk(dir, 0, '');
  return out;
}

let importing = false;
async function importFromPhone({ silent = false } = {}) {
  if (importing) return;
  const btn = $('#phoneImport');
  importing = true;
  try {
    let dir = await getDir();
    if (!dir) { if (silent) return; dir = await chooseFolder(); }
    if (!(await ensurePermission(dir))) { if (!silent) toast("Autorise l'accès au dossier pour importer"); return; }
    if (!silent) { btn.disabled = true; btn.textContent = 'Recherche des nouvelles photos…'; }
    const seenStore = await chrome.storage.local.get('phoneSeen');
    const seen = new Set(seenStore.phoneSeen || []);
    const since = Number(settings.phoneSince) || 0;
    const all = await listImages(dir);
    const fresh = all.filter((x) => !seen.has(x.key) && (x.group || x.file.lastModified > since))
      .sort((a, b) => a.file.lastModified - b.file.lastModified);
    if (!fresh.length) { if (!silent) toast('Aucune nouvelle photo'); return; }
    // Un sous-dossier = un article ; photos en vrac : regroupées par écart de temps
    if (silent && Date.now() - fresh[fresh.length - 1].file.lastModified < 8000) return; // dépôt encore en cours
    const groups = [];
    const byFolder = new Map();
    const gap = (Number(settings.phoneGap) || 2) * 60 * 1000;
    for (const x of fresh) {
      if (x.group) {
        if (!byFolder.has(x.group)) { byFolder.set(x.group, []); groups.push(byFolder.get(x.group)); }
        byFolder.get(x.group).push(x);
      } else {
        const last = groups[groups.length - 1];
        if (last && !last[0].group && x.file.lastModified - last[last.length - 1].file.lastModified <= gap) last.push(x);
        else groups.push([x]);
      }
    }
    if (!silent && !confirm(`${fresh.length} nouvelle(s) photo(s) → ${groups.length} article(s).\nImporter ?`)) return;
    for (const g of groups) {
      g.sort((a, b) => a.key.localeCompare(b.key, undefined, { numeric: true }));
      await addArticle(g.map((x) => x.file));
      g.forEach((x) => seen.add(x.key));
      await chrome.storage.local.set({ phoneSeen: [...seen].slice(-5000) });
    }
    settings.phoneSince = Math.max(since, ...fresh.map((x) => x.file.lastModified));
    await saveSettings();
    toast(`${groups.length} article(s) importé(s)`);
  } catch (e) {
    if (e.name !== 'AbortError' && !silent) toast('Erreur : ' + e.message);
  } finally {
    importing = false;
    btn.disabled = false;
    updatePhoneUi(await getDir().catch(() => null));
  }
}

// Surveillance automatique du dossier (toutes les 10 s, tant que le panneau est ouvert)
setInterval(async () => {
  if (!$('#phoneAuto').checked) return;
  const dir = await getDir().catch(() => null);
  if (!dir || (await dir.queryPermission({ mode: 'read' })) !== 'granted') return;
  importFromPhone({ silent: true });
}, 10000);

function updatePhoneUi(dir) {
  $('#phoneImport').textContent = dir ? '📱 Importer les nouvelles photos' : '📂 Relier un dossier existant';
  $('#phoneSetup').hidden = !!dir;
  $('#phoneImport').classList.toggle('grow', !!dir);
  $('#phoneTools').hidden = !dir;
  $('#phonePath').textContent = settings.phonePath && dir && dir.name === FOLDER ? settings.phonePath : (dir ? dir.name : '');
  $('#phoneChange').hidden = !dir;
}

$('#phoneImport').addEventListener('click', () => importFromPhone());
$('#phoneSetup').addEventListener('click', setupFolder);
$('#phoneOpen').addEventListener('click', async () => {
  if (settings.phoneDlId) { try { chrome.downloads.show(settings.phoneDlId); return; } catch { /* fichier supprimé */ } }
  chrome.downloads.showDefaultFolder();
});
$('#phoneCopyMsg').addEventListener('click', () => {
  const path = settings.phonePath || ('Téléchargements\\' + FOLDER);
  copy(`Voici les photos de mes articles Vinted. Regroupe-les par vêtement et dépose-les dans ce dossier de mon PC, avec un sous-dossier par article : ${path}`, 'Message pour Claude copié');
});
$('#phoneAuto').addEventListener('change', () => { settings.phoneAuto = $('#phoneAuto').checked; saveSettings(); if (settings.phoneAuto) importFromPhone(); });
$('#phoneChange').addEventListener('click', async (e) => { e.preventDefault(); try { await chooseFolder(); } catch { /* annulé */ } });
$('#phoneGap').addEventListener('change', () => { settings.phoneGap = Math.min(30, Math.max(1, Number($('#phoneGap').value) || 2)); saveSettings(); });
(async () => {
  const s = await chrome.storage.local.get('settings');
  $('#phoneGap').value = s.settings?.phoneGap ?? 2;
  $('#phoneAuto').checked = s.settings?.phoneAuto !== false;
  updatePhoneUi(await getDir().catch(() => null));
})();
