// ===== Nova Resell – synchronisation avec ton fichier Excel (SKU, statuts, ventes) =====
// Lecture/écriture locale du fichier choisi (rien n'est envoyé en ligne). La mise en forme et les formules sont conservées.
(() => {
  const FIELDS = [
    ['sku', 'SKU', /^(sku|r[ée]f(erence)?|code|n[°o]|num[ée]ro|id)\b/i, false],
    ['title', 'Article / titre', /(article|titre|produit|d[ée]signation|nom|description)/i, false],
    ['brand', 'Marque', /marque|brand/i, false],
    ['size', 'Taille', /taille|size/i, false],
    ['buy', "Prix d'achat", /(achat|co[uû]t|pa\b|prix pay[ée])/i, false],
    ['price', 'Prix en ligne', /(prix (en ligne|affich|vinted|demand|annonce)|^prix$)/i, true],
    ['sold', 'Prix de vente', /(prix (de )?vente|vendu (à|a)|prix final|encaiss|montant vente)/i, true],
    ['status', 'Statut', /(statut|status|[ée]tat (de )?(la )?vente|situation)/i, true],
    ['saleDate', 'Date de vente', /(date (de )?vente|vendu le|date vendu)/i, true],
    ['listDate', 'Date de mise en ligne', /(date (de )?(mise en ligne|publication|ajout|cr[ée]ation))/i, true],
    ['link', 'Lien Vinted', /(lien|url|link)/i, true],
  ];
  const STATUS = { draft: 'Brouillon', online: 'En ligne', sold: 'Vendu', toship: 'Vendu - à expédier', shipped: 'Expédié', returned: 'Retour', done: 'Vendu' };
  const X = window.__novaExcel = { handle: null, wb: null, ws: null, headerRow: 1, map: {}, plan: null };
  const normSku = (v) => { const m = String(v ?? '').match(/p\s*-?\s*(\d+)/i); return m ? 'P' + Number(m[1]) : ''; };
  const cellText = (c) => { const v = c?.value; if (v == null) return ''; if (typeof v === 'object') { if (v.richText) return v.richText.map((r) => r.text).join(''); if (v.text) return String(v.text); if ('result' in v) return String(v.result ?? ''); if (v instanceof Date) return v.toISOString(); } return String(v); };
  const getHandle = () => idb('readonly', (s) => s.get('excel'));
  const setHandle = (h) => idb('readwrite', (s) => s.put(h, 'excel'));
  const setBackup = (b) => idb('readwrite', (s) => s.put(b, 'excelBackup'));
  const getBackup = () => idb('readonly', (s) => s.get('excelBackup'));
  const ui = (id) => $('#' + id);
  const day = (d) => { const x = new Date(d); return isNaN(x) ? null : new Date(x.getFullYear(), x.getMonth(), x.getDate()); };

  async function perm(h, mode) {
    if ((await h.queryPermission({ mode })) === 'granted') return true;
    return (await h.requestPermission({ mode })) === 'granted';
  }
  async function pick() {
    try {
      const [h] = await window.showOpenFilePicker({ id: 'nova-excel', types: [{ description: 'Fichier Excel', accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx', '.xlsm'] } }] });
      X.handle = h; await setHandle(h);
      settings.excel = { ...(settings.excel || {}), name: h.name, sheet: null, map: null }; await saveSettings();
      await load(true);
    } catch (e) { if (e.name !== 'AbortError') toast('Ouverture impossible : ' + e.message); }
  }
  async function load(fresh) {
    if (!X.handle) X.handle = await getHandle().catch(() => null);
    if (!X.handle) return render();
    if (!(await perm(X.handle, 'read'))) { ui('xlInfo').textContent = 'Clique sur « Relire le fichier » pour autoriser Nova à l’ouvrir.'; return render(); }
    const file = await X.handle.getFile();
    X.wb = new ExcelJS.Workbook(); await X.wb.xlsx.load(await file.arrayBuffer());
    const want = settings.excel?.sheet;
    X.ws = X.wb.worksheets.find((w) => w.name === want) || X.wb.worksheets[0];
    detect(fresh || !settings.excel?.map);
    buildIndex();
    render();
  }
  // trouve la ligne d'en-têtes et associe les colonnes automatiquement
  function detect(auto) {
    let best = { row: 1, score: -1 };
    for (let r = 1; r <= Math.min(15, X.ws.rowCount); r++) {
      const vals = []; X.ws.getRow(r).eachCell((c) => vals.push(cellText(c)));
      const score = FIELDS.filter(([, , re]) => vals.some((v) => re.test(v.trim()))).length;
      if (score > best.score) best = { row: r, score };
    }
    X.headerRow = best.row;
    X.headers = [];
    X.ws.getRow(X.headerRow).eachCell({ includeEmpty: false }, (c, col) => X.headers.push({ col, name: cellText(c).trim() }));
    if (auto) {
      const used = new Set(); X.map = {};
      for (const [key, , re] of FIELDS) { const h = X.headers.find((x) => !used.has(x.col) && re.test(x.name)); if (h) { X.map[key] = h.col; used.add(h.col); } }
      if (!X.map.sku) { // SKU repéré dans les données (P12, #P12…)
        const counts = {}; for (let r = X.headerRow + 1; r <= Math.min(X.headerRow + 40, X.ws.rowCount); r++) X.ws.getRow(r).eachCell((c, col) => { if (/^#?p\d+$/i.test(cellText(c).trim())) counts[col] = (counts[col] || 0) + 1; });
        const col = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0]; if (col) X.map.sku = Number(col);
      }
      settings.excel = { ...(settings.excel || {}), sheet: X.ws.name, map: X.map, write: settings.excel?.write || { status: true, sold: true, saleDate: true, price: true, listDate: false, link: true, addNew: true } }; saveSettings();
    } else X.map = settings.excel.map;
  }
  function rows() {
    const out = [];
    for (let r = X.headerRow + 1; r <= X.ws.rowCount; r++) {
      const row = X.ws.getRow(r); const sku = normSku(cellText(row.getCell(X.map.sku || 0)));
      if (!sku && !cellText(row.getCell(X.map.title || 0))) continue;
      out.push({ r, sku, title: X.map.title ? cellText(row.getCell(X.map.title)) : '', buy: X.map.buy ? Number(String(cellText(row.getCell(X.map.buy))).replace(',', '.').replace(/[^\d.-]/g, '')) || null : null });
    }
    return out;
  }
  // Excel → extension : SKU retrouvés par titre (impression des bordereaux) et prix d'achat (marges)
  async function buildIndex() {
    if (!X.map.sku) return;
    const titles = {}, buy = {};
    for (const r of rows()) { if (!r.sku) continue; if (r.title) titles[normTitle(r.title)] = r.sku; if (r.buy != null) buy[r.sku] = r.buy; }
    await chrome.storage.local.set({ excelIndex: { titles, buy, at: Date.now(), name: X.handle?.name } });
  }

  // Vinted → plan de mise à jour
  async function plan() {
    ui('xlInfo').textContent = 'Lecture de ton compte Vinted…';
    const [items, drafts, sales, idx] = await Promise.all([vinted('wardrobe'), vinted('drafts'), vinted('sales', { pages: 5 }), skuIndexLoad()]);
    const v = {}; const skuOfTitle = (t) => normSku((String(t).match(/#\s*P\d+/i) || [])[0]);
    const put = (sku, rec) => { if (!sku) return; const cur = v[sku]; const rank = { draft: 1, online: 2, toship: 4, shipped: 5, returned: 5, sold: 6 }; if (!cur || rank[rec.state] >= rank[cur.state]) v[sku] = { ...cur, ...rec }; };
    for (const d of drafts) put(skuOfTitle(d.title) || normSku(idx.items[d.id]), { state: 'draft', title: d.title, price: d.price, brand: d.brand, size: d.size, link: `https://www.vinted.fr/items/${d.id}` });
    for (const i of items) put(skuOfTitle(i.title) || normSku(idx.items[i.id]), { state: 'online', title: i.title, price: i.price, link: `https://www.vinted.fr/items/${i.id}`, listDate: i.ts ? day(i.ts) : null });
    for (const o of sales) {
      if (o.userStatus === 'failed') continue;
      const state = o.userStatus === 'completed' ? 'sold' : o.isReturn ? 'returned' : (o.shipmentStatus >= 300 ? 'shipped' : 'toship');
      const skus = resolveSkus(o, idx).map(normSku).filter(Boolean);
      for (const sku of skus) put(sku, { state, title: o.title, sold: skus.length > 1 ? null : o.price, saleDate: o.date ? day(o.date) : null });
    }
    const w = settings.excel.write || {}; const changes = []; const seen = new Set();
    for (const r of rows()) {
      if (!r.sku || !v[r.sku]) continue; seen.add(r.sku);
      const rec = v[r.sku], row = X.ws.getRow(r.r), diff = [];
      const set = (key, val) => {
        if (!w[key] || !X.map[key] || val == null || val === '') return;
        const c = row.getCell(X.map[key]); if (c.formula || c.value?.formula || c.value?.sharedFormula) return; // on ne touche jamais aux formules
        const old = c.value instanceof Date ? c.value.toDateString() : cellText(c);
        const nv = val instanceof Date ? val.toDateString() : String(val);
        if (old.trim() !== nv.trim() && !(Number(old.replace(',', '.')) === Number(nv) && nv !== '')) diff.push({ key, cell: c, val, old });
      };
      set('status', STATUS[rec.state]); set('price', rec.price); set('sold', rec.sold); set('saleDate', rec.saleDate); set('listDate', rec.listDate); set('link', rec.link);
      if (diff.length) changes.push({ sku: r.sku, title: r.title || rec.title, diff });
    }
    const added = w.addNew ? Object.entries(v).filter(([sku]) => !seen.has(sku)).map(([sku, rec]) => ({ sku, rec })) : [];
    X.plan = { changes, added, total: Object.keys(v).length };
    renderPlan();
  }
  function renderPlan() {
    const p = X.plan; const box = ui('xlPlan');
    if (!p) { box.replaceChildren(); return; }
    const n = p.changes.reduce((a, c) => a + c.diff.length, 0);
    ui('xlInfo').textContent = !p.changes.length && !p.added.length ? '✅ Ton fichier est déjà à jour avec Vinted.' : `${p.changes.length} article(s) à mettre à jour (${n} case(s)) · ${p.added.length} nouveau(x) SKU à ajouter.`;
    const lbl = Object.fromEntries(FIELDS.map((f) => [f[0], f[1]]));
    const fmt = (x) => (x instanceof Date ? x.toLocaleDateString('fr-FR') : String(x).slice(0, 40));
    box.replaceChildren(...p.changes.slice(0, 60).map((c) => el('div', { className: 'xl-row' }, el('b', { textContent: c.sku }), el('span', { textContent: ' ' + String(c.title).slice(0, 40) }),
      el('div', { className: 'hint' }, c.diff.map((d) => `${lbl[d.key]} : ${d.old || '∅'} → ${fmt(d.val)}`).join(' · ')))),
      ...p.added.slice(0, 30).map((a) => el('div', { className: 'xl-row new' }, el('b', { textContent: '+ ' + a.sku }), el('span', { textContent: ' ' + String(a.rec.title).replace(/\s*\(#P\d+\)\s*$/i, '').slice(0, 40) }), el('div', { className: 'hint', textContent: `${STATUS[a.rec.state]}${a.rec.price ? ' · ' + a.rec.price + ' €' : ''}` }))));
    ui('xlWrite').hidden = !p.changes.length && !p.added.length;
  }
  async function write() {
    const p = X.plan; if (!p) return;
    if (!(await perm(X.handle, 'readwrite'))) return toast('Autorisation refusée : Nova ne peut pas modifier le fichier');
    // relit le fichier juste avant (au cas où tu l'as modifié entre-temps) et garde une copie de sécurité
    const before = await (await X.handle.getFile()).arrayBuffer();
    await setBackup({ name: X.handle.name, at: Date.now(), data: before });
    X.wb = new ExcelJS.Workbook(); await X.wb.xlsx.load(before); X.ws = X.wb.getWorksheet(X.ws.name); await plan();
    for (const c of X.plan.changes) for (const d of c.diff) {
      d.cell.value = d.val; if (d.val instanceof Date && !d.cell.numFmt) d.cell.numFmt = 'dd/mm/yyyy';
    }
    const m = X.map, ref = X.ws.getRow(X.ws.rowCount);
    for (const a of X.plan.added) {
      const row = X.ws.getRow(X.ws.rowCount + 1); const r = a.rec;
      const vals = { sku: a.sku, title: String(r.title || '').replace(/\s*\(#P\d+\)\s*$/i, ''), brand: r.brand, size: r.size, price: r.price, sold: r.sold, status: STATUS[r.state], saleDate: r.saleDate, listDate: r.listDate, link: r.link };
      for (const [k, col] of Object.entries(m)) if (col && vals[k] != null && vals[k] !== '') { const c = row.getCell(col); c.value = vals[k]; c.style = { ...ref.getCell(col).style }; if (vals[k] instanceof Date) c.numFmt = 'dd/mm/yyyy'; }
      row.commit();
    }
    try {
      const w = await X.handle.createWritable(); await w.write(await X.wb.xlsx.writeBuffer()); await w.close();
      const n = X.plan.changes.length + X.plan.added.length;
      settings.excel.lastSync = Date.now(); await saveSettings();
      logActivity({ cat: 'sale', icon: '📗', title: 'Fichier Excel synchronisé', detail: `${X.handle.name} · ${X.plan.changes.length} mis à jour, ${X.plan.added.length} ajouté(s)` });
      toast(`📗 Excel mis à jour (${n} ligne(s))`); X.plan = null; await load(false);
    } catch (e) { toast(/lock|modif|state|busy/i.test(e.name + e.message) ? 'Ferme le fichier dans Excel, puis réessaie' : 'Écriture impossible : ' + e.message); }
  }
  async function restore() {
    const b = await getBackup(); if (!b) return toast('Aucune copie de sécurité');
    if (!confirm(`Remettre « ${b.name} » comme avant la synchro du ${new Date(b.at).toLocaleString('fr-FR')} ?`)) return;
    if (!(await perm(X.handle, 'readwrite'))) return;
    const w = await X.handle.createWritable(); await w.write(b.data); await w.close(); toast('Fichier restauré'); load(false);
  }

  function render() {
    const has = !!X.handle;
    ui('xlEmpty').hidden = has; ui('xlMain').hidden = !has;
    if (!has) return;
    ui('xlName').textContent = X.handle.name;
    ui('xlLast').textContent = settings.excel?.lastSync ? 'Dernière synchro : ' + new Date(settings.excel.lastSync).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Jamais synchronisé';
    if (!X.ws) return;
    ui('xlSheet').replaceChildren(...X.wb.worksheets.map((w) => el('option', { value: w.name, textContent: w.name, selected: w === X.ws })));
    const opts = () => [el('option', { value: '', textContent: '— aucune —' }), ...X.headers.map((h) => el('option', { value: h.col, textContent: h.name || 'Colonne ' + h.col }))];
    const w = settings.excel.write || {};
    ui('xlMap').replaceChildren(...FIELDS.map(([key, label, , writable]) => {
      const sel = el('select', {}, ...opts()); sel.value = X.map[key] || '';
      sel.addEventListener('change', () => { X.map[key] = Number(sel.value) || null; settings.excel.map = X.map; saveSettings(); buildIndex(); X.plan = null; renderPlan(); });
      const chk = writable ? el('input', { type: 'checkbox', checked: !!w[key], title: 'Mettre à jour cette colonne depuis Vinted' }) : null;
      chk?.addEventListener('change', () => { settings.excel.write = { ...settings.excel.write, [key]: chk.checked }; saveSettings(); X.plan = null; renderPlan(); });
      return el('label', { className: 'xl-map' + (key === 'sku' && !X.map.sku ? ' warn' : '') }, el('span', { textContent: label }), sel, chk ? el('span', { className: 'xl-w' }, chk, '↻') : el('span', { className: 'xl-w hint', textContent: 'lu' }));
    }));
    ui('xlAddNew').checked = w.addNew !== false;
    const n = rows().filter((r) => r.sku).length;
    if (!ui('xlInfo').textContent || /SKU repérés|Choisis la colonne/.test(ui('xlInfo').textContent)) ui('xlInfo').textContent = X.map.sku ? `${n} SKU repérés dans « ${X.ws.name} ».` : 'Choisis la colonne qui contient tes SKU.';
  }

  ui('xlPick').addEventListener('click', pick);
  ui('xlChange').addEventListener('click', pick);
  ui('xlReload').addEventListener('click', () => load(false).catch((e) => toast('Lecture impossible : ' + e.message)));
  ui('xlSheet').addEventListener('change', async () => { settings.excel.sheet = ui('xlSheet').value; X.ws = X.wb.getWorksheet(ui('xlSheet').value); detect(true); await buildIndex(); render(); });
  ui('xlAddNew').addEventListener('change', () => { settings.excel.write = { ...settings.excel.write, addNew: ui('xlAddNew').checked }; saveSettings(); X.plan = null; renderPlan(); });
  ui('xlPreview').addEventListener('click', async () => { try { if (!X.ws) await load(false); if (!X.map.sku) return toast('Choisis d’abord la colonne SKU'); await plan(); } catch (e) { ui('xlInfo').textContent = 'Erreur : ' + e.message; } });
  ui('xlWrite').addEventListener('click', () => write().catch((e) => toast('Erreur : ' + e.message)));
  ui('xlRestore').addEventListener('click', () => restore().catch((e) => toast('Erreur : ' + e.message)));
  document.querySelector('.seg-b[data-view=excel]')?.addEventListener('click', () => { if (!X.wb) load(false).catch(() => render()); else render(); });
  getHandle().then((h) => { X.handle = h || null; render(); }).catch(() => render());
})();
