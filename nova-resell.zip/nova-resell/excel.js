// ===== Nova Resell – synchronisation avec ton fichier Excel (SKU, statuts, ventes) =====
// Lecture/écriture locale du fichier choisi (rien n'est envoyé en ligne). La mise en forme et les formules sont conservées.
(() => {
  const FIELDS = [
    ['sku', 'SKU', /^(sku|r[ée]f(erence)?|code|n[°o]|num[ée]ro|id)\b/i, false],
    ['title', 'Article / titre', /(article|titre|produit|d[ée]signation|nom|description)/i, false],
    ['brand', 'Marque', /marque|brand/i, false],
    ['size', 'Taille', /taille|size/i, false],
    ['buy', "Prix d'achat", /(prix d.?achat|achat|co[uû]t|pa\b|prix pay[ée])/i, false],
    ['price', 'Prix en ligne', /(prix (en ligne|affich|vinted|demand|annonce)|^prix$)/i, true],
    ['sold', 'Prix de vente', /(prix (de )?vente|vendu (à|a)|prix final|encaiss|montant vente)/i, true],
    ['status', 'Statut', /(statut|status|[ée]tat (de )?(la )?vente|situation)/i, true],
    ['saleDate', 'Date de vente', /(date (de )?vente|vendu le|date vendu)/i, true],
    ['listDate', 'Date de mise en ligne', /(date (de )?(mise en ligne|publication|ajout|cr[ée]ation))/i, true],
    ['link', 'Lien Vinted', /(lien|url|link)/i, true],
    ['cat', "Catégorie d'achat", /(cat[ée]gorie|provenance|origine|source)/i, false],
  ];
  const STATUS = { draft: 'Brouillon', online: 'En ligne', sold: 'Vendu', toship: 'Vendu - à expédier', shipped: 'Expédié', returned: 'Retour', done: 'Vendu' };
  const X = window.__novaExcel = { handle: null, wb: null, ws: null, headerRow: 1, map: {}, plan: null };
  const normSku = (v) => { const m = String(v ?? '').match(/p\s*-?\s*(\d+)/i); return m ? 'P' + Number(m[1]) : ''; };
  const cellText = (c) => { const v = c?.value; if (v == null) return ''; if (typeof v === 'object') { if (v.richText) return v.richText.map((r) => r.text).join(''); if (v.text) return String(v.text); if ('result' in v) return String(v.result ?? ''); if (v instanceof Date) return v.toISOString(); } return String(v); };
  const getHandle = () => idb('readonly', (s) => s.get('excel'));
  const setHandle = (h) => idb('readwrite', (s) => s.put(h, 'excel'));
  const setBackup = (b) => idb('readwrite', (s) => s.put(b, 'excelBackup'));
  const getBackup = () => idb('readonly', (s) => s.get('excelBackup'));
  // Deux façons de relier le fichier : « direct » (Nova écrit dans ton fichier) ou « copie » (Nova travaille sur une copie importée
  // et te propose d'enregistrer le fichier mis à jour par-dessus l'original : marche avec tous les navigateurs)
  const getCopy = () => idb('readonly', (s) => s.get('excelCopy'));
  const setCopy = (c) => idb('readwrite', (s) => s.put(c, 'excelCopy'));
  const isCopy = () => settings.excel?.mode === 'copy';
  const srcName = () => (isCopy() ? X.copy?.name : X.handle?.name) || '';
  const hasSrc = () => (isCopy() ? !!X.copy : !!X.handle);
  const okExt = (name) => /\.xls[xm]$/i.test(name);
  const badExt = (name) => toast(/\.xls$/i.test(name) ? 'Ancien format .xls : dans Excel, fais Fichier → Enregistrer sous → « Classeur Excel (.xlsx) », puis choisis ce fichier' : /\.csv$/i.test(name) ? 'Fichier CSV : enregistre-le d’abord en .xlsx dans Excel' : 'Choisis un fichier Excel (.xlsx)');
  async function srcRead(ask) {
    if (isCopy()) { if (!X.copy) X.copy = await getCopy().catch(() => null); return X.copy?.data || null; }
    if (!X.handle || !(await perm(X.handle, 'read', ask))) return null;
    return (await X.handle.getFile()).arrayBuffer();
  }
  async function srcWrite(bytes) {
    if (isCopy()) {
      const data = bytes instanceof ArrayBuffer ? bytes : bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
      X.copy = { ...X.copy, data, at: Date.now() }; await setCopy(X.copy);
      const type = /\.xlsm$/i.test(X.copy.name) ? 'application/vnd.ms-excel.sheet.macroEnabled.12' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      const url = URL.createObjectURL(new Blob([data], { type }));
      await chrome.downloads.download({ url, filename: X.copy.name.replace(/[\\/:*?"<>|]/g, '_'), saveAs: true, conflictAction: 'overwrite' });
      setTimeout(() => URL.revokeObjectURL(url), 120000);
      return;
    }
    const w = await X.handle.createWritable(); await w.write(bytes); await w.close();
  }
  async function importCopy(file) {
    if (!file) return;
    if (!okExt(file.name)) return badExt(file.name);
    X.copy = { name: file.name, data: await file.arrayBuffer(), at: Date.now() }; await setCopy(X.copy);
    settings.excel = { ...(settings.excel || {}), mode: 'copy', name: file.name, sheet: null, map: null }; await saveSettings();
    X.wb = null; X.plan = null; X.choosing = false; ui('xlInfo').textContent = '';
    await load(true);
  }
  const ui = (id) => $('#' + id);
  const day = (d) => { const x = new Date(d); return isNaN(x) ? null : new Date(x.getFullYear(), x.getMonth(), x.getDate()); };

  // Autorisation d'accès au fichier. Si le panneau latéral ne peut pas l'afficher, on ouvre une petite fenêtre Nova.
  async function perm(h, mode, fallback = true) {
    try { if ((await h.queryPermission({ mode })) === 'granted') return true; } catch { /* rien */ }
    try { if ((await h.requestPermission({ mode })) === 'granted') return true; } catch { /* pas de geste utilisateur ou panneau latéral */ }
    if (fallback) openAccess('grant', mode);
    return false;
  }
  function openAccess(mode, perm = 'readwrite') {
    toast(mode === 'pick' ? 'Choisis ton fichier dans la fenêtre Nova qui s’ouvre' : 'Autorise l’accès dans la fenêtre Nova qui s’ouvre');
    chrome.windows.create({ url: chrome.runtime.getURL(`file-access.html?mode=${mode}&perm=${perm}`), type: 'popup', width: 440, height: 360, focused: true });
  }
  async function picked(h) {
    if (!okExt(h.name)) return badExt(h.name);
    X.handle = h; X.wb = null; X.plan = null; X.choosing = false;
    settings.excel = { ...(settings.excel || {}), mode: 'direct', name: h.name, sheet: null, map: null }; await saveSettings();
    ui('xlInfo').textContent = '';
    await load(true);
  }
  async function pick() {
    if (!window.showOpenFilePicker) return ui('xlFile').click(); // navigateur sans accès direct (Brave…) : import d'une copie
    const t0 = Date.now();
    try {
      const [h] = await window.showOpenFilePicker({ id: 'nova-excel', startIn: 'documents' }); // tous les fichiers visibles (OneDrive compris)
      if (!okExt(h.name)) return badExt(h.name);
      await setHandle(h);
      await picked(h);
    } catch (e) {
      if (e.name === 'AbortError' && Date.now() - t0 > 900) return; // tu as fermé la fenêtre toi-même
      openAccess('pick'); // le panneau latéral n'a pas pu ouvrir l'explorateur de fichiers
    }
  }
  // réponse de la fenêtre Nova (fichier choisi / accès autorisé)
  chrome.storage.onChanged.addListener(async (ch) => {
    const pk = ch.excelPicked?.newValue;
    if (pk && pk.mode === 'copy') { const c = await getCopy().catch(() => null); if (c) { X.copy = c; settings.excel = { ...(settings.excel || {}), mode: 'copy', name: c.name, sheet: null, map: null }; await saveSettings(); X.wb = null; X.plan = null; X.choosing = false; load(true).catch((e) => toast('Lecture impossible : ' + e.message)); } }
    else if (pk) { const h = await getHandle().catch(() => null); if (h) picked(h).catch((e) => toast('Lecture impossible : ' + e.message)); }
    else if (ch.excelGranted?.newValue) { X.handle = await getHandle().catch(() => X.handle); load(false).catch((e) => toast('Lecture impossible : ' + e.message)); }
  });
  async function load(fresh) {
    if (isCopy()) { if (!X.copy) X.copy = await getCopy().catch(() => null); }
    else if (!X.handle) X.handle = await getHandle().catch(() => null);
    if (!hasSrc()) return render();
    const buf = await srcRead(false);
    if (!buf) { ui('xlInfo').textContent = 'Clique sur « Relire le fichier » pour autoriser Nova à l’ouvrir.'; return render(); }
    await readBuf(buf, fresh || !settings.excel?.map);
    await buildIndex();
    render();
  }
  // lecture du classeur (sans dépendre d'ExcelJS) : une « feuille » = cases lues + tableaux Excel
  function wsFrom(name, grid, tables) {
    const empty = { value: null };
    const cell = (r, c) => grid.cells.get(r)?.get(c) || empty;
    return {
      name, tables, rowCount: grid.maxRow,
      getRow: (r) => ({
        getCell: (c) => cell(r, c),
        eachCell: (o, fn) => { if (typeof o === 'function') fn = o; const row = grid.cells.get(r); if (!row) return; for (const [c, x] of [...row].sort((a, b) => a[0] - b[0])) if (x.value != null && x.value !== '') fn(x, c); },
      }),
    };
  }
  async function readBuf(buf, auto) {
    const P = await XlsxPatch.open(buf);
    const worksheets = [];
    for (const s of P.sheets) { if (!/worksheets\//.test(s.path)) continue; worksheets.push(wsFrom(s.name, await P.readSheet(s.name), await P.tables(s.name).catch(() => []))); }
    if (!worksheets.length) throw new Error('aucune feuille lisible dans ce fichier');
    X.wb = { worksheets, getWorksheet: (n) => worksheets.find((w) => w.name === n) || worksheets[0] };
    const want = settings.excel?.sheet;
    X.ws = X.wb.getWorksheet(want);
    X.tables = X.ws.tables || [];
    detect(auto);
  }
  const lastCol = () => Math.max(1, ...X.headers.map((h) => h.col));
  const isEmptyCol = (col) => { for (let r = X.headerRow; r <= Math.min(X.headerRow + 200, X.ws.rowCount); r++) if (cellText(X.ws.getRow(r).getCell(col)).trim()) return false; return true; };
  // trouve la ligne d'en-têtes et associe les colonnes automatiquement
  function detect(auto) {
    let best = { row: 1, score: -1 };
    for (let r = 1; r <= Math.min(15, X.ws.rowCount); r++) {
      const vals = []; X.ws.getRow(r).eachCell((c) => vals.push(cellText(c)));
      const score = FIELDS.filter(([, , re]) => vals.some((v) => re.test(v.trim()))).length;
      if (score > best.score) best = { row: r, score };
    }
    X.headerRow = best.row;
    X.headers = [];
    X.ws.getRow(X.headerRow).eachCell({ includeEmpty: false }, (c, col) => X.headers.push({ col, name: cellText(c).trim() }));
    X.table = (X.tables || []).find((t) => t.range.r1 === X.headerRow) || null;
    if (auto) {
      const used = new Set(); X.map = {};
      for (const [key, , re] of FIELDS) { const h = X.headers.find((x) => !used.has(x.col) && re.test(x.name)); if (h) { X.map[key] = h.col; used.add(h.col); } }
      if (!X.map.sku) { // SKU repéré dans les données (P12, #P12…)
        const counts = {}; for (let r = X.headerRow + 1; r <= Math.min(X.headerRow + 40, X.ws.rowCount); r++) X.ws.getRow(r).eachCell((c, col) => { if (/^#?p\d+$/i.test(cellText(c).trim())) counts[col] = (counts[col] || 0) + 1; });
        const col = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0]; if (col) X.map.sku = Number(col);
      }
      settings.excel = { ...(settings.excel || {}), sheet: X.ws.name, map: { ...X.map }, write: settings.excel?.write || { status: true, sold: true, saleDate: true, price: true, listDate: false, link: true, addNew: true } }; saveSettings();
    } else X.map = { ...(settings.excel.map || {}) };
    // pas de colonne SKU : Nova en ajoutera une juste à droite du tableau (si la place est libre)
    X.skuNew = false;
    if (!X.map.sku && settings.excel?.addSkuCol !== false) {
      const col = X.table ? X.table.range.c2 + 1 : lastCol() + 1;
      if (isEmptyCol(col)) { X.map.sku = col; X.skuNew = true; }
    }
  }
  const dataEnd = () => (X.table ? X.table.range.r2 : X.ws.rowCount);
  const numOf = (c) => { const v = c?.value; if (typeof v === 'number') return v; if (v && typeof v === 'object' && typeof v.result === 'number') return v.result; const n = Number(String(cellText(c)).replace(',', '.').replace(/[^\d.-]/g, '')); return cellText(c).trim() && Number.isFinite(n) ? n : null; };
  const dateOf = (c) => { const v = c?.value; if (v instanceof Date) return day(v); if (v && typeof v === 'object' && v.result instanceof Date) return day(v.result); if (typeof v === 'number' && v > 20000 && v < 80000) return day(new Date(Date.UTC(1899, 11, 30) + v * 864e5)); const t = cellText(c).trim(); const m = t.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/); return m ? new Date(Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]), Number(m[2]) - 1, Number(m[1])) : null; };
  function rows() {
    const out = []; X.emptyRows = [];
    for (let r = X.headerRow + 1; r <= dataEnd(); r++) {
      const row = X.ws.getRow(r); const sku = X.skuNew ? '' : normSku(cellText(row.getCell(X.map.sku || 0)));
      const title = X.map.title ? cellText(row.getCell(X.map.title)).trim() : '';
      if (!sku && !title) { if (X.table) X.emptyRows.push(r); continue; }
      out.push({ r, sku, title, buy: X.map.buy ? numOf(row.getCell(X.map.buy)) : null, sold: X.map.sold ? numOf(row.getCell(X.map.sold)) : null, saleDate: X.map.saleDate ? dateOf(row.getCell(X.map.saleDate)) : null });
    }
    return out;
  }
  // Excel → extension : SKU retrouvés par titre (impression des bordereaux) et prix d'achat (marges)
  async function buildIndex() {
    const titles = {}, buy = {}, cat = {}, list = [];
    for (const r of rows()) {
      const c = X.map.cat ? cellText(X.ws.getRow(r.r).getCell(X.map.cat)).trim() : '';
      if (r.title || r.sku) list.push({ t: r.title, sku: r.sku || '', buy: r.buy, cat: c });
      if (!r.sku) continue; if (r.title) titles[normTitle(r.title)] = r.sku; if (r.buy != null) buy[r.sku] = r.buy; if (c) cat[r.sku] = c;
    }
    // rows : sert aux statistiques de rentabilité (prix d'achat et provenance retrouvés par le nom si pas de SKU)
    await chrome.storage.local.set({ excelIndex: { titles, buy, cat, rows: list.slice(-3000), at: Date.now(), name: srcName() } });
  }

  // rapprochement par nom : « Veste tommy hilfiger » ↔ « Veste Tommy Hilfiger bleu marine M (#P3) »
  const STOP = new Set(['de', 'du', 'des', 'la', 'le', 'les', 'et', 'en', 'pour', 'avec', 'un', 'une', 'taille', 'homme', 'femme', 'enfant', 'mixte', 'xs', 'xl', 'xxl', 'xxxl', 'tbe', 'neuf']);
  const toks = (t) => normTitle(String(t).replace(/\(#?p\d+\)/ig, '')).split(' ').filter((w) => w.length > 1 && !STOP.has(w));
  function nameScore(rowTitle, vTitle) {
    const a = toks(rowTitle); if (!a.length) return 0;
    const b = toks(vTitle); let n = 0;
    for (const w of a) { if (b.some((x) => x === w || (Math.min(x.length, w.length) >= 4 && (x.startsWith(w) || w.startsWith(x))))) n++; else return 0; }
    return n;
  }
  const sameDay = (a, b) => a && b && Math.abs(a - b) <= 1.5 * 864e5;

  // Vinted → plan de mise à jour
  async function plan() {
    ui('xlInfo').textContent = 'Lecture de ton compte Vinted…';
    const [items, drafts, sales, idx] = await Promise.all([vinted('wardrobe'), vinted('drafts'), vinted('sales', { pages: 5 }), skuIndexLoad()]);
    const v = {}; const skuOfTitle = (t) => normSku((String(t).match(/#\s*P\d+/i) || [])[0]);
    const rank = { draft: 1, online: 2, toship: 4, shipped: 5, returned: 5, sold: 6 };
    const put = (key, rec) => { if (!key) return; const cur = v[key]; if (!cur || rank[rec.state] >= rank[cur.state]) v[key] = { ...cur, ...rec, key }; };
    const clean = (t) => String(t || '').replace(/\s*\(#?P\d+\)\s*$/i, '').trim();
    for (const d of drafts) { const sku = skuOfTitle(d.title) || normSku(idx.items[d.id]); put(sku || 'it:' + d.id, { sku, state: 'draft', title: clean(d.title), price: d.price, brand: d.brand, size: d.size, link: `https://www.vinted.fr/items/${d.id}` }); }
    for (const i of items) { const sku = skuOfTitle(i.title) || normSku(idx.items[i.id]); put(sku || 'it:' + i.id, { sku, state: 'online', title: clean(i.title), price: i.price, link: `https://www.vinted.fr/items/${i.id}`, listDate: i.ts ? day(i.ts) : null }); }
    for (const o of sales) {
      if (o.userStatus === 'failed') continue;
      const state = o.userStatus === 'completed' ? 'sold' : o.isReturn ? 'returned' : (o.shipmentStatus >= 300 ? 'shipped' : 'toship');
      const skus = resolveSkus(o, idx).map(normSku).filter(Boolean);
      const base = { state, sold: skus.length > 1 ? null : o.price, saleDate: o.date ? day(o.date) : null };
      if (skus.length) for (const sku of skus) put(sku, { ...base, sku, title: clean(skus.length > 1 ? (v[sku]?.title || o.title) : o.title) });
      else if (!(o.itemTitles?.length > 1)) put('tx:' + o.transactionId, { ...base, sku: '', title: clean(o.title) });
    }
    const w = settings.excel.write || {}; const links = settings.excel.links || {};
    const list = rows(); const byRow = new Map(list.map((r) => [r.r, r]));
    const linked = new Map(); // clé Vinted → ligne
    const taken = new Set();
    // 1) même SKU
    const bySku = new Map(list.filter((r) => r.sku).map((r) => [r.sku, r]));
    for (const rec of Object.values(v)) { const r = rec.sku && bySku.get(rec.sku); if (r && !taken.has(r.r)) { linked.set(rec.key, r); taken.add(r.r); } }
    // 2) liens déjà faits lors d'une synchro précédente (articles sans SKU)
    for (const rec of Object.values(v)) {
      if (linked.has(rec.key)) continue; const l = links[rec.key]; const r = l && byRow.get(l.r);
      if (r && !taken.has(r.r) && normTitle(r.title) === l.t) { linked.set(rec.key, r); taken.add(r.r); }
    }
    // 3) par le nom : ventes d'abord (sur la ligne qui a la même date de vente, sinon une ligne pas encore vendue)
    const order = Object.values(v).filter((rec) => !linked.has(rec.key)).sort((a, b) => (rank[b.state] - rank[a.state]) || ((a.saleDate || 0) - (b.saleDate || 0)));
    for (const rec of order) {
      let best = null, bestScore = 0;
      for (const r of list) {
        if (taken.has(r.r) || (r.sku && r.sku !== rec.sku)) continue;
        const sc = nameScore(r.title, rec.title); if (!sc) continue;
        const exact = rec.saleDate && sameDay(r.saleDate, rec.saleDate);
        const free = !r.saleDate && r.sold == null;
        if (!exact && !free) continue;
        const score = sc * 10 + (exact ? 100 : 0);
        if (score > bestScore) { best = r; bestScore = score; }
      }
      if (best) { linked.set(rec.key, best); taken.add(best.r); }
    }
    const changes = []; const newLinks = {};
    for (const [key, r] of linked) {
      const rec = v[key]; const row = X.ws.getRow(r.r); const diff = [];
      const set = (k, val) => {
        if (k !== 'sku' && (!w[k] || !X.map[k])) return; if (val == null || val === '') return;
        const c = row.getCell(X.map[k]); if (c.formula || c.value?.formula || c.value?.sharedFormula) return; // on ne touche jamais aux formules
        const old = k === 'sku' && X.skuNew ? '' : (c.value instanceof Date ? c.value.toDateString() : cellText(c));
        const nv = val instanceof Date ? val.toDateString() : String(val);
        if (k === 'saleDate' && sameDay(dateOf(c), val)) return;
        if (old.trim() !== nv.trim() && !(Number(old.replace(',', '.')) === Number(nv) && nv !== '')) diff.push({ key: k, col: X.map[k], val, old });
      };
      if (rec.sku && !r.sku && X.map.sku) set('sku', rec.sku);
      if (!rec.sku) newLinks[key] = { r: r.r, t: normTitle(r.title) };
      set('status', STATUS[rec.state]); set('price', rec.price); set('sold', rec.sold); set('saleDate', rec.saleDate); set('listDate', rec.listDate); set('link', rec.link);
      if (diff.length) changes.push({ r: r.r, sku: rec.sku || r.sku, title: r.title || rec.title, diff });
    }
    // 4) articles Vinted absents du fichier : ajoutés (ventes anciennes ignorées : avant le début de ton fichier)
    const dates = list.map((r) => r.saleDate).filter(Boolean);
    const since = dates.length ? Math.min(...dates) - 864e5 : Date.now() - 30 * 864e5;
    const added = !w.addNew ? [] : Object.values(v).filter((rec) => !linked.has(rec.key) && rec.title && (!rec.saleDate || rec.saleDate >= since || rec.state === 'toship'))
      .sort((a, b) => (a.saleDate || a.listDate || 0) - (b.saleDate || b.listDate || 0)).map((rec) => ({ sku: rec.sku, rec }));
    X.plan = { changes, added, total: Object.keys(v).length, links: newLinks };
    renderPlan();
  }
  function renderPlan() {
    const p = X.plan; const box = ui('xlPlan');
    if (!p) { box.replaceChildren(); return; }
    const n = p.changes.reduce((a, c) => a + c.diff.length, 0);
    ui('xlInfo').textContent = !p.changes.length && !p.added.length && !X.skuNew ? '✅ Ton fichier est déjà à jour avec Vinted.'
      : `${p.changes.length} ligne(s) à mettre à jour (${n} case(s)) · ${p.added.length} article(s) à ajouter.` + (X.skuNew ? ` Une colonne « SKU » sera ajoutée en ${XlsxPatch.colName(X.map.sku)}.` : '');
    const lbl = Object.fromEntries(FIELDS.map((f) => [f[0], f[1]]));
    const fmt = (x) => (x instanceof Date ? x.toLocaleDateString('fr-FR') : String(x).slice(0, 40));
    box.replaceChildren(...p.changes.slice(0, 80).map((c) => el('div', { className: 'xl-row' }, el('b', { textContent: c.sku || 'L' + c.r }), el('span', { textContent: ' ' + String(c.title).slice(0, 40) }),
      el('div', { className: 'hint' }, c.diff.map((d) => `${lbl[d.key]} : ${d.old || '∅'} → ${fmt(d.val)}`).join(' · ')))),
      ...p.added.slice(0, 40).map((a) => el('div', { className: 'xl-row new' }, el('b', { textContent: '+ ' + (a.sku || 'nouveau') }), el('span', { textContent: ' ' + String(a.rec.title).slice(0, 40) }), el('div', { className: 'hint', textContent: `${STATUS[a.rec.state]}${a.rec.sold ? ' · vendu ' + a.rec.sold + ' €' : a.rec.price ? ' · ' + a.rec.price + ' €' : ''}${a.rec.saleDate ? ' · ' + fmt(a.rec.saleDate) : ''}` }))));
    ui('xlWrite').hidden = !p.changes.length && !p.added.length && !X.skuNew;
  }
  async function write() {
    if (!X.plan) return;
    if (!isCopy() && !(await perm(X.handle, 'readwrite'))) return; // la fenêtre d'autorisation s'est ouverte : reclique ensuite sur « Écrire »
    ui('xlWrite').disabled = true;
    try {
      // relit le fichier juste avant (au cas où tu l'as modifié entre-temps) et garde une copie de sécurité
      const before = await srcRead(true); if (!before) throw new Error('fichier illisible');
      await setBackup({ name: srcName(), at: Date.now(), data: before });
      await readBuf(before, false); await plan();
      const p = X.plan, sheet = X.ws.name, m = X.map;
      const P = await XlsxPatch.open(before);
      // colonne SKU ajoutée à droite du tableau
      if (X.skuNew) {
        if (X.table) await P.addTableColumn(sheet, X.table.name, 'SKU');
        else await P.set(sheet, X.headerRow, m.sku, 'SKU', { styleFrom: { r: X.headerRow, c: m.sku - 1 } });
        await P.setColWidth(sheet, m.sku, 11);
      }
      const end = dataEnd();
      const dateStyle = {}; for (const k of ['saleDate', 'listDate']) if (m[k]) dateStyle[k] = await P.dateStyleIn(sheet, m[k], X.headerRow + 1, end);
      const first = X.headerRow + 1;
      for (const c of p.changes) for (const d of c.diff) await P.set(sheet, c.r, d.col, d.val, { styleFrom: { r: first, c: d.col }, dateStyle: dateStyle[d.key] });
      // nouvelles lignes : d'abord les lignes vides déjà prêtes dans ton tableau, sinon à la suite
      const list = rows(); const tpl = list.length ? list[list.length - 1].r : first;
      let next = tpl + 1; const free = [...X.emptyRows].filter((r) => r > tpl);
      const catCol = m.cat; let cat = null;
      if (catCol) { const cnt = {}; for (const r of list) { const t = cellText(X.ws.getRow(r.r).getCell(catCol)).trim(); if (t) cnt[t] = (cnt[t] || 0) + 1; } cat = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0]?.[0] || null; }
      const cols = X.table ? Array.from({ length: X.table.range.c2 - X.table.range.c1 + 1 }, (_, i) => X.table.range.c1 + i) : X.headers.map((h) => h.col);
      let maxRow = 0; const links = { ...(settings.excel.links || {}), ...p.links };
      for (const a of p.added) {
        const r = free.length ? free.shift() : Math.max(next, end + 1, maxRow + 1); next = r + 1; maxRow = Math.max(maxRow, r);
        const rec = a.rec;
        const vals = { sku: a.sku, title: rec.title, brand: rec.brand, size: rec.size, price: rec.price, sold: rec.sold, status: STATUS[rec.state], saleDate: rec.saleDate, listDate: rec.listDate, link: rec.link, cat };
        for (const [k, col] of Object.entries(m)) if (col && vals[k] != null && vals[k] !== '' && (k === 'sku' || k === 'title' || k === 'cat' || (settings.excel.write || {})[k] || ['brand', 'size'].includes(k))) await P.set(sheet, r, col, vals[k], { styleFrom: { r: tpl, c: col }, dateStyle: dateStyle[k] });
        for (const col of cols) await P.copyFormula(sheet, tpl, r, col);
        if (!a.sku && rec.key) links[rec.key] = { r, t: normTitle(rec.title) };
      }
      if (X.table && maxRow > X.table.range.r2) await P.extendTableRows(sheet, X.table.name, maxRow);
      const out = await P.save();
      await srcWrite(out);
      const n = p.changes.length + p.added.length;
      settings.excel.links = Object.fromEntries(Object.entries(links).filter(([, x]) => x).slice(-2000));
      settings.excel.lastSync = Date.now(); await saveSettings();
      logActivity({ cat: 'sale', icon: '📗', title: 'Fichier Excel synchronisé', detail: `${srcName()} · ${p.changes.length} mis à jour, ${p.added.length} ajouté(s)` });
      toast(`📗 Excel mis à jour (${n} ligne(s))`); X.plan = null; await load(false); renderPlan();
      ui('xlInfo').textContent = isCopy()
        ? `✅ Fichier prêt : ${p.changes.length} ligne(s) complétée(s), ${p.added.length} ajoutée(s). Dans la fenêtre « Enregistrer sous », choisis ton fichier d’origine (OneDrive, Documents…) et remplace-le.`
        : `✅ Fichier mis à jour : ${p.changes.length} ligne(s) complétée(s), ${p.added.length} ajoutée(s). Une copie de l’ancienne version est gardée (« Annuler la dernière synchro »).`;
    } catch (e) { toast(/lock|modif|state|busy|NoModificationAllowed|InvalidState/i.test(e.name + e.message) ? 'Ferme le fichier dans Excel, puis réessaie' : 'Écriture impossible : ' + e.message); }
    finally { ui('xlWrite').disabled = false; }
  }
  async function restore() {
    const b = await getBackup(); if (!b) return toast('Aucune copie de sécurité');
    if (!confirm(`Remettre « ${b.name} » comme avant la synchro du ${new Date(b.at).toLocaleString('fr-FR')} ?`)) return;
    if (!isCopy() && !(await perm(X.handle, 'readwrite'))) return;
    await srcWrite(b.data); toast(isCopy() ? 'Enregistre par-dessus ton fichier pour le restaurer' : 'Fichier restauré'); load(false);
  }

  function render() {
    const has = hasSrc() && !X.choosing;
    ui('xlEmpty').hidden = has; ui('xlMain').hidden = !has;
    ui('xlCancel').hidden = !(X.choosing && hasSrc());
    if (!has) return;
    ui('xlName').textContent = srcName();
    ui('xlMode').textContent = isCopy() ? '📥 Mode copie : à chaque écriture, Nova te propose d’enregistrer le fichier mis à jour → remplace ton fichier d’origine. « Réimporter » si tu l’as modifié dans Excel.' : '📂 Nova écrit directement dans ton fichier (OneDrive le synchronise tout seul).';
    ui('xlReload').textContent = isCopy() ? 'Réimporter le fichier' : 'Relire le fichier';
    ui('xlLast').textContent = settings.excel?.lastSync ? 'Dernière synchro : ' + new Date(settings.excel.lastSync).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Jamais synchronisé';
    if (!X.ws) return;
    ui('xlSheet').replaceChildren(...X.wb.worksheets.map((w) => el('option', { value: w.name, textContent: w.name, selected: w === X.ws })));
    const virt = X.skuNew ? X.map.sku : (X.table ? X.table.range.c2 + 1 : lastCol() + 1);
    const opts = (key) => [el('option', { value: '', textContent: '— aucune —' }), ...X.headers.map((h) => el('option', { value: h.col, textContent: h.name || 'Colonne ' + h.col })),
      ...(key === 'sku' && !X.headers.some((h) => h.col === virt) ? [el('option', { value: virt, textContent: `➕ Nouvelle colonne ${XlsxPatch.colName(virt)} (ajoutée par Nova)` })] : [])];
    const w = settings.excel.write || {};
    ui('xlMap').replaceChildren(...FIELDS.map(([key, label, , writable]) => {
      const sel = el('select', {}, ...opts(key)); sel.value = X.map[key] || '';
      sel.addEventListener('change', () => {
        X.map[key] = Number(sel.value) || null;
        if (key === 'sku') { X.skuNew = X.map.sku === virt && !X.headers.some((h) => h.col === virt); settings.excel.addSkuCol = X.skuNew || X.map.sku ? true : false; }
        settings.excel.map = { ...X.map, sku: X.skuNew ? null : X.map.sku }; saveSettings(); buildIndex(); X.plan = null; renderPlan(); render();
      });
      const chk = writable ? el('input', { type: 'checkbox', checked: !!w[key], title: 'Mettre à jour cette colonne depuis Vinted' }) : null;
      chk?.addEventListener('change', () => { settings.excel.write = { ...settings.excel.write, [key]: chk.checked }; saveSettings(); X.plan = null; renderPlan(); });
      return el('label', { className: 'xl-map' + (key === 'sku' && !X.map.sku && !X.map.title ? ' warn' : '') }, el('span', { textContent: label }), sel, chk ? el('span', { className: 'xl-w' }, chk, '↻') : el('span', { className: 'xl-w hint', textContent: 'lu' }));
    }));
    ui('xlAddNew').checked = w.addNew !== false;
    const all = rows(); const n = all.filter((r) => r.sku).length;
    if (!ui('xlInfo').textContent || /SKU repérés|Choisis la colonne|articles repérés|pas de colonne SKU/.test(ui('xlInfo').textContent)) {
      ui('xlInfo').textContent = X.skuNew ? `${all.length} articles repérés dans « ${X.ws.name} ». Ton tableau n'a pas de colonne SKU : Nova l'ajoutera en ${XlsxPatch.colName(X.map.sku)} et reliera tes lignes à Vinted par le nom.`
        : X.map.sku ? `${n} SKU repérés dans « ${X.ws.name} » (${all.length} articles).` : X.map.title ? `${all.length} articles repérés dans « ${X.ws.name} » : liaison avec Vinted par le nom.` : 'Choisis la colonne qui contient tes SKU ou le nom des articles.';
    }
  }

  ui('xlPick').addEventListener('click', pick);
  ui('xlChange').addEventListener('click', (e) => { e.preventDefault(); X.choosing = true; render(); });
  ui('xlCancel').addEventListener('click', (e) => { e.preventDefault(); X.choosing = false; render(); });
  ui('xlImport').addEventListener('click', () => ui('xlFile').click());
  ui('xlFile').addEventListener('change', () => { const f = ui('xlFile').files[0]; ui('xlFile').value = ''; importCopy(f).catch((e) => toast('Lecture impossible : ' + e.message)); });
  ui('xlReload').addEventListener('click', async () => {
    if (isCopy()) return ui('xlFile').click();
    if (X.handle && !(await perm(X.handle, 'read'))) return; load(false).catch((e) => toast('Lecture impossible : ' + e.message));
  });
  ui('xlSheet').addEventListener('change', async () => { settings.excel.sheet = ui('xlSheet').value; X.ws = X.wb.getWorksheet(ui('xlSheet').value); X.tables = X.ws.tables || []; detect(true); await buildIndex(); render(); });
  ui('xlAddNew').addEventListener('change', () => { settings.excel.write = { ...settings.excel.write, addNew: ui('xlAddNew').checked }; saveSettings(); X.plan = null; renderPlan(); });
  ui('xlPreview').addEventListener('click', async () => { try { if (!X.ws) await load(false); if (!X.map.sku && !X.map.title) return toast('Choisis d’abord la colonne SKU ou celle du nom des articles'); await plan(); } catch (e) { ui('xlInfo').textContent = 'Erreur : ' + e.message; } });
  ui('xlWrite').addEventListener('click', () => write().catch((e) => toast('Erreur : ' + e.message)));
  ui('xlRestore').addEventListener('click', () => restore().catch((e) => toast('Erreur : ' + e.message)));
  document.querySelector('.seg-b[data-view=excel]')?.addEventListener('click', () => { if (!X.wb) load(false).catch(() => render()); else render(); });
  (async () => { try { X.handle = (await getHandle()) || null; X.copy = (await getCopy()) || null; } catch { /* rien */ } render(); })();
})();
