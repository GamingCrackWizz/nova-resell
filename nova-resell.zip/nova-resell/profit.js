// ===== Nova Resell – rentabilité : prix d'achat retrouvé pour chaque vente (SKU ou nom de l'article dans ton Excel) =====
// Partagé panneau / arrière-plan (stats de l'appli téléphone). Vinted ne prend pas de commission au vendeur : bénéfice = prix de vente − prix d'achat.
const PROFIT_STOP = new Set(['de', 'du', 'des', 'la', 'le', 'les', 'et', 'en', 'pour', 'avec', 'un', 'une', 'taille', 'homme', 'femme', 'enfant', 'mixte', 'xs', 'xl', 'xxl', 'tbe', 'neuf', 'lot']);
const profitToks = (t) => normTitle(String(t || '').replace(/\(#?p\d+\)/ig, '')).split(' ').filter((w) => w.length > 1 && !PROFIT_STOP.has(w));
function profitTokMatch(rowToks, saleToks) {
  if (!rowToks.length) return 0;
  for (const w of rowToks) if (!saleToks.some((x) => x === w || (Math.min(x.length, w.length) >= 4 && (x.startsWith(w) || w.startsWith(x))))) return 0;
  return rowToks.length;
}
// → { buy, cat, via } ou null
function costOf(title, xi) {
  if (!xi) return null;
  const m = String(title || '').match(/#\s*P\s*(\d+)/i);
  const sku = m ? 'P' + Number(m[1]) : xi.titles?.[normTitle(title)];
  if (sku && xi.buy?.[sku] != null) return { buy: Number(xi.buy[sku]), cat: xi.cat?.[sku] || '', via: 'sku' };
  const st = profitToks(title); let best = null, bs = 0;
  for (const r of xi.rows || []) {
    if (r.buy == null || !r.t) continue;
    const sc = profitTokMatch(profitToks(r.t), st);
    if (sc > bs) { best = r; bs = sc; }
  }
  return best ? { buy: Number(best.buy), cat: best.cat || '', via: 'nom' } : null;
}
// sales : [{title, price, date, status}] → résumé du jour, du mois et des 6 derniers mois
function profitSummary(sales, xi, now = new Date()) {
  const ok = sales.filter((s) => s.status !== 'failed');
  const d0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const m0 = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  const out = { today: { n: 0, ca: 0 }, month: { n: 0, ca: 0, profit: 0, known: 0 }, months: [] };
  for (let k = 5; k >= 0; k--) { const d = new Date(now.getFullYear(), now.getMonth() - k, 1); out.months.push({ label: d.toLocaleDateString('fr-FR', { month: 'short' }), y: d.getFullYear(), m: d.getMonth(), ca: 0, profit: 0, known: 0, n: 0 }); }
  for (const s of ok) {
    const t = new Date(s.date).getTime(); if (!t) continue;
    const c = costOf(s.title, xi); const p = c ? s.price - c.buy : null;
    if (t >= d0) { out.today.n++; out.today.ca += s.price; }
    if (t >= m0) { out.month.n++; out.month.ca += s.price; if (p != null) { out.month.profit += p; out.month.known++; } }
    const d = new Date(t); const mm = out.months.find((x) => x.y === d.getFullYear() && x.m === d.getMonth());
    if (mm) { mm.n++; mm.ca += s.price; if (p != null) { mm.profit += p; mm.known++; } }
  }
  return out;
}
