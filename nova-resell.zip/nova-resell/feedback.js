// ===== Nova Resell – boîte à suggestions des testeurs (onglet Aide) =====
(() => {
  let kind = 'idee';
  document.querySelectorAll('#fbCard .seg-btn[data-fb]').forEach((b) => b.addEventListener('click', () => {
    kind = b.dataset.fb;
    document.querySelectorAll('#fbCard .seg-btn[data-fb]').forEach((x) => x.classList.toggle('active', x === b));
    $('#fbReport').checked = kind === 'bug';
    $('#fbText').placeholder = { idee: 'Ex : ce serait top de pouvoir…', bug: 'Ex : quand je clique sur Republier, il se passe…', avis: 'Ce que tu aimes, ce qui te gêne…' }[kind];
  }));
  async function row(text) {
    const c = await NovaCloud.cfg();
    const r = { kind, message: text, version: chrome.runtime.getManifest().version, email: c.session?.user?.email || null };
    if ($('#fbReport').checked && typeof buildReport === 'function') { try { r.report = String(await buildReport()).slice(0, 8000); } catch { /* pas de rapport */ } }
    return r;
  }
  // messages en attente (pas de connexion) : renvoyés au prochain passage
  async function flush() {
    const { fbQueue = [] } = await chrome.storage.local.get('fbQueue');
    if (!fbQueue.length) return;
    const left = [];
    for (const r of fbQueue) { try { await NovaCloud.sendFeedback(r); } catch { left.push(r); } }
    await chrome.storage.local.set({ fbQueue: left });
  }
  $('#fbSend').addEventListener('click', async () => {
    const text = $('#fbText').value.trim();
    if (text.length < 3) return toast('Écris ton message avant de l’envoyer');
    $('#fbSend').disabled = true; $('#fbInfo').textContent = 'Envoi…';
    const r = await row(text);
    try { await NovaCloud.sendFeedback(r); $('#fbInfo').textContent = '✅ Merci ! Message envoyé.'; }
    catch {
      const { fbQueue = [] } = await chrome.storage.local.get('fbQueue');
      await chrome.storage.local.set({ fbQueue: [...fbQueue, r].slice(-20) });
      $('#fbInfo').textContent = '📨 Merci ! Message gardé : il partira automatiquement dès que possible.';
    }
    $('#fbText').value = ''; $('#fbSend').disabled = false;
    logActivity({ cat: 'msg', icon: '💬', title: 'Suggestion envoyée', detail: text.slice(0, 80), via: 'pc' });
  });
  flush();

  // ----- Administrateur : lecture des suggestions reçues (uniquement pour ce compte) -----
  const ADMIN = 'chantepie.000@gmail.com';
  let filter = 'todo', list = [];
  const KIND = { idee: '💡 Idée', bug: '🐞 Bug', avis: '❤️ Avis' };
  async function isAdmin() { const c = await NovaCloud.cfg(); return (c.session?.user?.email || '').toLowerCase() === ADMIN; }
  async function loadAdmin() {
    if (!(await isAdmin())) { $('#fbAdmin').hidden = true; return; }
    $('#fbAdmin').hidden = false;
    try { list = await NovaCloud.rest('GET', 'feedback?select=*&order=created_at.desc&limit=200') || []; renderAdmin(); }
    catch (e) { $('#fbAdmList').textContent = /done|column/i.test(e.message) ? 'Accès administrateur pas encore activé dans Supabase.' : 'Lecture impossible : ' + e.message; }
  }
  function renderAdmin() {
    const box = $('#fbAdmList'); box.innerHTML = '';
    const todo = list.filter((r) => !r.done);
    $('#fbAdmCount').textContent = todo.length || '';
    const shown = filter === 'todo' ? todo : list;
    if (!shown.length) { box.innerHTML = '<p class="hint">' + (filter === 'todo' ? 'Rien à traiter 🎉' : 'Aucun message pour l’instant.') + '</p>'; return; }
    for (const r of shown) {
      const el = document.createElement('div'); el.className = 'fb-item' + (r.done ? ' done' : '');
      const meta = document.createElement('div'); meta.className = 'fb-meta';
      const d = new Date(r.created_at);
      meta.innerHTML = '<b></b><span></span><span></span><span></span>';
      meta.children[0].textContent = KIND[r.kind] || r.kind || '💬';
      meta.children[1].textContent = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      meta.children[2].textContent = r.email || 'anonyme';
      meta.children[3].textContent = r.version ? 'v' + r.version : '';
      const msg = document.createElement('div'); msg.className = 'fb-msg'; msg.textContent = r.message;
      el.append(meta, msg);
      if (r.report) { const det = document.createElement('details'); det.innerHTML = '<summary>Rapport de diagnostic</summary><pre></pre>'; det.querySelector('pre').textContent = r.report; el.append(det); }
      const acts = document.createElement('div'); acts.className = 'fb-acts';
      const bDone = document.createElement('button'); bDone.className = 'btn small'; bDone.textContent = r.done ? '↩︎ À traiter' : '✓ Traité';
      bDone.addEventListener('click', async () => { try { await NovaCloud.rest('PATCH', 'feedback?id=eq.' + r.id, { done: !r.done }, 'return=minimal'); r.done = !r.done; renderAdmin(); } catch (e) { toast('Erreur : ' + e.message); } });
      const bDel = document.createElement('button'); bDel.className = 'btn ghost small'; bDel.textContent = '🗑';
      bDel.addEventListener('click', async () => {
        if (bDel.dataset.sure !== '1') { bDel.dataset.sure = '1'; bDel.textContent = 'Supprimer ?'; setTimeout(() => { bDel.dataset.sure = ''; bDel.textContent = '🗑'; }, 3000); return; }
        try { await NovaCloud.rest('DELETE', 'feedback?id=eq.' + r.id, null, 'return=minimal'); list = list.filter((x) => x !== r); renderAdmin(); } catch (e) { toast('Erreur : ' + e.message); }
      });
      acts.append(bDone, bDel); el.append(acts);
      box.append(el);
    }
  }
  document.querySelectorAll('#fbAdmin .seg-btn[data-fba]').forEach((b) => b.addEventListener('click', () => {
    filter = b.dataset.fba;
    document.querySelectorAll('#fbAdmin .seg-btn[data-fba]').forEach((x) => x.classList.toggle('active', x === b));
    renderAdmin();
  }));
  $('#fbAdmReload').addEventListener('click', loadAdmin);
  document.querySelector('[data-tab=aide]')?.addEventListener('click', loadAdmin);
  chrome.storage.onChanged.addListener((ch) => { if (!ch.novaCloud) return; const a = ch.novaCloud.oldValue?.session?.user?.email, b = ch.novaCloud.newValue?.session?.user?.email; if (a !== b) loadAdmin(); });
  loadAdmin();
})();
