// ===== Nova Resell – boîte à suggestions des testeurs (onglet Aide) =====
(() => {
  let kind = 'idee';
  document.querySelectorAll('#fbCard .seg-btn[data-fb]').forEach((b) => b.addEventListener('click', () => {
    kind = b.dataset.fb;
    document.querySelectorAll('#fbCard .seg-btn[data-fb]').forEach((x) => x.classList.toggle('active', x === b));
    $('#fbReport').checked = kind === 'bug';
    $('#fbText').placeholder = { idee: 'Ex : ce serait top de pouvoir…', bug: 'Ex : quand je clique sur Republier, il se passe…', avis: 'Ce que tu aimes, ce qui te gêne…' }[kind];
  }));
  async function row(text) {
    const c = await NovaCloud.cfg();
    const r = { kind, message: text, version: chrome.runtime.getManifest().version, email: c.session?.user?.email || null };
    if ($('#fbReport').checked && typeof buildReport === 'function') { try { r.report = String(await buildReport()).slice(0, 8000); } catch { /* pas de rapport */ } }
    return r;
  }
  // messages en attente (pas de connexion) : renvoyés au prochain passage
  async function flush() {
    const { fbQueue = [] } = await chrome.storage.local.get('fbQueue');
    if (!fbQueue.length) return;
    const left = [];
    for (const r of fbQueue) { try { await NovaCloud.sendFeedback(r); } catch { left.push(r); } }
    await chrome.storage.local.set({ fbQueue: left });
  }
  $('#fbSend').addEventListener('click', async () => {
    const text = $('#fbText').value.trim();
    if (text.length < 3) return toast('Écris ton message avant de l’envoyer');
    $('#fbSend').disabled = true; $('#fbInfo').textContent = 'Envoi…';
    const r = await row(text);
    try { await NovaCloud.sendFeedback(r); $('#fbInfo').textContent = '✅ Merci ! Message envoyé.'; }
    catch {
      const { fbQueue = [] } = await chrome.storage.local.get('fbQueue');
      await chrome.storage.local.set({ fbQueue: [...fbQueue, r].slice(-20) });
      $('#fbInfo').textContent = '📨 Merci ! Message gardé : il partira automatiquement dès que possible.';
    }
    $('#fbText').value = ''; $('#fbSend').disabled = false;
    logActivity({ cat: 'msg', icon: '💬', title: 'Suggestion envoyée', detail: text.slice(0, 80), via: 'pc' });
  });
  flush();
})();
