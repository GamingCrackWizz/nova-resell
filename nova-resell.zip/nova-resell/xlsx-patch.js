// ===== Nova Resell – écriture « chirurgicale » dans un fichier Excel =====
// On modifie uniquement les cases nécessaires dans le XML du fichier : mise en forme, tableaux, listes déroulantes,
// mises en forme conditionnelles, graphiques et autres feuilles restent exactement comme avant.
const XlsxPatch = (() => {
  const NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  const NS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  const NS_PR = 'http://schemas.openxmlformats.org/package/2006/relationships';
  const colNum = (s) => [...s.toUpperCase()].reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0);
  const colName = (n) => { let s = ''; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  const parseRef = (ref) => { const m = /^\$?([A-Z]+)\$?(\d+)$/i.exec(ref); return m ? { c: colNum(m[1]), r: Number(m[2]) } : null; };
  const parseRange = (ref) => { const [a, b] = String(ref).split(':'); const A = parseRef(a), B = parseRef(b || a); return A && B ? { c1: A.c, r1: A.r, c2: B.c, r2: B.r } : null; };
  const rangeStr = (g) => `${colName(g.c1)}${g.r1}:${colName(g.c2)}${g.r2}`;
  const xmlParse = (s) => new DOMParser().parseFromString(s, 'application/xml');
  const xmlStr = (d) => { let s = new XMLSerializer().serializeToString(d); if (!s.startsWith('<?xml')) s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' + s; return s; };
  const kids = (el, name) => [...el.childNodes].filter((n) => n.nodeType === 1 && n.localName === name);
  const dirOf = (p) => p.replace(/[^/]*$/, '');
  const resolve = (base, target) => { if (target.startsWith('/')) return target.slice(1); const parts = (dirOf(base) + target).split('/'); const out = []; for (const p of parts) { if (p === '..') out.pop(); else if (p !== '.') out.push(p); } return out.join('/'); };
  const relsPath = (p) => dirOf(p) + '_rels/' + p.split('/').pop() + '.rels';
  const toSerial = (d) => (Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(1899, 11, 30)) / 864e5;

  // décale les références A1 relatives d'une formule (copie d'une formule sur une autre ligne)
  function shiftFormula(f, dRow) {
    if (!dRow) return f;
    let out = '', inStr = false;
    for (let i = 0; i < f.length;) {
      const ch = f[i];
      if (ch === '"') { inStr = !inStr; out += ch; i++; continue; }
      if (inStr) { out += ch; i++; continue; }
      if (ch === '[') { const j = f.indexOf(']', i); const k = j < 0 ? f.length : j + 1; out += f.slice(i, k); i = k; continue; } // références de tableau
      const m = /^(\$?)([A-Z]{1,3})(\$?)(\d+)(?![\d(A-Za-z_])/.exec(f.slice(i));
      const prev = i > 0 ? f[i - 1] : '';
      if (m && !/[A-Za-z0-9_.]/.test(prev)) {
        out += m[1] + m[2] + m[3] + (m[3] ? m[4] : String(Number(m[4]) + dRow));
        i += m[0].length; continue;
      }
      out += ch; i++;
    }
    return out;
  }

  async function open(buf) {
    const zip = await JSZip.loadAsync(buf);
    const files = {}; // chemin → document XML modifié
    const doc = async (p) => { if (!files[p]) { const f = zip.file(p); if (!f) return null; files[p] = xmlParse(await f.async('string')); } return files[p]; };
    const wb = await doc('xl/workbook.xml');
    const wbRels = await doc('xl/_rels/workbook.xml.rels');
    const relTarget = (rels, id) => kids(rels.documentElement, 'Relationship').find((r) => r.getAttribute('Id') === id)?.getAttribute('Target');
    const sheets = kids(kids(wb.documentElement, 'sheets')[0], 'sheet').map((s) => ({ name: s.getAttribute('name'), path: resolve('xl/workbook.xml', relTarget(wbRels, s.getAttributeNS(NS_R, 'id') || s.getAttribute('r:id'))) }));
    const sheetPath = (name) => (sheets.find((s) => s.name === name) || sheets[0]).path;

    async function tables(sheetName) {
      const sp = sheetPath(sheetName); const sd = await doc(sp); const rels = await doc(relsPath(sp));
      const out = [];
      for (const tp of kids(sd.documentElement, 'tableParts')[0] ? kids(kids(sd.documentElement, 'tableParts')[0], 'tablePart') : []) {
        const path = resolve(sp, relTarget(rels, tp.getAttributeNS(NS_R, 'id') || tp.getAttribute('r:id')));
        const td = await doc(path); const t = td.documentElement;
        out.push({ path, name: t.getAttribute('displayName') || t.getAttribute('name'), ref: t.getAttribute('ref'), range: parseRange(t.getAttribute('ref')), header: Number(t.getAttribute('headerRowCount') ?? 1), totals: Number(t.getAttribute('totalsRowCount') || 0) });
      }
      return out;
    }

    // ---- styles : reconnaître un format de date ----
    let xfs = null;
    async function styles() {
      if (xfs) return xfs;
      const st = await doc('xl/styles.xml'); xfs = { fmt: [], codes: {} };
      if (!st) return xfs;
      const nf = kids(st.documentElement, 'numFmts')[0];
      if (nf) for (const f of kids(nf, 'numFmt')) xfs.codes[f.getAttribute('numFmtId')] = f.getAttribute('formatCode') || '';
      const cx = kids(st.documentElement, 'cellXfs')[0];
      if (cx) xfs.fmt = kids(cx, 'xf').map((x) => x.getAttribute('numFmtId') || '0');
      return xfs;
    }
    async function isDateStyle(s) {
      const st = await styles(); const id = st.fmt[Number(s || 0)] || '0'; const n = Number(id);
      if ((n >= 14 && n <= 22) || (n >= 45 && n <= 47) || (n >= 27 && n <= 36) || (n >= 50 && n <= 58)) return true;
      const code = String(st.codes[id] || '').replace(/"[^"]*"|\\.|\[[^\]]*\]/g, '');
      return /[dmy]/i.test(code) && !/^[#0.,\s%-]+$/.test(code);
    }
    // un style de date déjà utilisé dans cette colonne (pour écrire une date bien affichée)
    async function dateStyleIn(sheetName, c, r1, r2) {
      const { sd, data } = await sheetData(sheetName);
      for (const row of kids(data, 'row')) {
        const r = Number(row.getAttribute('r')); if (r < r1 || r > r2) continue;
        const cell = cellEl(sd, row, r, c, false); const st = cell?.getAttribute('s');
        if (st && await isDateStyle(st)) return st;
      }
      return null;
    }

    // ---- lecture (sans ExcelJS : plus robuste avec les tableaux et mises en forme d'Excel) ----
    const textOf = (el) => { let out = ''; const walk = (n) => { for (const k of n.childNodes) { if (k.nodeType !== 1) continue; if (k.localName === 'rPh') continue; if (k.localName === 't') out += k.textContent; else walk(k); } }; walk(el); return out; };
    let ssCache = null;
    async function sharedStrings() { if (ssCache) return ssCache; const d = await doc('xl/sharedStrings.xml'); ssCache = d ? kids(d.documentElement, 'si').map(textOf) : []; return ssCache; }
    const fromSerial = (n) => { const d = new Date(Date.UTC(1899, 11, 30) + Math.round(n * 864e5)); return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); };
    async function readSheet(sheetName) {
      const cells = new Map(); let maxRow = 0, maxCol = 0;
      const sd = await doc(sheetPath(sheetName)); const data = sd && kids(sd.documentElement, 'sheetData')[0];
      if (!data) return { cells, maxRow, maxCol };
      const ss = await sharedStrings();
      for (const row of kids(data, 'row')) {
        const r = Number(row.getAttribute('r')); const line = new Map();
        for (const c of kids(row, 'c')) {
          const ref = parseRef(c.getAttribute('r') || ''); if (!ref) continue;
          const t = c.getAttribute('t'); const f = kids(c, 'f')[0]; const vEl = kids(c, 'v')[0]; const v = vEl ? vEl.textContent : null;
          let val = null;
          if (t === 's') val = v != null ? ss[Number(v)] ?? '' : null;
          else if (t === 'inlineStr') { const is = kids(c, 'is')[0]; val = is ? textOf(is) : ''; }
          else if (t === 'str' || t === 'e') val = v;
          else if (t === 'b') val = v === '1';
          else if (v != null && v !== '') { const n = Number(v); val = (await isDateStyle(c.getAttribute('s'))) && n > 0 && n < 2958466 ? fromSerial(n) : n; }
          const cell = f ? { value: { formula: f.textContent || '(partagée)', result: val }, formula: true } : { value: val };
          line.set(ref.c, cell);
          if (val != null && val !== '' || f) { maxRow = Math.max(maxRow, r); maxCol = Math.max(maxCol, ref.c); }
        }
        if (line.size) cells.set(r, line);
      }
      return { cells, maxRow, maxCol };
    }

    // ---- cellules ----
    async function sheetData(sheetName) { const sd = await doc(sheetPath(sheetName)); return { sd, data: kids(sd.documentElement, 'sheetData')[0] }; }
    function rowEl(sd, data, r, create) {
      let before = null;
      for (const el of kids(data, 'row')) { const n = Number(el.getAttribute('r')); if (n === r) return el; if (n > r) { before = el; break; } }
      if (!create) return null;
      const el = sd.createElementNS(NS, 'row'); el.setAttribute('r', String(r)); data.insertBefore(el, before); return el;
    }
    function cellEl(sd, row, r, c, create) {
      let before = null;
      for (const el of kids(row, 'c')) { const p = parseRef(el.getAttribute('r')); if (p.c === c) return el; if (p.c > c) { before = el; break; } }
      if (!create) return null;
      const el = sd.createElementNS(NS, 'c'); el.setAttribute('r', colName(c) + r); row.insertBefore(el, before); row.removeAttribute('spans'); return el;
    }
    // valeur : nombre, texte, Date ou null (vide). styleFrom : {r, c} dont on copie la mise en forme si la case n'en a pas
    async function set(sheetName, r, c, value, { styleFrom, force, dateStyle } = {}) {
      const { sd, data } = await sheetData(sheetName);
      const row = rowEl(sd, data, r, true); const cell = cellEl(sd, row, r, c, true);
      if (kids(cell, 'f').length && !force) return false; // jamais sur une formule
      if (styleFrom && !cell.getAttribute('s')) { const src = cellEl(sd, rowEl(sd, data, styleFrom.r, false) || sd.createElementNS(NS, 'row'), styleFrom.r, styleFrom.c, false); if (src?.getAttribute('s')) cell.setAttribute('s', src.getAttribute('s')); }
      for (const k of [...kids(cell, 'v'), ...kids(cell, 'is'), ...kids(cell, 'f')]) cell.removeChild(k);
      cell.removeAttribute('t');
      if (value == null || value === '') return true;
      if (value instanceof Date) { if (dateStyle && !(await isDateStyle(cell.getAttribute('s')))) cell.setAttribute('s', dateStyle); value = toSerial(value); }
      if (typeof value === 'number' && Number.isFinite(value)) { const v = sd.createElementNS(NS, 'v'); v.textContent = String(value); cell.appendChild(v); }
      else { cell.setAttribute('t', 'inlineStr'); const is = sd.createElementNS(NS, 'is'); const t = sd.createElementNS(NS, 't'); t.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:space', 'preserve'); t.textContent = String(value); is.appendChild(t); cell.appendChild(is); }
      return true;
    }
    // recopie la formule (et le style) d'une case vers une autre ligne, en décalant les références
    async function copyFormula(sheetName, fromR, toR, c) {
      const { sd, data } = await sheetData(sheetName);
      const src = cellEl(sd, rowEl(sd, data, fromR, false) || sd.createElementNS(NS, 'row'), fromR, c, false);
      const f = src && kids(src, 'f')[0]; if (!f) return false;
      let text = f.textContent, base = fromR;
      if (f.getAttribute('t') === 'shared' && !text) { // formule partagée : on retrouve la formule maître
        const si = f.getAttribute('si');
        for (const fe of sd.getElementsByTagNameNS(NS, 'f')) if (fe.getAttribute('t') === 'shared' && fe.getAttribute('si') === si && fe.textContent) { text = fe.textContent; base = parseRef(fe.parentNode.getAttribute('r')).r; break; }
      }
      if (!text) return false;
      const row = rowEl(sd, data, toR, true); const cell = cellEl(sd, row, toR, c, true);
      if (kids(cell, 'f').length) return true; // déjà une formule
      for (const k of [...kids(cell, 'v'), ...kids(cell, 'is')]) cell.removeChild(k);
      cell.removeAttribute('t');
      if (src.getAttribute('s') && !cell.getAttribute('s')) cell.setAttribute('s', src.getAttribute('s'));
      const nf = sd.createElementNS(NS, 'f'); nf.textContent = shiftFormula(text, toR - base); cell.appendChild(nf);
      return true;
    }
    async function setColWidth(sheetName, c, width) {
      const sd = await doc(sheetPath(sheetName)); const root = sd.documentElement;
      let cols = kids(root, 'cols')[0];
      if (!cols) { cols = sd.createElementNS(NS, 'cols'); root.insertBefore(cols, kids(root, 'sheetData')[0]); }
      for (const el of kids(cols, 'col')) {
        const a = Number(el.getAttribute('min')), b = Number(el.getAttribute('max'));
        if (c < a || c > b) continue;
        // on isole la colonne c dans sa propre définition
        const mk = (x, y) => { const n = el.cloneNode(false); n.setAttribute('min', String(x)); n.setAttribute('max', String(y)); return n; };
        if (a < c) cols.insertBefore(mk(a, c - 1), el);
        if (b > c) cols.insertBefore(mk(c + 1, b), el.nextSibling);
        el.setAttribute('min', String(c)); el.setAttribute('max', String(c)); el.setAttribute('width', String(width)); el.setAttribute('customWidth', '1'); el.removeAttribute('hidden');
        return;
      }
      const n = sd.createElementNS(NS, 'col'); n.setAttribute('min', String(c)); n.setAttribute('max', String(c)); n.setAttribute('width', String(width)); n.setAttribute('customWidth', '1');
      const after = kids(cols, 'col').find((el) => Number(el.getAttribute('min')) > c) || null; cols.insertBefore(n, after);
    }

    // ---- tableaux ----
    // ajoute une colonne à droite d'un tableau Excel (en-tête « name »)
    async function addTableColumn(sheetName, tableName, name) {
      const t = (await tables(sheetName)).find((x) => x.name === tableName); if (!t) throw new Error('Tableau introuvable');
      const td = await doc(t.path); const root = td.documentElement; const g = t.range;
      const nc = g.c2 + 1;
      const ng = { ...g, c2: nc };
      root.setAttribute('ref', rangeStr(ng));
      const af = kids(root, 'autoFilter')[0]; if (af) { const ag = parseRange(af.getAttribute('ref')); af.setAttribute('ref', rangeStr({ ...ag, c2: nc })); }
      const tcs = kids(root, 'tableColumns')[0]; const list = kids(tcs, 'tableColumn');
      const id = Math.max(0, ...list.map((x) => Number(x.getAttribute('id')))) + 1;
      const tc = td.createElementNS(NS, 'tableColumn'); tc.setAttribute('id', String(id)); tc.setAttribute('name', name);
      tcs.appendChild(tc); tcs.setAttribute('count', String(list.length + 1));
      // en-tête + style des cases recopié de la colonne voisine
      await set(sheetName, g.r1, nc, name, { styleFrom: { r: g.r1, c: g.c2 } });
      for (let r = g.r1 + 1; r <= g.r2; r++) {
        const { sd, data } = await sheetData(sheetName);
        const row = rowEl(sd, data, r, false); const src = row && cellEl(sd, row, r, g.c2, false);
        if (src?.getAttribute('s')) { const cell = cellEl(sd, row, r, nc, true); if (!cell.getAttribute('s')) cell.setAttribute('s', src.getAttribute('s')); }
      }
      // titre fusionné au-dessus du tableau (ex. A1:F1) : on l'étend à la nouvelle colonne
      const sd = await doc(sheetPath(sheetName)); const mcs = kids(sd.documentElement, 'mergeCells')[0];
      if (mcs) for (const mc of kids(mcs, 'mergeCell')) { const mg = parseRange(mc.getAttribute('ref')); if (mg && mg.c1 === g.c1 && mg.c2 === g.c2 && mg.r2 < g.r1) mc.setAttribute('ref', rangeStr({ ...mg, c2: nc })); }
      extendRanges(sd, g, ng);
      return nc;
    }
    // agrandit un tableau vers le bas jusqu'à la ligne r2
    async function extendTableRows(sheetName, tableName, r2) {
      const t = (await tables(sheetName)).find((x) => x.name === tableName); if (!t || r2 <= t.range.r2) return;
      if (t.totals) throw new Error('Tableau avec ligne de total : ajoute des lignes vides dans Excel');
      const td = await doc(t.path); const root = td.documentElement; const ng = { ...t.range, r2 };
      root.setAttribute('ref', rangeStr(ng));
      const af = kids(root, 'autoFilter')[0]; if (af) { const ag = parseRange(af.getAttribute('ref')); af.setAttribute('ref', rangeStr({ ...ag, r2 })); }
      extendRanges(await doc(sheetPath(sheetName)), t.range, ng);
    }
    // listes déroulantes et mises en forme conditionnelles qui couvraient exactement l'ancien tableau : on les étend
    function extendRanges(sd, og, ng) {
      const fix = (el) => {
        const parts = String(el.getAttribute('sqref') || '').split(/\s+/).filter(Boolean).map((p) => {
          const g = parseRange(p); if (!g) return p;
          let h = { ...g };
          if (ng.r2 > og.r2 && g.r2 === og.r2 && g.r1 >= og.r1 && g.c1 >= og.c1 && g.c2 <= og.c2) h.r2 = ng.r2;
          return g.c1 === g.c2 && g.r1 === g.r2 && h.r2 === g.r2 ? p : rangeStr(h);
        });
        el.setAttribute('sqref', parts.join(' '));
      };
      for (const el of sd.getElementsByTagNameNS(NS, 'dataValidation')) fix(el);
      for (const el of sd.getElementsByTagNameNS(NS, 'conditionalFormatting')) fix(el);
    }

    async function save() {
      // recalcul complet à l'ouverture dans Excel (bénéfices, totaux…)
      const calc = kids(wb.documentElement, 'calcPr')[0] || (() => { const c = wb.createElementNS(NS, 'calcPr'); wb.documentElement.appendChild(c); return c; })();
      calc.setAttribute('fullCalcOnLoad', '1');
      files['xl/workbook.xml'] = wb;
      // la chaîne de calcul n'est plus valable : Excel la reconstruit
      if (zip.file('xl/calcChain.xml')) {
        zip.remove('xl/calcChain.xml');
        for (const r of kids(wbRels.documentElement, 'Relationship')) if (/calcChain/i.test(r.getAttribute('Type'))) wbRels.documentElement.removeChild(r);
        files['xl/_rels/workbook.xml.rels'] = wbRels;
        const ct = await doc('[Content_Types].xml');
        for (const o of kids(ct.documentElement, 'Override')) if (/calcChain/i.test(o.getAttribute('PartName'))) ct.documentElement.removeChild(o);
      }
      for (const [p, d] of Object.entries(files)) zip.file(p, xmlStr(d));
      return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    }
    return { sheets, tables, readSheet, set, copyFormula, setColWidth, addTableColumn, extendTableRows, dateStyleIn, isDateStyle, save, colName, parseRange };
  }
  return { open, shiftFormula, colName, colNum, parseRange };
})();
