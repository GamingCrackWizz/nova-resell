// ===== Nova Resell – bandeau « mise à jour disponible » =====
(() => {
  if (/print|worker/.test(location.hash)) return;
  async function render() {
    const { updateAvail: u, updateSnooze = {} } = await chrome.storage.local.get(['updateAvail', 'updateSnooze']);
    const show = !!u?.version && !(updateSnooze.version === u.version && Date.now() < updateSnooze.until);
    $('#updateBanner').hidden = !show;
    if (!show) return;
    $('#updTitle').textContent = `✨ Nova Resell ${novaVer(u.version)} est disponible (tu as la ${novaVer()})`;
    $('#updNotes').replaceChildren(...(u.notes || []).slice(0, 4).map((n) => el('span', { className: 'upd-note', textContent: '• ' + n })));
  }
  $('#updGet').addEventListener('click', async () => {
    const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
    if (!u?.setup) return chrome.tabs.create({ url: 'https://github.com/GamingCrackWizz/nova-resell' });
    chrome.downloads.download({ url: u.setup, filename: `Installer Nova Resell ${u.version}.exe`, saveAs: false });
    toast('Téléchargement lancé : ouvre le fichier puis clique sur ↻');
  });
  $('#updLater').addEventListener('click', async () => {
    const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
    await chrome.storage.local.set({ updateSnooze: { version: u?.version, until: Date.now() + 24 * 3600e3 } });
    render();
  });
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && (c.updateAvail || c.updateSnooze)) render(); });
  render();
  chrome.runtime.sendMessage({ va: 'checkUpdate' }).catch(() => {});
})();
