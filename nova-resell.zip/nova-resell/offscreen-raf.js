// Le document invisible n'affiche aucune image : requestAnimationFrame ne se déclenche jamais, on le remplace par un minuteur
window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 0);
window.cancelAnimationFrame = (id) => clearTimeout(id);
