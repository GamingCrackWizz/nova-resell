// ===== Nova Resell – compte Nova (Supabase) partagé entre l'extension (PC) et l'appli mobile =====
// Utilisé par le panneau (connexion) et par l'arrière-plan (synchronisation). Aucune bibliothèque : API REST Supabase.
const NOVA_APP_URL = 'https://novaresell.github.io/nova-resell/';  // appli mobile (aussi page de nouveau mot de passe)
const NOVA_DEFAULT = { url: 'https://btbohxtqruyudzxbgwvt.supabase.co', key: 'sb_publishable_VHJLxRBOdQoLWDkRK-ecIg_8RsPcusj' };

const NovaCloud = {
  async cfg() {
    const { novaCloud = {} } = await chrome.storage.local.get('novaCloud');
    const url = (novaCloud.url || (NOVA_DEFAULT.url.startsWith('http') ? NOVA_DEFAULT.url : '')).replace(/\/+$/, '');
    const key = novaCloud.key || (NOVA_DEFAULT.key.startsWith('__') ? '' : NOVA_DEFAULT.key);
    return { ...novaCloud, url, key };
  },
  async save(patch) {
    const { novaCloud = {} } = await chrome.storage.local.get('novaCloud');
    await chrome.storage.local.set({ novaCloud: { ...novaCloud, ...patch } });
  },
  async auth(path, body) {
    const c = await this.cfg();
    if (!c.url || !c.key) throw new Error('Adresse et clé du projet Nova manquantes');
    const r = await fetch(`${c.url}/auth/v1/${path}`, { method: 'POST', headers: { apikey: c.key, 'content-type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(NovaCloud.fr(j.error_description || j.msg || j.message || `Erreur ${r.status}`));
    return j;
  },
  keep(j) { return { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: Math.floor(Date.now() / 1000) + (j.expires_in || 3600), user: { id: j.user?.id, email: j.user?.email } }; },
  async signIn(email, password) {
    const j = await this.auth('token?grant_type=password', { email, password });
    await this.save({ session: this.keep(j) });
    return j.user;
  },
  async signUp(email, password) {
    const j = await this.auth('signup', { email, password });
    if (j.access_token) { await this.save({ session: this.keep(j) }); return { ok: true }; }
    return { confirm: true };
  },
  // E-mail « mot de passe oublié » : le lien ouvre l'appli Nova, qui demande le nouveau mot de passe
  async recover(email) {
    const c = await this.cfg();
    if (!c.url || !c.key) throw new Error('Adresse et clé du projet Nova manquantes');
    const r = await fetch(`${c.url}/auth/v1/recover?redirect_to=${encodeURIComponent(NOVA_APP_URL)}`, { method: 'POST', headers: { apikey: c.key, 'content-type': 'application/json' }, body: JSON.stringify({ email }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(NovaCloud.fr(j.msg || j.error_description || j.message || `Erreur ${r.status}`)); }
    return true;
  },
  fr(m) {
    return /invalid login/i.test(m) ? 'E-mail ou mot de passe incorrect'
      : /not confirmed/i.test(m) ? "E-mail pas encore confirmé : clique sur le lien reçu par e-mail"
      : /already (registered|exists)/i.test(m) ? 'Un compte existe déjà avec cet e-mail : connecte-toi'
      : /rate limit|too many|security purposes/i.test(m) ? 'Trop de demandes : attends quelques minutes puis réessaie'
      : /password/i.test(m) && /6|short|least/i.test(m) ? 'Mot de passe : 6 caractères minimum'
      : /valid email|invalid.*email|email.*invalid/i.test(m) ? "Adresse e-mail invalide"
      : m;
  },
  async signOut() { await this.save({ session: null }); },
  async token() {
    const c = await this.cfg();
    const s = c.session;
    if (!s?.refresh_token) return null;
    if (s.expires_at - 90 > Date.now() / 1000) return { c, s };
    try {
      const j = await this.auth('token?grant_type=refresh_token', { refresh_token: s.refresh_token });
      const ns = this.keep(j); await this.save({ session: ns });
      return { c, s: ns };
    } catch (e) { await this.save({ session: null, lastError: 'Session expirée : reconnecte-toi' }); return null; }
  },
  async rest(method, path, body, prefer) {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/rest/v1/${path}`, { method, headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': 'application/json', ...(prefer ? { prefer } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const txt = await r.text(); let j = null; try { j = txt ? JSON.parse(txt) : null; } catch { /* vide */ }
    if (!r.ok) throw new Error(j?.message || `Erreur ${r.status}`);
    return j;
  },
  async download(path) {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/storage/v1/object/authenticated/photos/${path}`, { headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}` } });
    if (!r.ok) throw new Error('Photo introuvable (' + r.status + ')');
    return r.blob();
  },
  // Sauvegarde des réglages dans le compte Nova (fichier privé dans ton dossier du stockage)
  async uploadBackup(obj) {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/storage/v1/object/photos/${t.s.user.id}/_backup/nova-settings.json`, { method: 'POST', headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': 'application/json', 'x-upsert': 'true' }, body: JSON.stringify(obj) });
    if (!r.ok) throw new Error('Sauvegarde refusée (' + r.status + ')');
    await this.save({ lastBackup: Date.now() });
    return true;
  },
  async downloadBackup() {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/storage/v1/object/authenticated/photos/${t.s.user.id}/_backup/nova-settings.json?t=${Date.now()}`, { headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}` }, cache: 'no-store' });
    if (r.status === 400 || r.status === 404) return null;
    if (!r.ok) throw new Error('Lecture de la sauvegarde impossible (' + r.status + ')');
    return r.json();
  },
  // Message de suggestion (bêta) : enregistré dans la table « feedback », lisible seulement par l'administrateur
  async sendFeedback(row) {
    const c = await this.cfg();
    if (!c.url || !c.key) throw new Error('Projet Nova non configuré');
    const t = await this.token().catch(() => null);
    const r = await fetch(`${c.url}/rest/v1/feedback`, { method: 'POST', headers: { apikey: c.key, authorization: `Bearer ${t?.s?.access_token || c.key}`, 'content-type': 'application/json', prefer: 'return=minimal' }, body: JSON.stringify(row) });
    if (!r.ok) throw new Error('Envoi refusé (' + r.status + ')');
    return true;
  },
  async uploadFile(path, body, contentType) {
    const t = await this.token(); if (!t) throw new Error('Non connecté au compte Nova');
    const r = await fetch(`${t.c.url}/storage/v1/object/photos/${t.s.user.id}/${path}`, { method: 'POST', headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': contentType, 'x-upsert': 'true' }, body });
    if (!r.ok) throw new Error('Envoi refusé (' + r.status + ')');
    return `${t.s.user.id}/${path}`;
  },
  async removePhotos(paths) {
    if (!paths?.length) return;
    const t = await this.token(); if (!t) return;
    await fetch(`${t.c.url}/storage/v1/object/photos`, { method: 'DELETE', headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': 'application/json' }, body: JSON.stringify({ prefixes: paths }) }).catch(() => {});
  },
};

async function blobToDataUrl(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return `data:${blob.type || 'image/jpeg'};base64,${btoa(bin)}`;
}

// Contenu sauvegardé : tout sauf ta clé API et ce qui est propre à ce PC (modes 24h/24, dossier photos…)
const BACKUP_LOCAL_ONLY = ['apiKey', 'phonePath', 'phoneDlId', 'phoneSince', 'vintedMaxSku', 'favAuto', 'aiAuto', 'favAutoSince', 'onboarded'];
async function collectBackup() {
  const d = await chrome.storage.local.get(['settings', 'quickReplies', 'favContacted', 'printedLabels']);
  const settings = Object.fromEntries(Object.entries(d.settings || {}).filter(([k]) => !BACKUP_LOCAL_ONLY.includes(k)));
  return { app: 'Nova Resell', version: chrome.runtime.getManifest().version, date: new Date().toISOString(), data: { settings, quickReplies: d.quickReplies || null, favContacted: (d.favContacted || []).slice(-2000), printedLabels: (d.printedLabels || []).slice(-500) } };
}
async function applyBackup(b) {
  if (b?.app !== 'Nova Resell' || !b.data) throw new Error('Sauvegarde invalide');
  const cur = await chrome.storage.local.get(['settings', 'favContacted', 'printedLabels']);
  const keep = Object.fromEntries(Object.entries(cur.settings || {}).filter(([k]) => BACKUP_LOCAL_ONLY.includes(k)));
  const upd = { settings: { ...(cur.settings || {}), ...(b.data.settings || {}), ...keep } };
  if (b.data.quickReplies) upd.quickReplies = b.data.quickReplies;
  upd.favContacted = [...new Set([...(cur.favContacted || []), ...(b.data.favContacted || [])])];
  upd.printedLabels = [...new Set([...(cur.printedLabels || []), ...(b.data.printedLabels || [])])];
  await chrome.storage.local.set(upd);
  return true;
}
