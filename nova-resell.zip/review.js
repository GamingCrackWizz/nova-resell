// ===== Nova Resell – réponses aux avis des acheteurs (partagé panneau / arrière-plan) =====
const REVIEW_TEMPLATES = [
  'Merci beaucoup {pseudo} pour ton avis 😊 Ravi que l’article te plaise, à bientôt sur mon dressing !',
  'Merci {pseudo} ! Super content que tout se soit bien passé 🙏 Au plaisir de te revoir sur mon dressing.',
  'Un grand merci {pseudo} pour ta confiance et ton avis 😊 Belle journée à toi !',
];
// Une des réponses types (choisie selon l'avis, pour ne pas répondre toujours la même chose)
function reviewReply(settings, f) {
  const list = String(settings.reviewTemplates || '').split(/\n\s*\n/).map((x) => x.trim()).filter(Boolean);
  const t = (list.length ? list : REVIEW_TEMPLATES)[Number(f.id) % (list.length || REVIEW_TEMPLATES.length)];
  return t.replaceAll('{pseudo}', f.author || '');
}
// Avis à qui on peut répondre automatiquement : 4 ou 5 étoiles, pas encore de réponse
const reviewAutoOk = (f) => f.canComment && !f.replied && Number(f.rating) >= 4;
