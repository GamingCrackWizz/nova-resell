// ===== Nova Resell – notifications sur l'iPhone (Web Push, sans serveur) =====
// Le PC signe et chiffre lui-même chaque notification (VAPID + aes128gcm, RFC 8291/8292),
// puis l'envoie au service de push d'Apple/Google. Les clés restent sur le PC.
const WebPush = (() => {
  const enc = new TextEncoder();
  const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = (s) => { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return Uint8Array.from(atob(s), (c) => c.charCodeAt(0)); };
  const cat = (...a) => { const out = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let o = 0; for (const x of a) { out.set(x, o); o += x.length; } return out; };
  const hmac = async (key, data) => new Uint8Array(await crypto.subtle.sign('HMAC', await crypto.subtle.importKey('raw', key, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']), data));

  // Clés VAPID du PC (créées une seule fois, gardées en local)
  async function keys() {
    const { vapid } = await chrome.storage.local.get('vapid');
    if (vapid?.priv && vapid?.pub) return vapid;
    const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
    const v = { priv: await crypto.subtle.exportKey('jwk', kp.privateKey), pub: b64u(await crypto.subtle.exportKey('raw', kp.publicKey)) };
    await chrome.storage.local.set({ vapid: v });
    return v;
  }
  async function vapidHeader(endpoint, v) {
    const aud = new URL(endpoint).origin;
    const head = b64u(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
    const body = b64u(enc.encode(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: 'https://novaresell.github.io/nova-resell/' })));
    const key = await crypto.subtle.importKey('jwk', v.priv, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
    const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, enc.encode(head + '.' + body));
    return `vapid t=${head}.${body}.${b64u(sig)}, k=${v.pub}`;
  }
  // Chiffrement du contenu (aes128gcm) pour l'abonnement {keys:{p256dh, auth}}
  async function encrypt(sub, text, salt = crypto.getRandomValues(new Uint8Array(16)), eph = null) {
    const uaPub = unb64u(sub.keys.p256dh), auth = unb64u(sub.keys.auth);
    eph = eph || await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
    const asPub = new Uint8Array(await crypto.subtle.exportKey('raw', eph.publicKey));
    const uaKey = await crypto.subtle.importKey('raw', uaPub, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
    const secret = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: uaKey }, eph.privateKey, 256));
    const prkKey = await hmac(auth, secret);
    const ikm = await hmac(prkKey, cat(enc.encode('WebPush: info\0'), uaPub, asPub, new Uint8Array([1])));
    const prk = await hmac(salt, ikm);
    const cek = (await hmac(prk, cat(enc.encode('Content-Encoding: aes128gcm\0'), new Uint8Array([1])))).slice(0, 16);
    const nonce = (await hmac(prk, cat(enc.encode('Content-Encoding: nonce\0'), new Uint8Array([1])))).slice(0, 12);
    const aes = await crypto.subtle.importKey('raw', cek, 'AES-GCM', false, ['encrypt']);
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, aes, cat(enc.encode(text), new Uint8Array([2]))));
    const rs = new Uint8Array([0, 0, 16, 0]); // 4096
    return cat(salt, rs, new Uint8Array([asPub.length]), asPub, ct);
  }
  // Envoie {title, body, tag, url} à un abonnement. Renvoie le code HTTP (404/410 = abonnement expiré)
  async function send(sub, msg) {
    const v = await keys();
    const body = await encrypt(sub, JSON.stringify(msg));
    const r = await fetch(sub.endpoint, {
      method: 'POST', body,
      headers: { Authorization: await vapidHeader(sub.endpoint, v), 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', TTL: '86400', Urgency: 'high', Topic: String(msg.tag || 'nova').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 32) || 'nova' },
    });
    return r.status;
  }
  return { keys, send, encrypt, vapidHeader, b64u, unb64u };
})();

// Catégories de notifications réglables dans l'extension (⚙︎ → Notifications iPhone)
const PUSH_KINDS = { sale: '🎉 Nouvelle vente', offer: '💬 Offre reçue', delivered: '📬 Colis livré', paid: '💶 Argent versé', ship: '📦 Rappel d’expédition' };

// Envoie à tous les iPhone abonnés (si la catégorie est activée). Ne fait jamais échouer l'appelant.
async function pushPhone(kind, title, body, tag) {
  try {
    const { settings = {}, pushSubs = [], pushSent = [] } = await chrome.storage.local.get(['settings', 'pushSubs', 'pushSent']);
    if (!settings.phonePush || !pushSubs.length) return 0;
    if (kind !== 'test' && (settings.pushKinds || {})[kind] === false) return 0;
    if (tag && pushSent.includes(tag)) return 0;
    let ok = 0; const keep = [];
    for (const s of pushSubs) {
      try {
        const code = await WebPush.send(s, { title, body, tag: tag || kind, url: 'https://novaresell.github.io/nova-resell/' });
        if (code === 404 || code === 410) continue; // iPhone désabonné : on l'oublie
        keep.push(s); if (code >= 200 && code < 300) ok++;
      } catch { keep.push(s); }
    }
    const upd = { pushSubs: keep };
    if (tag) upd.pushSent = [...pushSent, tag].slice(-400);
    await chrome.storage.local.set(upd);
    return ok;
  } catch { return 0; }
}
