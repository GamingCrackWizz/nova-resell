// ===== Nova Resell – mode grand écran (onglet complet, mise en page dédiée) =====
(() => {
  const full = /full/.test(location.hash);
  if (full) { document.body.classList.add('full'); document.title = 'Nova Resell'; }
  const btn = document.getElementById('fullBtn');
  if (!btn) return;
  btn.title = full ? 'Revenir au panneau latéral' : 'Ouvrir en grand écran';
  btn.innerHTML = full
    ? '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>'
    : '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>';
  btn.addEventListener('click', async () => {
    if (!full) {
      const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('sidepanel.html') + '#full' });
      if (tabs[0]) { chrome.tabs.update(tabs[0].id, { active: true }); chrome.windows.update(tabs[0].windowId, { focused: true }); }
      else chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html#full') });
      return;
    }
    try { const w = await chrome.windows.getCurrent(); await chrome.sidePanel.open({ windowId: w.id }); } catch { /* panneau indisponible */ }
    window.close();
  });
})();
