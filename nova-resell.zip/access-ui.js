// ===== Nova Resell – écran d'accès (compte Nova, essai, code bêta) =====
(() => {
  if (/print|worker/.test(location.hash)) return;
  const gate = $('#accessGate');
  async function render(a) {
    a = a || await NovaAccess.state();
    const ok = await NovaAccess.ok();
    const onboarding = $('#onboard') && !$('#onboard').hidden;
    // bandeau d'essai
    const trial = ok && a?.plan === 'trial';
    $('#trialBanner').hidden = !trial;
    if (trial) { const d = NovaAccess.daysLeft(a); $('#trialText').textContent = `🎁 Essai gratuit : ${d} jour${d > 1 ? 's' : ''} restant${d > 1 ? 's' : ''}`; }
    // écran bloquant
    gate.hidden = ok || onboarding;
    if (ok) return;
    const login = a?.reason === 'login';
    $('#agTitle').textContent = login ? 'Bienvenue sur Nova Resell' : 'Ton essai gratuit est terminé';
    $('#agText').textContent = login
      ? 'Connecte-toi ou crée ton compte Nova (gratuit) : tu profites de 7 jours d’essai complet. Testeur ? Entre ensuite ton code d’accès.'
      : 'Merci d’avoir testé Nova ! Pour continuer, entre ton code d’accès. L’abonnement Pro arrive bientôt.';
    $('#agLogin').hidden = !login;
    $('#agCodeBox').hidden = login;
  }
  window.showAccessGate = () => render();
  $('#agLogin').addEventListener('click', () => {
    gate.hidden = true;
    $('#toggleSettings')?.click();
    document.querySelector('.set-nav [data-set="compte"]')?.click();
  });
  async function redeem(code) {
    $('#agErr').textContent = '';
    try { const a = await NovaAccess.redeem(code); toast(a.plan === 'beta' ? '✅ Accès testeur activé, merci !' : '✅ Code accepté'); render(a); return true; }
    catch (e) { $('#agErr').textContent = /invalide/i.test(e.message) ? '❌ Code invalide' : 'Erreur : ' + e.message; return false; }
  }
  $('#agCodeGo').addEventListener('click', () => redeem($('#agCode').value));
  $('#agCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') redeem($('#agCode').value); });
  $('#trialCode').addEventListener('click', (e) => {
    e.preventDefault();
    gate.hidden = false; $('#agTitle').textContent = 'Entre ton code d’accès'; $('#agText').textContent = 'Testeur Nova : entre le code que tu as reçu.';
    $('#agLogin').hidden = true; $('#agCodeBox').hidden = false;
    const close = el('button', { className: 'btn ghost', textContent: 'Fermer' }); close.addEventListener('click', () => { close.remove(); render(); });
    $('#agErr').after(close);
  });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (c.novaAccess) render(c.novaAccess.newValue);
    if (c.novaCloud) NovaAccess.refresh();
  });
  NovaAccess.refresh().then(render);
  setInterval(() => render(), 60000);
})();
