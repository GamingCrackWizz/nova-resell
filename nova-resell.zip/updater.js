// ===== Nova Resell – mise à jour en 2 clics : « Mettre à jour » puis « Installer maintenant » =====
(() => {
  if (/print|worker/.test(location.hash)) return;
  let dlId = null, dlState = 'idle'; // idle | downloading | ready | installing
  // Chrome / Edge : mise à jour directe dans le dossier (sans .exe). Brave n'a pas cette fonction → installateur ou zip
  const fast = 'showDirectoryPicker' in window;
  let useExe = !fast;
  const openFast = () => chrome.windows.create({ url: chrome.runtime.getURL('update-folder.html'), type: 'popup', width: 460, height: 420 });
  async function render() {
    const { updateAvail: u, updateSnooze = {}, updateDl } = await chrome.storage.local.get(['updateAvail', 'updateSnooze', 'updateDl']);
    const show = !!u?.version && !(updateSnooze.version === u.version && Date.now() < updateSnooze.until);
    $('#updateBanner').hidden = !show;
    if (!show) return;
    if (updateDl?.version === u.version && dlState === 'idle') {
      // téléchargement déjà fait (panneau rouvert) : on retrouve le fichier
      const [d] = await chrome.downloads.search({ id: updateDl.id }).catch(() => []);
      if (d?.state === 'complete' && d.exists !== false) { dlId = d.id; dlState = 'ready'; }
    }
    $('#updTitle').textContent = `✨ Nova Resell ${novaVer(u.version)} est disponible (tu as la ${novaVer()})`;
    $('#updNotes').replaceChildren(...(u.notes || []).slice(0, 4).map((n) => el('span', { className: 'upd-note', textContent: '• ' + n })));
    const btn = $('#updGet');
    btn.disabled = dlState === 'downloading' || dlState === 'installing';
    $('#updExe').hidden = !fast || useExe;
    if (!useExe && dlState === 'idle') { btn.disabled = false; btn.textContent = '⚡ Mettre à jour en 1 clic'; $('#updHow').textContent = 'Nova installe la nouvelle version tout seul, sans fichier à lancer. Tes réglages, ton compte et ta clé API sont conservés.'; return; }
    btn.textContent = { idle: '⬇ Mettre à jour', downloading: 'Téléchargement…', ready: '▶ Installer maintenant', installing: 'Installation… Nova va redémarrer tout seul' }[dlState];
    $('#updHow').textContent = dlState === 'ready'
      ? "Clique sur « Installer maintenant ». Si Windows affiche « Windows a protégé votre ordinateur » : Informations complémentaires → Exécuter quand même. Nova se recharge tout seul après l'installation."
      : dlState === 'installing' ? 'Nova détecte la nouvelle version et redémarre automatiquement (quelques secondes).'
      : 'Deux clics et c’est fini : tes réglages, ton compte et ta clé API sont conservés.';
  }
  async function startDownload() {
    const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
    if (!u?.setup) return chrome.tabs.create({ url: 'https://github.com/novaresell/nova-resell' });
    dlState = 'downloading'; render();
    try {
      dlId = await chrome.downloads.download({ url: u.setup + '?v=' + u.version, filename: `Nova Resell ${novaVer(u.version)} - mise a jour.exe`, conflictAction: 'overwrite', saveAs: false });
      await chrome.storage.local.set({ updateDl: { id: dlId, version: u.version } });
    } catch (e) { dlState = 'idle'; toast('Téléchargement impossible : ' + e.message); render(); }
  }
  async function install() {
    try {
      const [d] = await chrome.downloads.search({ id: dlId });
      if (d && d.danger && !['safe', 'accepted'].includes(d.danger)) await chrome.downloads.acceptDanger(dlId);
      chrome.downloads.open(dlId);
      dlState = 'installing'; render();
      chrome.runtime.sendMessage({ va: 'watchSelfUpdate' }).catch(() => {});
    } catch (e) { toast("Impossible d'ouvrir l'installateur : " + e.message + ' · ouvre-le depuis tes Téléchargements'); chrome.downloads.show(dlId); }
  }
  $('#updGet').addEventListener('click', () => (!useExe && dlState === 'idle' ? openFast() : dlState === 'ready' ? install() : dlState === 'idle' ? startDownload() : null));
  $('#updExe').addEventListener('click', (e) => { e.preventDefault(); useExe = true; render(); });
  // Windows bloque l'installateur (Contrôle intelligent des applications) : mise à jour par le zip, sans rien lancer
  $('#updBlocked').addEventListener('click', async (e) => {
    e.preventDefault();
    const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
    if (fast) { openFast(); return; }
    if (!u?.zip) return;
    await chrome.downloads.download({ url: u.zip + '?v=' + u.version, filename: 'nova-resell.zip', conflictAction: 'overwrite', saveAs: false }).catch(() => {});
    $('#updHow').textContent = "Le zip est dans tes Téléchargements. Clic droit dessus → « Extraire tout… » → « Parcourir » → choisis le dossier de Nova (installé avec l'installateur : Documents › Nova Resell › extension) → Extraire → « Remplacer les fichiers ». Nova redémarre tout seul dans la minute.";
    chrome.runtime.sendMessage({ va: 'watchSelfUpdate' }).catch(() => {});
  });
  chrome.downloads.onChanged.addListener((d) => {
    if (d.id !== dlId) return;
    if (d.state?.current === 'complete') { dlState = 'ready'; render(); toast('Mise à jour téléchargée : clique sur « Installer maintenant »'); }
    if (d.state?.current === 'interrupted') { dlState = 'idle'; render(); toast('Téléchargement interrompu, réessaie'); }
  });
  $('#updLater').addEventListener('click', async () => {
    const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
    await chrome.storage.local.set({ updateSnooze: { version: u?.version, until: Date.now() + 24 * 3600e3 } });
    render();
  });
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && (c.updateAvail || c.updateSnooze)) render(); });
  render();
  chrome.runtime.sendMessage({ va: 'checkUpdate' }).catch(() => {});
})();
