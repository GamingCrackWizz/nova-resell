// ===== Nova Resell – mise à jour directe dans le dossier de l'extension (Chrome / Edge) =====
// Le testeur autorise une seule fois le dossier de Nova ; ensuite chaque mise à jour = 1 clic, sans .exe ni zip à extraire.
const $ = (s) => document.querySelector(s);
const msg = (t, c = '') => { $('#msg').textContent = t; $('#msg').className = c; };
const db = () => new Promise((ok, ko) => { const r = indexedDB.open('novaUpdate', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => ok(r.result); r.onerror = () => ko(r.error); });
const kv = async (mode, fn) => { const d = await db(); return new Promise((ok, ko) => { const tx = d.transaction('kv', mode); const q = fn(tx.objectStore('kv')); tx.oncomplete = () => ok(q?.result); tx.onerror = () => ko(tx.error); }); };
const getDir = () => kv('readonly', (s) => s.get('dir'));
const setDir = (h) => kv('readwrite', (s) => s.put(h, 'dir'));
const me = chrome.runtime.getManifest();

async function isNovaFolder(dir) {
  try {
    const m = JSON.parse(await (await (await dir.getFileHandle('manifest.json')).getFile()).text());
    return m.name === me.name && m.version === me.version;
  } catch { return false; }
}
async function writeFile(root, path, data) {
  const parts = path.split('/'); let d = root;
  for (const p of parts.slice(0, -1)) d = await d.getDirectoryHandle(p, { create: true });
  const w = await (await d.getFileHandle(parts[parts.length - 1], { create: true })).createWritable();
  await w.write(data); await w.close();
}
async function run(dir) {
  const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
  if (!u?.zip) throw new Error('Aucune mise à jour à installer');
  $('#bar').hidden = false; const bar = $('#bar i');
  msg('Téléchargement…');
  const r = await fetch(u.zip + '?v=' + u.version, { cache: 'no-store' });
  if (!r.ok) throw new Error('Téléchargement impossible (' + r.status + ')');
  const zip = await JSZip.loadAsync(await r.arrayBuffer());
  const files = Object.values(zip.files).filter((f) => !f.dir);
  const man = files.find((f) => f.name === 'manifest.json');
  if (!man || JSON.parse(await man.async('string')).version !== u.version) throw new Error('Fichier de mise à jour invalide');
  // tout est préparé en mémoire avant d'écrire ; manifest.json en dernier (c'est lui qui déclenche la nouvelle version)
  const data = [];
  for (const f of files) data.push([f.name, await f.async('uint8array')]);
  data.sort((a, b) => (a[0] === 'manifest.json') - (b[0] === 'manifest.json'));
  let n = 0;
  for (const [name, bytes] of data) { await writeFile(dir, name, bytes); bar.style.width = (++n / data.length * 100) + '%'; msg(`Installation… ${n}/${data.length}`); }
  await chrome.storage.local.set({ justUpdated: { from: me.version, to: u.version, at: Date.now() } });
  msg('✅ Nova ' + u.version + ' installé : redémarrage…', 'ok');
  setTimeout(() => chrome.runtime.reload(), 800);
}

(async () => {
  const { updateAvail: u } = await chrome.storage.local.get('updateAvail');
  let dir = await getDir().catch(() => null);
  const ver = u?.name || u?.version || '';
  $('#t').textContent = `⚡ Installer Nova ${ver}`;
  $('#d').innerHTML = dir
    ? 'Nova va télécharger et installer la nouvelle version dans son dossier, puis redémarrer. Tes réglages sont conservés.'
    : 'Première fois : choisis le <b>dossier de Nova</b> (celui qui contient <code>manifest.json</code>). Installé avec l\'installateur : <code>Documents › Nova Resell › extension</code>. Ensuite, les mises à jour se feront en 1 clic.';
  $('#go').textContent = dir ? '⚡ Mettre à jour maintenant' : '📂 Choisir le dossier de Nova';
  $('#go').addEventListener('click', async () => {
    $('#go').disabled = true;
    try {
      if (dir) {
        if ((await dir.requestPermission({ mode: 'readwrite' })) !== 'granted') throw new Error('Autorisation refusée');
        if (!(await isNovaFolder(dir))) { dir = null; throw new Error('Le dossier enregistré ne correspond plus à Nova : rechoisis-le'); }
      } else {
        const d = await showDirectoryPicker({ id: 'nova-folder', mode: 'readwrite', startIn: 'documents' });
        if (!(await isNovaFolder(d))) throw new Error("Ce n'est pas le dossier de Nova : choisis celui qui contient manifest.json (Documents › Nova Resell › extension)");
        await setDir(d); dir = d;
      }
      await run(dir);
    } catch (e) {
      if (e.name === 'AbortError') msg(''); else msg(e.message, 'err');
      $('#go').disabled = false; $('#go').textContent = dir ? '⚡ Réessayer' : '📂 Choisir le dossier de Nova';
    }
  });
})();
