// ===== Nova Resell – offres groupées (onglet Favoris) =====
(() => {
  let done = new Set(); const sending = new Set();
  const sel = (id) => document.getElementById(id);
  async function init() {
    const s = await chrome.storage.local.get(['bundleContacted', 'settings']);
    done = new Set(s.bundleContacted || []);
    const st = s.settings || {};
    sel('bundleDiscount').value = st.bundleDiscount ?? 15;
    sel('bundleAuto').checked = !!st.bundleAuto;
    sel('bundleTemplate').value = st.bundleTemplate || BUNDLE_TEMPLATE;
  }
  function render() {
    const box = sel('bundleList'); if (!box || !favs.loaded) return;
    const groups = bundleGroups(favs.list, favs.prices, done);
    sel('bundleCount').textContent = groups.length || '';
    if (!groups.length) { box.replaceChildren(el('p', { className: 'hint', textContent: 'Personne n’a encore mis 2 de tes articles en favori. Nova te préviendra ici.' })); return; }
    box.replaceChildren(...groups.slice(0, 20).map((g) => {
      const { total, lot } = bundlePrice(settings, g);
      const go = el('button', { className: 'btn primary', textContent: sending.has(g.key) ? '…' : 'Proposer le lot', disabled: sending.has(g.key) });
      go.addEventListener('click', () => send(g));
      const skip = el('button', { className: 'btn ghost', textContent: 'Ignorer' });
      skip.addEventListener('click', async () => { done.add(g.key); await chrome.storage.local.set({ bundleContacted: [...done].slice(-1000) }); render(); });
      const prev = el('button', { className: 'btn ghost', textContent: 'Aperçu' });
      prev.addEventListener('click', () => alert(bundleMessage(settings, g)));
      return el('div', { className: 'row-item bundle-row' },
        el('div', { className: 'bundle-pics' }, ...g.items.slice(0, 3).map((i) => el('img', { src: i.photo || '', alt: '' }))),
        el('div', { className: 'meta' }, el('div', { className: 'title', textContent: `@${g.pseudo} · ${g.items.length} articles` }),
          el('div', { className: 'sub' }, g.items.map((i) => String(i.title).replace(/\s*\(#?P\d+\)\s*$/i, '')).join(' + ').slice(0, 90), ' · ', el('s', { textContent: total + ' €' }), ' → ', el('b', { textContent: lot + ' €' }))),
        el('div', { className: 'row-actions' }, go, prev, skip));
    }));
  }
  async function send(g) {
    if (!confirm(`Proposer le lot de ${g.items.length} articles à @${g.pseudo} pour ${bundlePrice(settings, g).lot} € ?`)) return;
    sending.add(g.key); render();
    try {
      await vinted('contactFav', { itemId: g.items[0].id, userId: g.userId, body: bundleMessage(settings, g), offerPrice: null, _t: `Lot de ${g.items.length} articles`, _who: g.pseudo });
      done.add(g.key);
      g.items.forEach((i) => favs.contacted.add(`${i.id}-${g.userId}`));
      await chrome.storage.local.set({ bundleContacted: [...done].slice(-1000), favContacted: [...favs.contacted] });
      logActivity?.({ cat: 'msg', icon: '🛍️', title: `Lot proposé à @${g.pseudo}`, detail: `${g.items.length} articles · ${bundlePrice(settings, g).lot} €`, via: 'pc' });
      toast(`Lot proposé à @${g.pseudo} ✓`);
    } catch (e) { toast(`@${g.pseudo} : ${e.message}`); }
    finally { sending.delete(g.key); renderFavs(); }
  }
  const save = () => {
    settings.bundleDiscount = Math.min(60, Math.max(0, Number(sel('bundleDiscount').value) || 0));
    settings.bundleTemplate = sel('bundleTemplate').value.trim() || BUNDLE_TEMPLATE;
    saveSettings(); render();
  };
  sel('bundleDiscount').addEventListener('change', save);
  sel('bundleTemplate').addEventListener('change', save);
  sel('bundleAuto').addEventListener('change', async () => {
    if (sel('bundleAuto').checked && !confirm('Proposer automatiquement un lot à chaque personne qui aime au moins 2 de tes articles ?\nLe message part sans validation de ta part.')) { sel('bundleAuto').checked = false; return; }
    settings.bundleAuto = sel('bundleAuto').checked;
    if (settings.bundleAuto) settings.bundleAutoSince = Date.now() - 3 * 864e5; // les favoris des 3 derniers jours comptent aussi
    await saveSettings();
    if (settings.bundleAuto) chrome.runtime.sendMessage({ va: 'autoFavNow' }).catch(() => {});
    toast(settings.bundleAuto ? 'Offres groupées automatiques activées' : 'Offres groupées automatiques désactivées');
  });
  chrome.storage.onChanged.addListener((c) => { if (c.bundleContacted) { done = new Set(c.bundleContacted.newValue || []); render(); } });
  window.renderBundles = render;
  init().then(render);
})();
