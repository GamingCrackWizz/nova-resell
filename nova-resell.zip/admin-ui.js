// ===== Nova Resell – administration des comptes (admin) + mes données (RGPD) =====
(() => {
  if (/print|worker/.test(location.hash)) return;
  const rpc = (fn, args = {}) => NovaCloud.rest('POST', 'rpc/' + fn, args);
  const ADMIN = 'chantepie.000@gmail.com';
  const PLAN = { trial: '🎁 Essai', beta: '🧪 Bêta', pro: '💎 Pro', blocked: '⛔ Bloqué', admin: '👑 Admin' };
  const fmt = (d) => d ? new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : '—';
  let users = [];

  // ---------- Administration ----------
  async function isAdmin() { const c = await NovaCloud.cfg(); return (c.session?.user?.email || '').toLowerCase() === ADMIN; }
  function status(u) {
    if (u.plan === 'trial') { const d = Math.ceil((Date.parse(u.trial_ends) - Date.now()) / 864e5); return d > 0 ? `${d} j d'essai restants` : 'essai terminé'; }
    if (u.plan === 'pro') return u.paid_until ? 'jusqu’au ' + fmt(u.paid_until) : 'sans fin';
    return '';
  }
  function renderUsers() {
    const q = ($('#usrSearch').value || '').toLowerCase();
    const list = users.filter((u) => !q || (u.email || '').includes(q));
    $('#usrCount').textContent = users.length || '';
    $('#usrList').replaceChildren(...list.map((u) => {
      const sel = el('select', {}, ...['trial', 'beta', 'pro', 'blocked'].map((p) => el('option', { value: p, textContent: PLAN[p], selected: u.plan === p })));
      sel.disabled = u.plan === 'admin';
      sel.addEventListener('change', () => setPlan(u, sel.value));
      const ext = el('button', { className: 'btn ghost small', textContent: '+7 j', title: 'Prolonger l’essai de 7 jours', hidden: u.plan !== 'trial' });
      ext.addEventListener('click', () => setPlan(u, 'trial', 7));
      const online = u.last_seen && Date.now() - Date.parse(u.last_seen) < 7 * 60000;
      return el('div', { className: 'usr-row' },
        el('span', { className: 'pres-dot' + (online ? ' on' : '') }),
        el('div', {}, el('b', { textContent: u.email || '(e-mail inconnu)' }),
          el('span', { className: 'hint', textContent: `${PLAN[u.plan] || u.plan}${status(u) ? ' · ' + status(u) : ''} · inscrit le ${fmt(u.created_at)}${u.version ? ' · v' + u.version : ''}${u.last_seen ? ' · vu le ' + fmt(u.last_seen) : ''}` })),
        el('div', { className: 'usr-act' }, u.plan === 'admin' ? el('span', { className: 'hint', textContent: PLAN.admin }) : sel, ext));
    }));
    if (!list.length) $('#usrList').replaceChildren(el('p', { className: 'hint', textContent: users.length ? 'Aucun résultat.' : 'Aucun compte pour l’instant.' }));
  }
  async function setPlan(u, plan, days = null) {
    let paid = null;
    if (plan === 'pro') {
      const months = Number(prompt('Pro pendant combien de mois ? (vide = sans fin)', '1'));
      paid = months > 0 ? new Date(Date.now() + months * 30 * 864e5).toISOString() : null;
    }
    try { await rpc('nova_admin_set', { p_user: u.user_id, p_plan: plan, p_days: days, p_paid_until: paid }); toast(`✅ ${u.email} → ${PLAN[plan]}${days ? ' (+' + days + ' j)' : ''}`); await loadUsers(); }
    catch (e) { toast('Échec : ' + e.message); renderUsers(); }
  }
  async function loadUsers() {
    try { users = await rpc('nova_admin_users') || []; renderUsers(); loadCodes(); }
    catch (e) { $('#usrList').replaceChildren(el('p', { className: 'hint', textContent: 'Lecture impossible : ' + e.message })); }
  }
  async function loadCodes() {
    try {
      const codes = await rpc('nova_admin_codes') || [];
      $('#codeList').replaceChildren(...codes.map((c) => {
        const t = el('button', { className: 'btn ghost small', textContent: c.active ? 'Désactiver' : 'Réactiver' });
        t.addEventListener('click', async () => { await rpc('nova_admin_code', { p_code: c.code, p_plan: c.plan, p_active: !c.active }).catch((e) => toast(e.message)); loadCodes(); });
        const copy = el('button', { className: 'btn ghost small', textContent: 'Copier' });
        copy.addEventListener('click', () => navigator.clipboard.writeText(c.code).then(() => toast('Code copié')));
        return el('div', { className: 'code-row' + (c.active ? '' : ' off') }, el('code', { textContent: c.code }), el('span', { className: 'hint', textContent: `${PLAN[c.plan] || c.plan} · ${c.uses} utilisation${c.uses > 1 ? 's' : ''}${c.active ? '' : ' · désactivé'}` }), copy, t);
      }));
    } catch { /* codes indisponibles */ }
  }
  $('#codeAdd').addEventListener('click', async () => {
    const code = $('#codeNew').value.trim().toUpperCase();
    if (code.length < 6) return toast('Code trop court (6 caractères minimum)');
    try { await rpc('nova_admin_code', { p_code: code, p_plan: $('#codePlan').value, p_active: true }); $('#codeNew').value = ''; toast('🔑 Code créé : ' + code); loadCodes(); }
    catch (e) { toast('Échec : ' + e.message); }
  });
  $('#usrSearch').addEventListener('input', renderUsers);
  $('#usrReload').addEventListener('click', loadUsers);
  async function initAdmin() { const a = await isAdmin(); $('#usrAdmin').hidden = !a; if (a) loadUsers(); }
  document.querySelectorAll('[data-tab]').forEach((t) => t.addEventListener('click', () => { if (/aide|help/i.test(t.dataset.tab)) initAdmin(); }));
  initAdmin();

  // ---------- RGPD : exporter / supprimer ----------
  $('#gdprExport').addEventListener('click', async () => {
    const b = $('#gdprExport'); b.disabled = true;
    try {
      const server = await rpc('nova_export_me').catch((e) => ({ erreur: e.message }));
      const local = await chrome.storage.local.get(null);
      if (local.settings) local.settings = { ...local.settings, apiKey: local.settings.apiKey ? '(masquée)' : '' };
      delete local.novaCloud; delete local.vapid;
      const data = { application: 'Nova Resell', version: chrome.runtime.getManifest().version, date: new Date().toISOString(), serveur_nova: server, donnees_de_ce_pc: local };
      const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      await chrome.downloads.download({ url, filename: `nova-resell-mes-donnees-${new Date().toISOString().slice(0, 10)}.json`, saveAs: true });
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      toast('⬇ Export prêt');
    } catch (e) { toast('Export impossible : ' + e.message); }
    b.disabled = false;
  });
  $('#gdprDelete').addEventListener('click', () => { $('#gdprConfirm').hidden = !$('#gdprConfirm').hidden; $('#gdprWord').value = ''; });
  async function listFiles(prefix, out = [], depth = 0) {
    const t = await NovaCloud.token(); if (!t) return out;
    const r = await fetch(`${t.c.url}/storage/v1/object/list/photos`, { method: 'POST', headers: { apikey: t.c.key, authorization: `Bearer ${t.s.access_token}`, 'content-type': 'application/json' }, body: JSON.stringify({ prefix, limit: 1000 }) });
    const items = r.ok ? await r.json() : [];
    for (const it of items) { if (it.id) out.push(prefix + it.name); else if (depth < 3) await listFiles(prefix + it.name + '/', out, depth + 1); }
    return out;
  }
  $('#gdprGo').addEventListener('click', async () => {
    if ($('#gdprWord').value.trim().toUpperCase() !== 'SUPPRIMER') return toast('Tape SUPPRIMER pour confirmer');
    const b = $('#gdprGo'); b.disabled = true; b.textContent = 'Suppression…';
    try {
      const c = await NovaCloud.cfg(); const uid = c.session?.user?.id;
      if (uid) { const files = await listFiles(uid + '/'); for (let i = 0; i < files.length; i += 100) await NovaCloud.removePhotos(files.slice(i, i + 100)); }
      await rpc('nova_delete_me');
      await chrome.storage.local.clear();
      toast('Compte et données supprimés');
      setTimeout(() => chrome.runtime.reload(), 1200);
    } catch (e) { toast('Suppression impossible : ' + e.message); b.disabled = false; b.textContent = 'Supprimer définitivement'; }
  });
})();
